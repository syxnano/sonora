package com.personal.sonora.data.social

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.personal.sonora.data.catalog.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Social room over Firebase Realtime Database.
 * - 6-digit room code
 * - Chat messages
 * - Playback commands (play / pause / seek / track)
 * No email/password login: uses Anonymous Auth (or continues without auth if rules allow).
 *
 * DB paths:
 *   rooms/{code}/meta
 *   rooms/{code}/messages/{id}
 *   rooms/{code}/playback  (last command)
 *   rooms/{code}/presence/{uid}
 */
@Singleton
class FirebaseRoomRepository @Inject constructor() {

    data class ChatMsg(
        val id: String = "",
        val sender: String = "",
        val text: String = "",
        val ts: Long = 0L,
        val tts: Boolean = true
    )

    data class PlaybackCmd(
        val type: String = "", // play, pause, seek, track
        val positionMs: Long = 0L,
        val trackId: String? = null,
        val trackTitle: String? = null,
        val trackArtist: String? = null,
        val coverUrl: String? = null,
        val by: String = "",
        val ts: Long = 0L,
        val cmdId: String = ""
    )

    data class RoomUi(
        val code: String? = null,
        val isHost: Boolean = false,
        val connected: Boolean = false,
        val status: String = "idle",
        val error: String? = null,
        val peerCount: Int = 0
    )

    private val _room = MutableStateFlow(RoomUi())
    val room: StateFlow<RoomUi> = _room.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages.asStateFlow()

    private val _playback = MutableStateFlow<PlaybackCmd?>(null)
    val playback: StateFlow<PlaybackCmd?> = _playback.asStateFlow()

    private var msgListener: ChildEventListener? = null
    private var playListener: ValueEventListener? = null
    private var presenceListener: ValueEventListener? = null
    private var currentCode: String? = null
    private var myUid: String = "guest_${UUID.randomUUID().toString().take(8)}"
    private var lastAppliedCmdId: String? = null

    private fun db(): FirebaseDatabase? = try {
        val url = com.personal.sonora.BuildConfig.FIREBASE_DB_URL
        if (url.isNotBlank()) FirebaseDatabase.getInstance(url) else FirebaseDatabase.getInstance()
    } catch (_: Exception) {
        null
    }

    private val timeoutMsg =
        "เชื่อมต่อ Firebase Realtime Database ไม่ได้ (หมดเวลา) ตรวจว่าเน็ตใช้ได้ และสร้าง Realtime Database ใน Firebase Console แล้ว"

    private fun auth(): FirebaseAuth? = try {
        FirebaseAuth.getInstance()
    } catch (_: Exception) {
        null
    }

    /** Ensure anonymous session (no UI login). Best effort: rules allow access without auth. */
    suspend fun ensureAuth(): Boolean {
        val a = auth() ?: return false
        return try {
            if (a.currentUser == null) {
                withTimeout(6_000) { a.signInAnonymously().await() }
            }
            myUid = a.currentUser?.uid ?: myUid
            true
        } catch (e: TimeoutCancellationException) {
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
    }

    suspend fun createRoom(displayName: String): String? {
        if (db() == null) {
            _room.value = RoomUi(error = "ใส่ google-services.json ก่อน (Firebase)")
            return null
        }
        ensureAuth()
        val code = Random.nextInt(100000, 999999).toString()
        val ref = db()!!.getReference("rooms").child(code)
        val meta = mapOf(
            "createdAt" to ServerValue.TIMESTAMP,
            "host" to myUid,
            "hostName" to displayName
        )
        return try {
            withTimeout(12_000) { ref.child("meta").setValue(meta).await() }
            joinInternal(code, displayName, isHost = true)
            code
        } catch (e: TimeoutCancellationException) {
            _room.value = RoomUi(error = timeoutMsg)
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _room.value = RoomUi(error = e.message)
            null
        }
    }

    suspend fun joinRoom(code: String, displayName: String): Boolean {
        if (code.length != 6 || !code.all { it.isDigit() }) {
            _room.value = RoomUi(error = "รหัสต้องเป็นตัวเลข 6 หลัก")
            return false
        }
        if (db() == null) {
            _room.value = RoomUi(error = "ใส่ google-services.json ก่อน (Firebase)")
            return false
        }
        ensureAuth()
        return try {
            val snap = withTimeout(12_000) {
                db()!!.getReference("rooms").child(code).child("meta").get().await()
            }
            if (!snap.exists()) {
                // auto-create empty room if missing (friendlier for testing)
                db()!!.getReference("rooms").child(code).child("meta").setValue(
                    mapOf(
                        "createdAt" to ServerValue.TIMESTAMP,
                        "host" to myUid,
                        "hostName" to displayName
                    )
                ).await()
            }
            joinInternal(code, displayName, isHost = false)
            true
        } catch (e: TimeoutCancellationException) {
            _room.value = RoomUi(error = timeoutMsg)
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _room.value = RoomUi(error = e.message)
            false
        }
    }

    private fun joinInternal(code: String, displayName: String, isHost: Boolean) {
        leaveListenersOnly()
        currentCode = code
        _messages.value = emptyList()
        _playback.value = null
        lastAppliedCmdId = null

        val roomRef = db()!!.getReference("rooms").child(code)

        // presence
        val presenceRef = roomRef.child("presence").child(myUid)
        presenceRef.setValue(
            mapOf("name" to displayName, "at" to ServerValue.TIMESTAMP)
        )
        presenceRef.onDisconnect().removeValue()

        presenceListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _room.value = _room.value.copy(peerCount = snapshot.childrenCount.toInt())
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        roomRef.child("presence").addValueEventListener(presenceListener!!)

        // messages
        msgListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val m = snapshot.getValue(ChatMsg::class.java)?.copy(id = snapshot.key ?: "")
                    ?: return
                _messages.value = (_messages.value + m).takeLast(100)
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                _room.value = _room.value.copy(error = error.message)
            }
        }
        roomRef.child("messages").limitToLast(50).addChildEventListener(msgListener!!)

        // playback commands
        playListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val cmd = snapshot.getValue(PlaybackCmd::class.java) ?: return
                if (cmd.cmdId.isNotBlank() && cmd.cmdId == lastAppliedCmdId) return
                if (cmd.by == myUid) {
                    lastAppliedCmdId = cmd.cmdId
                    return // ignore own echo
                }
                lastAppliedCmdId = cmd.cmdId
                _playback.value = cmd
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        roomRef.child("playback").addValueEventListener(playListener!!)

        _room.value = RoomUi(
            code = code,
            isHost = isHost,
            connected = true,
            status = "connected",
            peerCount = 1
        )
    }

    fun sendChat(sender: String, text: String) {
        val code = currentCode ?: return
        val id = UUID.randomUUID().toString().take(12)
        val msg = ChatMsg(
            id = id,
            sender = sender,
            text = text.trim(),
            ts = System.currentTimeMillis(),
            tts = true
        )
        db()?.getReference("rooms")?.child(code)?.child("messages")?.child(id)?.setValue(msg)
    }

    fun sendPlayback(
        type: String,
        positionMs: Long = 0,
        track: Track? = null,
        byName: String = ""
    ) {
        val code = currentCode ?: return
        val cmd = PlaybackCmd(
            type = type,
            positionMs = positionMs,
            trackId = track?.id,
            trackTitle = track?.title,
            trackArtist = track?.artist,
            coverUrl = track?.coverUrl,
            by = myUid,
            ts = System.currentTimeMillis(),
            cmdId = UUID.randomUUID().toString()
        )
        lastAppliedCmdId = cmd.cmdId
        db()?.getReference("rooms")?.child(code)?.child("playback")?.setValue(cmd)
    }

    fun leave() {
        val code = currentCode
        if (code != null) {
            try {
                db()?.getReference("rooms")?.child(code)?.child("presence")?.child(myUid)?.removeValue()
            } catch (_: Exception) {}
        }
        leaveListenersOnly()
        currentCode = null
        _room.value = RoomUi()
        _messages.value = emptyList()
        _playback.value = null
    }

    private fun leaveListenersOnly() {
        val code = currentCode ?: return
        val roomRef = try { db()?.getReference("rooms")?.child(code) } catch (_: Exception) { null }
        msgListener?.let { roomRef?.child("messages")?.removeEventListener(it) }
        playListener?.let { roomRef?.child("playback")?.removeEventListener(it) }
        presenceListener?.let { roomRef?.child("presence")?.removeEventListener(it) }
        msgListener = null
        playListener = null
        presenceListener = null
    }
}
