# Sonora BUILD_FIX_08

แก้ crash ตอนเปิดแอปก่อนล็อกอินและ harden auth/firestore listeners

## โค้ดที่แก้
- DirectMessageRepository: ไม่เรียก uid() แบบบังคับก่อน auth; ฟัง FirebaseAuth state และคืน empty list เมื่อยังไม่ล็อกอิน/Firestore listener error
- FeedRepository / ProviderConnectionRepository: listener error ไม่ close flow ด้วย exception แล้ว
- DM / ChatHub / DirectConversation / SocialHome ViewModel: เพิ่ม Flow catch เป็นชั้นกันซ้ำ
- NavGraph: ไม่สร้าง DM chat-head overlay เมื่อยังไม่ล็อกอิน
- AuthScreen: ตรวจ Email/password ก่อนเรียก Firebase, password masking, loading, กันกดซ้ำ, scroll เมื่อคีย์บอร์ดขึ้น, Google error handling
- AuthRepository: ตรวจ Web Client ID และ idToken ก่อน Google credential
- ไม่ส่ง X/TikTok client secret ใน local.properties ของ ZIP นี้

## ต้องทำใน Firebase Console
1. Authentication > Sign-in method: เปิด Email/Password และ Google
2. Project settings > Android app `com.personal.sonora`: เพิ่ม SHA-1 และ SHA-256 ของ keystore ที่ใช้จริง
3. ดาวน์โหลด `google-services.json` ใหม่ แล้ววางทับ `app/google-services.json` หลังเพิ่ม fingerprints; ต้องมี oauth_client
4. Authentication > Google > Web SDK configuration: นำ Web Client ID มาใส่ `default_web_client_id` ใน `app/src/main/res/values/strings.xml`
5. Deploy index/rules: `firebase deploy --only firestore:indexes,firestore:rules`
6. ถ้า App Check เปิด Enforcement สำหรับ debug ให้ปิดชั่วคราวหรือ register debug token

## Build
แนะนำใช้ Gradle 8.13 ตาม wrapper/CI ของโปรเจกต์
`bash gradlew assembleDebug --no-daemon`
