package com.personal.sonora.ui.dm

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.dm.DirectMessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DirectConversationViewModel @Inject constructor(
    private val repo: DirectMessageRepository
) : ViewModel() {
    private val _other = MutableStateFlow("")
    val other: StateFlow<String> = _other.asStateFlow()
    val messages: StateFlow<List<DirectMessageRepository.Message>> = _other.flatMapLatest { uid ->
        if (uid.isBlank()) flowOf(emptyList()) else repo.observeMessages(uid)
    }.catch { emit(emptyList()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun open(uid: String) { _other.value = uid; viewModelScope.launch { repo.markRead(uid) } }
    fun send(text: String) = viewModelScope.launch { if (_other.value.isNotBlank()) repo.send(_other.value, text) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectConversationScreen(
    otherUid: String,
    displayName: String,
    onBack: () -> Unit,
    vm: DirectConversationViewModel = hiltViewModel()
) {
    LaunchedEffect(otherUid) { vm.open(otherUid) }
    val messages by vm.messages.collectAsState()
    var text by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text(displayName) }, navigationIcon = { Button(onClick = onBack) { Text("กลับ") } }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { m -> Text(m.text) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("ข้อความ") })
                Button(onClick = { vm.send(text); text = "" }, enabled = text.isNotBlank()) { Text("ส่ง") }
            }
        }
    }
}
