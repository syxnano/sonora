package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

/**
 * TikTok boundary connector.
 * - Embed playback is handled by [com.personal.sonora.video.EmbeddedVideoPlayer]
 * - Official Login Kit can authorize profile scopes when configured
 * - Automatic DM *send* is NOT available on public TikTok developer APIs
 */
class TikTokConnector : SonoraConnector {
    override val platform = Platform.TIKTOK

    override suspend fun capabilities() = listOf(
        CapabilityStatus(Capability.READ_PROFILE, CapabilityState.NEEDS_PERMISSION, "Login Kit + user.info.basic"),
        CapabilityStatus(Capability.READ_STATS, CapabilityState.NEEDS_PERMISSION, "Stats scope/account eligibility"),
        CapabilityStatus(Capability.READ_FEED, CapabilityState.NEEDS_PERMISSION, "Provider/API eligibility"),
        CapabilityStatus(Capability.READ_MEDIA, CapabilityState.SUPPORTED, "Official Embed Player in Sonora"),
        CapabilityStatus(
            Capability.READ_MESSAGES, CapabilityState.NEEDS_PERMISSION,
            "Data Portability API exports DM copies — not a live inbox"
        ),
        CapabilityStatus(
            Capability.SEND_MESSAGE, CapabilityState.UNSUPPORTED,
            "No public TikTok API to send DMs; open TikTok app/web instead"
        ),
        CapabilityStatus(
            Capability.DAILY_FLAME, CapabilityState.SUPPORTED,
            "Tracked in Sonora after a confirmed external action"
        ),
        CapabilityStatus(Capability.EMBED_PLAYBACK, CapabilityState.SUPPORTED, "Official TikTok player/v1 embed")
    )

    override suspend fun connect() = Result.success(Unit)
    override suspend fun disconnect() = Result.success(Unit)
    override suspend fun refresh() = Result.success(Unit)
}
