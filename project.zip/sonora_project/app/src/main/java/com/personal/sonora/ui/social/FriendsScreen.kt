package com.personal.sonora.ui.social

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.socialnet.SocialRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FriendsViewModel @Inject constructor(
    private val repo: SocialRepository
) : ViewModel() {
    val incoming: StateFlow<List<SocialRepository.FriendRequest>> =
        repo.observeIncomingRequests().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val friends: StateFlow<List<SocialRepository.Friend>> =
        repo.observeFriends().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _message = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _searchHits = kotlinx.coroutines.flow.MutableStateFlow<List<SocialRepository.UserHit>>(emptyList())
    val searchHits: StateFlow<List<SocialRepository.UserHit>> = _searchHits

    fun search(q: String) = viewModelScope.launch {
        _searchHits.value = runCatching { repo.searchUsers(q) }.getOrDefault(emptyList())
    }

    fun addByUid(uid: String) = viewModelScope.launch {
        runCatching { repo.sendFriendRequest(uid) }
            .onSuccess { _message.value = "ส่งคำขอเพื่อนแล้ว" }
            .onFailure { _message.value = it.message ?: "ส่งไม่สำเร็จ" }
    }

    fun accept(req: SocialRepository.FriendRequest) = viewModelScope.launch {
        runCatching { repo.acceptFriendRequest(req.id, req.from) }
            .onSuccess { _message.value = "รับเพื่อนแล้ว" }
            .onFailure { _message.value = it.message ?: "รับไม่สำเร็จ" }
    }

    fun reject(req: SocialRepository.FriendRequest) = viewModelScope.launch {
        runCatching { repo.rejectFriendRequest(req.id) }
            .onSuccess { _message.value = "ปฏิเสธแล้ว" }
            .onFailure { _message.value = it.message ?: "ไม่สำเร็จ" }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    onBack: () -> Unit,
    onOpenChat: (uid: String, name: String) -> Unit = { _, _ -> },
    vm: FriendsViewModel = hiltViewModel()
) {
    val incoming by vm.incoming.collectAsState()
    val friends by vm.friends.collectAsState()
    val message by vm.message.collectAsState()
    val hits by vm.searchHits.collectAsState()
    var uid by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("เพื่อน") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("กลับ") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("เพิ่มเพื่อน", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = uid,
                    onValueChange = { uid = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("UID ของเพื่อน") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { vm.addByUid(uid); uid = "" },
                    enabled = uid.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ส่งคำขอเพื่อน") }
            }
            item {
                Text("ค้นหาจากชื่อ", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("displayName") }
                    )
                    Button(onClick = { vm.search(search) }, enabled = search.isNotBlank()) { Text("ค้น") }
                }
            }
            items(hits, key = { it.uid }) { hit ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(hit.displayName, style = MaterialTheme.typography.titleSmall)
                            Text(hit.uid.take(12) + "…", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { vm.addByUid(hit.uid) }) { Text("เพิ่ม") }
                    }
                }
            }
            item { Text("คำขอเข้ามา", style = MaterialTheme.typography.titleMedium) }
            if (incoming.isEmpty()) {
                item { Text("ยังไม่มีคำขอ", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            items(incoming, key = { it.id }) { req ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(req.fromName.ifBlank { req.from.take(8) })
                        Text(req.from, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.accept(req) }) { Text("รับ") }
                            OutlinedButton(onClick = { vm.reject(req) }) { Text("ปฏิเสธ") }
                        }
                    }
                }
            }
            item { Text("เพื่อนของคุณ", style = MaterialTheme.typography.titleMedium) }
            if (friends.isEmpty()) {
                item { Text("ยังไม่มีเพื่อน", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            items(friends, key = { it.uid }) { f ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(f.displayName)
                            Text(f.uid.take(12) + "…", style = MaterialTheme.typography.bodySmall)
                        }
                        OutlinedButton(onClick = { onOpenChat(f.uid, f.displayName) }) { Text("แชท") }
                    }
                }
            }
            message?.let { item { Text(it, color = MaterialTheme.colorScheme.primary) } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
