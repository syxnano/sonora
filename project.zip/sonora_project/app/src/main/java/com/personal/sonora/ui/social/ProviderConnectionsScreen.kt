package com.personal.sonora.ui.social

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.BuildConfig
import com.personal.sonora.data.providers.ProviderConnectionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProviderCard(
    val id: String,
    val title: String,
    val subtitle: String,
    val openUrl: String,
    val canMarkConnected: Boolean
)

@HiltViewModel
class ProviderConnectionsViewModel @Inject constructor(
    private val repo: ProviderConnectionRepository
) : ViewModel() {
    val connections = repo.observe().catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setConnected(provider: String, handle: String, connected: Boolean) = viewModelScope.launch {
        runCatching { repo.setConnection(provider, handle, connected) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProviderConnectionsScreen(
    onBack: () -> Unit,
    onOpenProviderWeb: (platform: String, name: String, url: String) -> Unit,
    vm: ProviderConnectionsViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val connected by vm.connections.collectAsState()
    val connectedMap = remember(connected) { connected.associateBy { it.provider.lowercase() } }

    val cards = listOf(
        ProviderCard(
            id = "youtube",
            title = "YouTube",
            subtitle = "ค้นหา + เล่นในแอปด้วย YouTube Data API และ IFrame Player (ไม่ต้อง OAuth สำหรับค้น/เล่น)",
            openUrl = "https://www.youtube.com",
            canMarkConnected = true
        ),
        ProviderCard(
            id = "tiktok",
            title = "TikTok",
            subtitle = "เล่นด้วย Official Embed • ส่ง DM อัตโนมัติทำไม่ได้ • Login Kit key: " +
                if (BuildConfig.TIKTOK_CLIENT_KEY.isNotBlank()) "ตั้งแล้ว" else "ยังไม่ตั้ง",
            openUrl = "https://www.tiktok.com/login",
            canMarkConnected = true
        ),
        ProviderCard(
            id = "x",
            title = "X (Twitter)",
            subtitle = "เปิด Explore / Messages ในเบราว์เซอร์ในแอป • OAuth token แลกฝั่ง server เท่านั้น • Client ID: " +
                if (BuildConfig.X_CLIENT_ID.isNotBlank()) "ตั้งแล้ว" else "ยังไม่ตั้ง",
            openUrl = "https://x.com/explore",
            canMarkConnected = true
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("เชื่อมบริการ") },
                navigationIcon = { TextButton(onClick = onBack) { Text("กลับ") } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Sonora ใช้ API/Embed ทางการเท่านั้น — ไม่เก็บ client secret ใน APK และไม่ส่ง TikTok DM ปลอม",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(cards, key = { it.id }) { card ->
                val state = connectedMap[card.id]
                val isOn = state?.connected == true
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(card.title, style = MaterialTheme.typography.titleMedium)
                        Text(card.subtitle, style = MaterialTheme.typography.bodySmall)
                        Text(
                            if (isOn) "สถานะ: เชื่อมแล้ว (${state?.handle.orEmpty().ifBlank { "—" }})"
                            else "สถานะ: ยังไม่เชื่อม",
                            color = if (isOn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                onOpenProviderWeb(card.id, card.title, card.openUrl)
                            }) { Text("เปิดในแอป") }
                            OutlinedButton(onClick = {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(card.openUrl)))
                            }) { Text("เปิดภายนอก") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (card.canMarkConnected) {
                                if (!isOn) {
                                    Button(onClick = {
                                        vm.setConnected(card.id, "user", true)
                                    }) { Text("ทำเครื่องหมายว่าเชื่อมแล้ว") }
                                } else {
                                    OutlinedButton(onClick = {
                                        vm.setConnected(card.id, state?.handle.orEmpty(), false)
                                    }) { Text("ยกเลิกการเชื่อม") }
                                }
                            }
                        }
                    }
                }
            }
            item {
                Text(
                    "หมายเหตุ TikTok: scope portability เป็นการส่งออกข้อมูล DM ไม่ใช่ API ส่งข้อความ — ปุ่มส่งจะพาไป TikTok ให้ส่งเอง",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
