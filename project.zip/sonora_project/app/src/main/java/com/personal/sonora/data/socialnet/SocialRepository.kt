package com.personal.sonora.data.socialnet

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SocialRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore
) {
    data class FriendRequest(
        val id: String,
        val from: String,
        val to: String,
        val fromName: String = "",
        val status: String = "pending"
    )

    data class Friend(
        val uid: String,
        val displayName: String,
        val photoUrl: String = ""
    )

    data class UserHit(
        val uid: String,
        val displayName: String,
        val email: String = ""
    )

    suspend fun ensureProfile(displayName: String = auth.currentUser?.displayName ?: "Sonora User") {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (!snap.exists()) {
            ref.set(
                mapOf(
                    "uid" to uid,
                    "displayName" to displayName,
                    "email" to (auth.currentUser?.email ?: ""),
                    "photoUrl" to (auth.currentUser?.photoUrl?.toString() ?: ""),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    suspend fun sendFriendRequest(toUid: String) {
        val from = auth.currentUser?.uid ?: error("Not signed in")
        val clean = toUid.trim()
        require(clean.isNotBlank() && clean != from) { "UID ไม่ถูกต้อง" }
        val myName = auth.currentUser?.displayName
            ?: auth.currentUser?.email?.substringBefore("@")
            ?: "Sonora User"
        db.collection("friendRequests").add(
            mapOf(
                "from" to from,
                "to" to clean,
                "fromName" to myName,
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun acceptFriendRequest(requestId: String, fromUid: String) {
        val me = auth.currentUser?.uid ?: error("Not signed in")
        val batch = db.batch()
        batch.set(
            db.collection("friends").document("$me:$fromUid"),
            mapOf("a" to me, "b" to fromUid, "createdAt" to FieldValue.serverTimestamp())
        )
        batch.set(
            db.collection("friends").document("$fromUid:$me"),
            mapOf("a" to fromUid, "b" to me, "createdAt" to FieldValue.serverTimestamp())
        )
        batch.update(db.collection("friendRequests").document(requestId), "status", "accepted")
        batch.commit().await()
    }

    suspend fun rejectFriendRequest(requestId: String) {
        val me = auth.currentUser?.uid ?: error("Not signed in")
        val ref = db.collection("friendRequests").document(requestId)
        val snap = ref.get().await()
        require(snap.getString("to") == me) { "ไม่ใช่คำขอของคุณ" }
        ref.update("status", "rejected").await()
    }

    fun observeIncomingRequests(): Flow<List<FriendRequest>> = callbackFlow {
        var reg: ListenerRegistration? = null
        fun restart() {
            reg?.remove(); reg = null
            val me = auth.currentUser?.uid
            if (me == null) {
                trySend(emptyList()); return
            }
            reg = db.collection("friendRequests")
                .whereEqualTo("to", me)
                .whereEqualTo("status", "pending")
                .addSnapshotListener { snap, err ->
                    if (err != null) {
                        trySend(emptyList()); return@addSnapshotListener
                    }
                    trySend(
                        snap?.documents.orEmpty().map {
                            FriendRequest(
                                id = it.id,
                                from = it.getString("from").orEmpty(),
                                to = it.getString("to").orEmpty(),
                                fromName = it.getString("fromName").orEmpty(),
                                status = it.getString("status") ?: "pending"
                            )
                        }
                    )
                }
        }
        val authListener = FirebaseAuth.AuthStateListener { restart() }
        auth.addAuthStateListener(authListener)
        restart()
        awaitClose {
            auth.removeAuthStateListener(authListener)
            reg?.remove()
        }
    }

    fun observeFriends(): Flow<List<Friend>> = callbackFlow {
        var reg: ListenerRegistration? = null
        fun restart() {
            reg?.remove(); reg = null
            val me = auth.currentUser?.uid
            if (me == null) {
                trySend(emptyList()); return
            }
            reg = db.collection("friends")
                .whereEqualTo("a", me)
                .addSnapshotListener { snap, err ->
                    if (err != null) {
                        trySend(emptyList()); return@addSnapshotListener
                    }
                    trySend(
                        snap?.documents.orEmpty().mapNotNull { d ->
                            val other = d.getString("b") ?: return@mapNotNull null
                            Friend(uid = other, displayName = other.take(8))
                        }
                    )
                }
        }
        val authListener = FirebaseAuth.AuthStateListener { restart() }
        auth.addAuthStateListener(authListener)
        restart()
        awaitClose {
            auth.removeAuthStateListener(authListener)
            reg?.remove()
        }
    }

    /** Best-effort name resolution for friend list (safe empty on error). */
    suspend fun resolveDisplayName(uid: String): String {
        return runCatching {
            db.collection("users").document(uid).get().await().getString("displayName")
                ?: uid.take(8)
        }.getOrDefault(uid.take(8))
    }

    suspend fun searchUsers(query: String, limit: Int = 20): List<UserHit> {
        val q = query.trim()
        if (q.isBlank()) return emptyList()
        val me = auth.currentUser?.uid
        // Prefix search on displayName (requires exact case match for simple client query)
        val snap = db.collection("users")
            .orderBy("displayName")
            .startAt(q)
            .endAt(q + "\uf8ff")
            .limit(limit.toLong())
            .get()
            .await()
        return snap.documents.mapNotNull { d ->
            val uid = d.getString("uid") ?: d.id
            if (uid == me) return@mapNotNull null
            UserHit(
                uid = uid,
                displayName = d.getString("displayName") ?: uid.take(8),
                email = d.getString("email").orEmpty()
            )
        }
    }

    suspend fun sendDirectMessage(toUid: String, text: String) {
        val from = auth.currentUser?.uid ?: error("Not signed in")
        require(text.isNotBlank())
        val chatId = listOf(from, toUid).sorted().joinToString("_")
        db.collection("dm").document(chatId).collection("messages").add(
            mapOf(
                "from" to from,
                "to" to toUid,
                "text" to text.trim(),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }
}
