package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

/**
 * X (Twitter) boundary connector.
 * Client holds only X_CLIENT_ID. Token exchange must stay server-side.
 * In-app experience opens official X web surfaces (Explore / Messages).
 */
class XConnector : SonoraConnector {
    override val platform = Platform.X

    override suspend fun capabilities() = listOf(
        CapabilityStatus(Capability.READ_PROFILE, CapabilityState.NEEDS_PERMISSION, "OAuth 2.0 user context + server token exchange"),
        CapabilityStatus(Capability.READ_FEED, CapabilityState.NEEDS_PERMISSION, "X API access/plan"),
        CapabilityStatus(Capability.READ_MEDIA, CapabilityState.NEEDS_PERMISSION, "Post/media API access"),
        CapabilityStatus(Capability.READ_MESSAGES, CapabilityState.NEEDS_PERMISSION, "DM read requires elevated API access"),
        CapabilityStatus(Capability.SEND_MESSAGE, CapabilityState.NEEDS_PERMISSION, "DM write requires elevated API access"),
        CapabilityStatus(Capability.FOLLOW, CapabilityState.NEEDS_PERMISSION, "User-context authorization"),
        CapabilityStatus(Capability.LIKE, CapabilityState.NEEDS_PERMISSION, "User-context authorization"),
        CapabilityStatus(Capability.EMBED_PLAYBACK, CapabilityState.SUPPORTED, "Open official X web surfaces in-app")
    )

    override suspend fun connect() = Result.success(Unit)
    override suspend fun disconnect() = Result.success(Unit)
    override suspend fun refresh() = Result.success(Unit)
}
