package com.personal.sonora.ui.social

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.feed.FeedRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SocialHomeViewModel @Inject constructor(private val repo: FeedRepository) : ViewModel() {
    val posts: StateFlow<List<FeedRepository.SonoraPost>> = repo.observePosts().catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun post(text: String) = viewModelScope.launch { runCatching { repo.createPost(text) } }
}

@Composable
fun SocialHomeScreen(
    onSearch: (String) -> Unit,
    onMusic: () -> Unit,
    onYouTube: () -> Unit,
    onTikTok: () -> Unit,
    onX: () -> Unit,
    onFriends: () -> Unit,
    onChats: () -> Unit,
    onConnections: () -> Unit = {},
    onJoinRoom: (String) -> Unit = {},
    roomCode: String? = null,
    peerCount: Int = 0,
    onShareRoom: () -> Unit = {},
    vm: SocialHomeViewModel = hiltViewModel()
) {
    var query by remember { mutableStateOf("") }
    var post by remember { mutableStateOf("") }
    var joinCode by remember { mutableStateOf("") }
    val posts by vm.posts.collectAsState()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text("Sonora", style = MaterialTheme.typography.headlineLarge)
            Text(
                "Social + Media + Music + Watch/Listen Together + DM",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                query,
                { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("ค้นหาวิดีโอ เพลง หรือคน") },
                trailingIcon = { Button(onClick = { onSearch(query) }) { Text("ค้นหา") } }
            )
        }
        item {
            Text("Services", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ServiceButton("Music", onMusic, Modifier.weight(1f))
                ServiceButton("YouTube", onYouTube, Modifier.weight(1f))
                ServiceButton("TikTok", onTikTok, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onX, modifier = Modifier.weight(1f)) { Text("Sonora X") }
                OutlinedButton(onClick = onConnections, modifier = Modifier.weight(1f)) { Text("เชื่อมบัญชี") }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ห้องดูด้วยกัน", style = MaterialTheme.typography.titleMedium)
                    if (roomCode != null) {
                        Text("รหัสห้อง: $roomCode • คนในห้อง ~$peerCount")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onShareRoom) { Text("แชร์ห้อง") }
                        }
                    } else {
                        Text("เปิดวิดีโอ/เพลงแล้วระบบจะสร้างรหัส 6 หลักให้อัตโนมัติ", style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedTextField(
                        joinCode,
                        { joinCode = it.filter(Char::isDigit).take(6) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("รหัส 6 หลักเพื่อเข้าห้อง") }
                    )
                    Button(
                        onClick = { onJoinRoom(joinCode); joinCode = "" },
                        enabled = joinCode.length == 6,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("เข้าห้อง") }
                }
            }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("โพสต์ของคุณ", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        post,
                        { post = it },
                        Modifier.fillMaxWidth(),
                        minLines = 2,
                        placeholder = { Text("กำลังคิดอะไรอยู่?") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { vm.post(post); post = "" },
                        enabled = post.isNotBlank()
                    ) { Text("โพสต์") }
                }
            }
        }
        item { Text("Feed", style = MaterialTheme.typography.titleLarge) }
        items(posts, key = { it.id }) { item ->
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Sonora • ${item.displayName}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(item.text)
                    Spacer(Modifier.height(6.dp))
                    Text("Sonora", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onFriends, modifier = Modifier.weight(1f)) { Text("เพื่อน") }
                OutlinedButton(onClick = onChats, modifier = Modifier.weight(1f)) { Text("ข้อความ") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ServiceButton(text: String, onClick: () -> Unit, modifier: Modifier) {
    ElevatedButton(onClick = onClick, modifier = modifier.height(54.dp)) { Text(text) }
}
