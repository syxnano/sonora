package com.personal.sonora.ui.social

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.personal.sonora.data.auth.AuthRepository
import com.personal.sonora.data.socialnet.SocialRepository
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onSignedIn: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }
    val socialRepo = remember { SocialRepository(com.google.firebase.auth.FirebaseAuth.getInstance(), com.google.firebase.firestore.FirebaseFirestore.getInstance()) }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    fun finishAuth() {
        scope.launch {
            runCatching { socialRepo.ensureProfile() }
            loading = false
            onSignedIn()
        }
    }

    fun validate(): Boolean {
        val e = email.trim()
        when {
            e.isBlank() -> { error = "กรุณากรอก Email"; return false }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches() -> { error = "รูปแบบ Email ไม่ถูกต้อง"; return false }
            password.isBlank() -> { error = "กรุณากรอกรหัสผ่าน"; return false }
            password.length < 6 -> { error = "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร"; return false }
        }
        error = null
        return true
    }

    val googleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (loading) return@rememberLauncherForActivityResult
        try {
            val data = result.data
            val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.result
            loading = true
            repo.signInWithGoogle(account) { r ->
                if (r.isSuccess) finishAuth() else loading = false.also { error = r.exceptionOrNull()?.message ?: "Google Sign-In ไม่สำเร็จ" }
            }
        } catch (e: Exception) {
            loading = false
            error = e.message ?: "Google Sign-In ไม่สำเร็จ"
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Sonora", style = MaterialTheme.typography.displaySmall)
        Text("เข้าสู่โลกเพลง วิดีโอ และเพื่อนของคุณ")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = email, onValueChange = { email = it; error = null },
            modifier = Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), enabled = !loading
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it; error = null },
            modifier = Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), enabled = !loading
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    if (!validate()) return@Button
                    loading = true
                    repo.signIn(email, password) { r ->
                        if (r.isSuccess) finishAuth() else { loading = false; error = r.exceptionOrNull()?.message ?: "เข้าสู่ระบบไม่สำเร็จ" }
                    }
                }, enabled = !loading, modifier = Modifier.weight(1f)
            ) { Text("เข้าสู่ระบบ") }
            OutlinedButton(
                onClick = {
                    if (!validate()) return@OutlinedButton
                    loading = true
                    repo.signUp(email, password) { r ->
                        if (r.isSuccess) finishAuth() else { loading = false; error = r.exceptionOrNull()?.message ?: "สมัครไม่สำเร็จ" }
                    }
                }, enabled = !loading, modifier = Modifier.weight(1f)
            ) { Text("สมัคร") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                try { loading = true; googleLauncher.launch(repo.googleClient().signInIntent) }
                catch (e: Exception) { loading = false; error = e.message ?: "Google Sign-In ยังไม่ได้ตั้งค่า" }
            }, enabled = !loading, modifier = Modifier.fillMaxWidth()
        ) { Text("Continue with Google") }
        if (loading) {
            Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(24.dp))
    }
}
