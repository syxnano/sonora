package com.personal.sonora.ui.dm

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.dm.DirectMessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class DmChatHeadViewModel @Inject constructor(repo: DirectMessageRepository) : ViewModel() {
    val conversations: StateFlow<List<DirectMessageRepository.Conversation>> =
        repo.observeConversations().catch { emit(emptyList()) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

@Composable
fun DmChatHeadOverlay(onOpen: (String, String) -> Unit, vm: DmChatHeadViewModel = hiltViewModel()) {
    val conversations by vm.conversations.collectAsState()
    val head = conversations.firstOrNull { it.unread > 0 } ?: return
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
        Box(
            Modifier.padding(end = 16.dp, bottom = 84.dp).size(58.dp).clip(CircleShape)
                .background(androidx.compose.material3.MaterialTheme.colorScheme.primary)
                .clickable { onOpen(head.otherUid, head.otherName) },
            contentAlignment = Alignment.Center
        ) {
            Text(head.otherName.take(1).uppercase())
        }
        Box(
            Modifier.padding(end = 10.dp, bottom = 126.dp).size(22.dp).clip(CircleShape)
                .background(androidx.compose.material3.MaterialTheme.colorScheme.error),
            contentAlignment = Alignment.Center
        ) { Text(head.unread.coerceAtMost(99).toString(), color = androidx.compose.material3.MaterialTheme.colorScheme.onError) }
    }
}
