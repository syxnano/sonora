package com.personal.sonora.ui.sonora

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.catalog.MusicCatalog
import com.personal.sonora.data.catalog.SearchType
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.product.*
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.morning.MorningSongScheduler
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SonoraViewModel @Inject constructor(
    val products: ProductRepository,
    private val catalog: MusicCatalog,
    private val agent: TasteAgent,
    private val profile: ProfileRepository,
    private val scheduler: MorningSongScheduler,
    private val publicCards: PublicCardRepository
) : ViewModel() {
    val cards = products.cards
    val taste = products.taste
    val morning = products.morning
    private val _agentTracks = MutableStateFlow<List<Track>>(emptyList())
    val agentTracks = _agentTracks.asStateFlow()
    private val _agentMessage = MutableStateFlow("")
    val agentMessage = _agentMessage.asStateFlow()

    fun createCard(track: Track, message: String, mood: String) = viewModelScope.launch {
        products.createCard(track, message, mood)
    }
    fun publishCard(card: MusicCard, onDone: (String?) -> Unit) = viewModelScope.launch {
        runCatching { publicCards.publish(card) }
            .onSuccess { onDone(it) }
            .onFailure { onDone(null) }
    }
    fun deleteCard(id: String) = viewModelScope.launch { products.deleteCard(id) }
    fun saveTaste(value: TasteMemory) = viewModelScope.launch { products.saveTaste(value) }
    fun clearTaste() = viewModelScope.launch { products.clearTaste() }
    fun feedback(track: Track, liked: Boolean) = viewModelScope.launch { products.recordTrackFeedback(track, liked) }
    fun saveMorning(value: MorningSong) = viewModelScope.launch {
        products.saveMorning(value)
        if (value.enabled) scheduler.schedule(value.hour, value.minute) else scheduler.cancel()
    }
    fun askAgent(text: String) = viewModelScope.launch {
        _agentMessage.value = "กำลังค้นเพลงที่มีอยู่จริง…"
        val result = catalog.search(text, SearchType.SONGS, 30)
        val candidates = result.tracks
        _agentTracks.value = agent.rank(text, taste.first(), candidates).trackIds.mapNotNull { id -> candidates.firstOrNull { it.id == id } }
        _agentMessage.value = agent.rank(text, taste.first(), candidates).explanation
    }
}

@Composable
fun SonoraScreen(
    playerController: PlayerController,
    onOpenRoom: () -> Unit,
    viewModel: SonoraViewModel = hiltViewModel()
) {
    val cards by viewModel.cards.collectAsState(emptyList())
    val taste by viewModel.taste.collectAsState(TasteMemory())
    val morning by viewModel.morning.collectAsState(MorningSong())
    val agentTracks by viewModel.agentTracks.collectAsState()
    val agentMessage by viewModel.agentMessage.collectAsState()
    val playerState by playerController.state.collectAsState()
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var agentText by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Track?>(null) }
    var message by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("") }
    var liked by remember(taste) { mutableStateOf(taste.likedArtists.joinToString(", ")) }
    var disliked by remember(taste) { mutableStateOf(taste.dislikedArtists.joinToString(", ")) }
    var languages by remember(taste) { mutableStateOf(taste.likedLanguages.joinToString(", ")) }

    Column(Modifier.fillMaxSize().background(SpotifyBlack)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Sonora", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenRoom) { Text("ห้องฟังร่วม", color = SpotifyGreen) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Cards", "Morning", "Taste AI").forEachIndexed { i, label ->
                Text(label, color = if (tab == i) SpotifyGreen else SpotifySecondary, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.clickable { tab = i }.padding(12.dp))
            }
        }
        when (tab) {
            0 -> CardsTab(cards, playerController, playerState.currentTrack, onCreate = { selected = it }, onShare = { card ->
                viewModel.publishCard(card) { publicId ->
                    if (publicId == null) {
                        android.widget.Toast.makeText(context, "แชร์ Card ได้เฉพาะเพลง YouTube ที่มี video ID", android.widget.Toast.LENGTH_LONG).show()
                        return@publishCard
                    }
                    val cardUrl = "https://sonora-9d7f4.web.app/card/$publicId"
                    val text = buildString {
                        append("🎵 Music Card จาก Sonora\n")
                        append("${card.track.title} — ${card.track.artist}\n")
                        if (card.message.isNotBlank()) append("“${card.message}”\n")
                        append(cardUrl)
                    }
                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "ส่ง Music Card"))
                }
            }, onDelete = viewModel::deleteCard)
            1 -> MorningTab(morning, onSave = { viewModel.saveMorning(it) })
            2 -> AgentTab(agentText, { agentText = it }, agentMessage, agentTracks, playerController, { viewModel.askAgent(agentText) }, liked, disliked, languages, { liked = it }, { disliked = it }, { languages = it }, { viewModel.saveTaste(TasteMemory(liked.split(",").map(String::trim).filter(String::isNotBlank), disliked.split(",").map(String::trim).filter(String::isNotBlank), languages.split(",").map(String::trim).filter(String::isNotBlank), learningEnabled = taste.learningEnabled)) }, taste.learningEnabled, { viewModel.saveTaste(taste.copy(learningEnabled = it)) }, { viewModel.clearTaste() }, { t, like -> viewModel.feedback(t, like) })
        }
    }
    if (selected != null) {
        AlertDialog(onDismissRequest = { selected = null }, title = { Text("สร้าง Music Card") }, text = {
            Column {
                Text("${selected!!.title} — ${selected!!.artist}")
                OutlinedTextField(message, { message = it }, label = { Text("ข้อความ") })
                OutlinedTextField(mood, { mood = it }, label = { Text("Mood (ถ้ามี)") })
            }
        }, confirmButton = { TextButton(onClick = { viewModel.createCard(selected!!, message, mood); selected = null; message = "" }) { Text("สร้าง") } }, dismissButton = { TextButton(onClick = { selected = null }) { Text("ยกเลิก") } })
    }
}

@Composable private fun CardsTab(cards: List<MusicCard>, player: PlayerController, currentTrack: Track?, onCreate: (Track) -> Unit, onShare: (MusicCard) -> Unit, onDelete: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Text("เพลงที่มีความหมาย", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(vertical = 12.dp))
            Button(onClick = { currentTrack?.let(onCreate) }, enabled = currentTrack != null, colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)) { Text("สร้าง Card จากเพลงที่กำลังฟัง", color = Color.Black) }
        }
        if (cards.isEmpty()) item { Text("สร้าง Card จากเพลงที่คุณเลือก แล้วส่งให้คนที่อยากให้ฟัง", color = SpotifySecondary) }
        items(cards, key = { it.id }) { card ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text(card.track.title, fontWeight = FontWeight.Bold)
                    Text(card.track.artist, color = Color.Gray)
                    if (card.message.isNotBlank()) Text("“${card.message}”", modifier = Modifier.padding(top = 6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { player.play(card.track) }, colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)) { Text("ฟัง", color = Color.Black) }
                        IconButton(onClick = { onShare(card) }) { Icon(Icons.Default.Share, null) }
                        IconButton(onClick = { onDelete(card.id) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
}

@Composable private fun MorningTab(value: MorningSong, onSave: (MorningSong) -> Unit) {
    var enabled by remember(value) { mutableStateOf(value.enabled) }
    var hour by remember(value) { mutableStateOf(value.hour.toString()) }
    var minute by remember(value) { mutableStateOf(value.minute.toString().padStart(2, '0')) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Icon(Icons.Default.NotificationsActive, null, tint = SpotifyGreen, modifier = Modifier.size(36.dp))
        Text("Morning Song", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("หนึ่งเพลงทุกเช้า เพื่อให้เพลงกลายเป็นบทสนทนา", color = SpotifySecondary, modifier = Modifier.padding(vertical = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Text("เปิดใช้งาน", color = Color.White, modifier = Modifier.weight(1f)); Switch(enabled, { enabled = it }) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, label = { Text("ชั่วโมง") }, modifier = Modifier.weight(1f))
            OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, label = { Text("นาที") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSave(MorningSong(enabled, hour.toIntOrNull()?.coerceIn(0,23) ?: 7, minute.toIntOrNull()?.coerceIn(0,59) ?: 0)) }, colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)) { Text("บันทึก", color = Color.Black) }
    }
}

@Composable private fun AgentTab(text: String, setText: (String) -> Unit, result: String, tracks: List<Track>, player: PlayerController, ask: () -> Unit, liked: String, disliked: String, languages: String, setLiked: (String) -> Unit, setDisliked: (String) -> Unit, setLanguages: (String) -> Unit, save: () -> Unit, learning: Boolean, setLearning: (Boolean) -> Unit, clearTaste: () -> Unit, feedback: (Track, Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Icon(Icons.Default.AutoAwesome, null, tint = SpotifyGreen, modifier = Modifier.size(34.dp))
            Text("AI Taste Agent", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("บอกสิ่งที่อยากฟัง แล้ว Sonora จะค้นเพลงจริงก่อนจัดอันดับ", color = SpotifySecondary)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, setText, modifier = Modifier.fillMaxWidth(), label = { Text("เช่น วันนี้สอบ อยากฟังไทย ๆ แต่ไม่เศร้า") })
            Button(onClick = ask, enabled = text.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen), modifier = Modifier.padding(top = 8.dp)) { Text("ค้นหาให้ฉัน", color = Color.Black) }
            if (result.isNotBlank()) Text(result, color = Color.White, modifier = Modifier.padding(vertical = 10.dp))
            Text("Taste Memory", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            OutlinedTextField(liked, setLiked, modifier = Modifier.fillMaxWidth(), label = { Text("ศิลปินที่ชอบ (คั่นด้วย ,)") })
            OutlinedTextField(disliked, setDisliked, modifier = Modifier.fillMaxWidth(), label = { Text("ศิลปินที่ไม่ชอบ") })
            OutlinedTextField(languages, setLanguages, modifier = Modifier.fillMaxWidth(), label = { Text("ภาษา") })
            Row(verticalAlignment = Alignment.CenterVertically) { Text("อนุญาตให้ Sonora เรียนรู้จากการใช้งาน", color = Color.White, modifier = Modifier.weight(1f)); Switch(learning, setLearning) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = save) { Text("บันทึก") }
                TextButton(onClick = clearTaste) { Text("ล้าง Taste Memory") }
            }
            Spacer(Modifier.height(8.dp))
        }
        items(tracks, key = { it.id }) { t ->
            Row(Modifier.fillMaxWidth().clickable { player.play(t) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(t.title, color = Color.White); Text(t.artist, color = SpotifySecondary) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("👎", color = Color.White, modifier = Modifier.clickable { feedback(t, false) })
                    Text("👍", color = SpotifyGreen, modifier = Modifier.clickable { feedback(t, true) })
                }
            }
        }
    }
}
