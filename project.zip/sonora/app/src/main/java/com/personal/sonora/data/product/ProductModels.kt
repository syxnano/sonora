package com.personal.sonora.data.product

import com.personal.sonora.data.catalog.Track
import kotlinx.serialization.Serializable

@Serializable
data class MusicCard(
    val id: String,
    val track: Track,
    val message: String = "",
    val mood: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class TasteMemory(
    val likedArtists: List<String> = emptyList(),
    val dislikedArtists: List<String> = emptyList(),
    val likedLanguages: List<String> = emptyList(),
    val moodTags: List<String> = emptyList(),
    val explicitNotes: List<String> = emptyList(),
    val likedTrackIds: List<String> = emptyList(),
    val dislikedTrackIds: List<String> = emptyList(),
    val learningEnabled: Boolean = true
)

@Serializable
data class MorningSong(
    val enabled: Boolean = false,
    val hour: Int = 7,
    val minute: Int = 0,
    val source: String = "friend",
    val message: String = "เพลงเช้าของมึงวันนี้"
)

@Serializable
data class AgentRequest(
    val text: String,
    val tracks: List<Track> = emptyList()
)

@Serializable
data class AgentResult(
    val trackIds: List<String>,
    val explanation: String,
    val followUp: String? = null
)
