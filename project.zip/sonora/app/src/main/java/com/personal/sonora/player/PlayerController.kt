package com.personal.sonora.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.resolver.YouTubeResolver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

data class PlayerUiState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val codec: String? = null,
    val bitrate: Int = 0,
    val error: String? = null
)

@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val resolver: YouTubeResolver
) {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    // Any uncaught error inside a player coroutine is shown on screen instead of killing the app.
    private val errorHandler = CoroutineExceptionHandler { _, e ->
        _state.value = _state.value.copy(
            error = "Player error: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
        )
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + errorHandler)

    private val queue = mutableListOf<Track>()
    private var currentIndex = 0
    private var pendingItem: MediaItem? = null
    private var retriedTrackId: String? = null

    fun connect() {
        if (controller != null || controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(playerListener)
                pendingItem?.let { item ->
                    controller?.setMediaItem(item)
                    controller?.prepare()
                    controller?.play()
                    pendingItem = null
                }
                syncState()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = "Player service error: ${e.message}")
            }
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    fun play(track: Track, newQueue: List<Track> = listOf(track), startIndex: Int = 0) {
        queue.clear()
        queue.addAll(newQueue)
        currentIndex = startIndex.coerceIn(0, queue.lastIndex.coerceAtLeast(0))
        retriedTrackId = null
        scope.launch { loadAndPlay(queue[currentIndex]) }
    }

    fun playNext(track: Track) {
        val insertAt = (currentIndex + 1).coerceAtMost(queue.size)
        queue.add(insertAt, track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun addToQueue(track: Track) {
        queue.add(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun skipNext() {
        if (currentIndex < queue.lastIndex) {
            currentIndex++
            scope.launch { loadAndPlay(queue[currentIndex]) }
        }
    }

    fun skipPrevious() {
        if (controller?.currentPosition ?: 0 > 3000) {
            controller?.seekTo(0)
        } else if (currentIndex > 0) {
            currentIndex--
            scope.launch { loadAndPlay(queue[currentIndex]) }
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
        _state.value = _state.value.copy(shuffle = enabled)
    }

    fun cycleRepeat() {
        val next = when (controller?.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller?.repeatMode = next
        _state.value = _state.value.copy(repeatMode = next)
    }

    fun clearQueue() {
        queue.clear()
        currentIndex = 0
        controller?.stop()
        _state.value = PlayerUiState()
    }

    fun reorderQueue(from: Int, to: Int) {
        if (from in queue.indices && to in queue.indices) {
            val item = queue.removeAt(from)
            queue.add(to, item)
            if (currentIndex == from) currentIndex = to
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun removeFromQueue(index: Int) {
        if (index in queue.indices) {
            queue.removeAt(index)
            if (index < currentIndex) currentIndex--
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    private suspend fun loadAndPlay(track: Track) {
        try {
            loadAndPlayInner(track)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            _state.value = _state.value.copy(
                isPlaying = false,
                error = "Cannot play: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
            )
        }
    }

    private suspend fun loadAndPlayInner(track: Track) {
        _state.value = _state.value.copy(
            currentTrack = track,
            queue = queue.toList(),
            queueIndex = currentIndex,
            error = null,
            isPlaying = false
        )
        val resolved = resolver.resolve(track, preferHighest = true)
        if (resolved == null) {
            _state.value = _state.value.copy(
                error = resolver.lastError ?: "Could not resolve stream"
            )
            return
        }
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .apply { track.coverUrl?.let { setArtworkUri(android.net.Uri.parse(it)) } }
            .build()
        val mediaItem = MediaItem.Builder()
            .setUri(resolved.streamUrl)
            .setMediaId(track.id)
            .setMediaMetadata(metadata)
            .build()
        _state.value = _state.value.copy(
            codec = resolved.codec,
            bitrate = resolved.bitrate
        )
        val c = controller
        if (c == null) {
            // Service connection not ready yet: play as soon as it connects.
            pendingItem = mediaItem
            connect()
        } else {
            c.setMediaItem(mediaItem)
            c.prepare()
            c.play()
        }
        // Prefetch next 2
        prefetchNext()
    }

    private fun prefetchNext() {
        val upcoming = (1..2).mapNotNull { queue.getOrNull(currentIndex + it) }
        if (upcoming.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            for (t in upcoming) {
                try {
                    resolver.resolve(t, preferHighest = true)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // prefetch is best-effort
                }
            }
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val track = _state.value.currentTrack ?: return
            if (retriedTrackId != track.id) {
                // Stream URLs expire or get rejected: drop the cache and resolve once more.
                retriedTrackId = track.id
                scope.launch {
                    resolver.invalidate(track.id)
                    loadAndPlay(track)
                }
            } else {
                val detail = error.cause?.message ?: error.message ?: ""
                _state.value = _state.value.copy(
                    isPlaying = false,
                    error = "Playback failed (${error.errorCodeName}) $detail".take(160)
                )
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                skipNext()
            }
            syncState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncState()
        }
    }

    private fun syncState() {
        val c = controller ?: return
        _state.value = _state.value.copy(
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode
        )
    }

    fun updatePosition() {
        controller?.let {
            _state.value = _state.value.copy(
                positionMs = it.currentPosition,
                durationMs = it.duration.coerceAtLeast(0)
            )
        }
    }
}
