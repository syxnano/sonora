package com.personal.sonora.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.resolver.YouTubeResolver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

data class PlayerUiState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val codec: String? = null,
    val bitrate: Int = 0,
    val error: String? = null
)

@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val resolver: YouTubeResolver
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val queue = mutableListOf<Track>()
    private var currentIndex = 0

    fun connect() {
        if (controller != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(playerListener)
                syncState()
            } catch (e: Exception) {
                // ignore
            }
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
    }

    fun play(track: Track, newQueue: List<Track> = listOf(track), startIndex: Int = 0) {
        queue.clear()
        queue.addAll(newQueue)
        currentIndex = startIndex.coerceIn(0, queue.lastIndex.coerceAtLeast(0))
        scope.launch { loadAndPlay(queue[currentIndex]) }
    }

    fun playNext(track: Track) {
        val insertAt = (currentIndex + 1).coerceAtMost(queue.size)
        queue.add(insertAt, track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun addToQueue(track: Track) {
        queue.add(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun togglePlayPause() {
        controller?.let {
            if (it.isPlaying) it.pause() else it.play()
        }
    }

    fun skipNext() {
        if (currentIndex < queue.lastIndex) {
            currentIndex++
            scope.launch { loadAndPlay(queue[currentIndex]) }
        }
    }

    fun skipPrevious() {
        if (controller?.currentPosition ?: 0 > 3000) {
            controller?.seekTo(0)
        } else if (currentIndex > 0) {
            currentIndex--
            scope.launch { loadAndPlay(queue[currentIndex]) }
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    fun setShuffle(enabled: Boolean) {
        controller?.shuffleModeEnabled = enabled
        _state.value = _state.value.copy(shuffle = enabled)
    }

    fun cycleRepeat() {
        val next = when (controller?.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        controller?.repeatMode = next
        _state.value = _state.value.copy(repeatMode = next)
    }

    fun clearQueue() {
        queue.clear()
        currentIndex = 0
        controller?.stop()
        _state.value = PlayerUiState()
    }

    fun reorderQueue(from: Int, to: Int) {
        if (from in queue.indices && to in queue.indices) {
            val item = queue.removeAt(from)
            queue.add(to, item)
            if (currentIndex == from) currentIndex = to
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun removeFromQueue(index: Int) {
        if (index in queue.indices) {
            queue.removeAt(index)
            if (index < currentIndex) currentIndex--
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    private suspend fun loadAndPlay(track: Track) {
        _state.value = _state.value.copy(
            currentTrack = track,
            queue = queue.toList(),
            queueIndex = currentIndex,
            error = null,
            isPlaying = false
        )
        val resolved = resolver.resolve(track, preferHighest = true)
        if (resolved == null) {
            _state.value = _state.value.copy(error = "Could not resolve stream")
            // Auto-skip
            if (currentIndex < queue.lastIndex) {
                currentIndex++
                loadAndPlay(queue[currentIndex])
            }
            return
        }
        val mediaItem = MediaItem.Builder()
            .setUri(resolved.streamUrl)
            .setMediaId(track.id)
            .setTag(track)
            .build()
        controller?.setMediaItem(mediaItem)
        controller?.prepare()
        controller?.play()
        _state.value = _state.value.copy(
            codec = resolved.codec,
            bitrate = resolved.bitrate,
            isPlaying = true
        )
        // Prefetch next 2
        prefetchNext()
    }

    private fun prefetchNext() {
        scope.launch(Dispatchers.IO) {
            for (i in 1..2) {
                val idx = currentIndex + i
                if (idx in queue.indices) {
                    resolver.resolve(queue[idx], preferHighest = true)
                }
            }
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                skipNext()
            }
            syncState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncState()
        }
    }

    private fun syncState() {
        val c = controller ?: return
        _state.value = _state.value.copy(
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode
        )
    }

    fun updatePosition() {
        controller?.let {
            _state.value = _state.value.copy(
                positionMs = it.currentPosition,
                durationMs = it.duration.coerceAtLeast(0)
            )
        }
    }
}
