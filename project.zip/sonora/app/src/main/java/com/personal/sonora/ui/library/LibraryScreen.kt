package com.personal.sonora.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.R
import com.personal.sonora.data.db.PlaylistEntity
import com.personal.sonora.data.playlist.PlaylistRepository
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.ConfirmDialog
import com.personal.sonora.ui.components.CoverArt
import com.personal.sonora.ui.components.NamePlaylistDialog
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repo: PlaylistRepository
) : ViewModel() {
    val playlists = repo.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<PlaylistEntity>())

    init {
        viewModelScope.launch { repo.ensureLikedSongs() }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch { repo.create(name) }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch { repo.rename(id, name) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}

@Composable
fun LibraryScreen(
    playerController: PlayerController,
    onOpenSettings: () -> Unit,
    onOpenPlaylist: (String) -> Unit,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val playlists by viewModel.playlists.collectAsState()
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<PlaylistEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<PlaylistEntity?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.nav_library), style = MaterialTheme.typography.headlineMedium)
            Row {
                IconButton(onClick = { showCreate = true }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                }
            }
        }
        LazyColumn {
            items(playlists, key = { it.id }) { pl ->
                var menuOpen by remember { mutableStateOf(false) }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenPlaylist(pl.id) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CoverArt(pl.coverUrl, size = 64.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(
                            if (pl.isLikedSongs) stringResource(R.string.liked_songs) else pl.name,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            if (pl.isLikedSongs) "Playlist" else "Playlist",
                            color = SpotifySecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (!pl.isLikedSongs) {
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = null, tint = SpotifySecondary)
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.rename_playlist)) },
                                    onClick = { menuOpen = false; renameTarget = pl }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.delete_playlist)) },
                                    onClick = { menuOpen = false; deleteTarget = pl }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        NamePlaylistDialog(
            title = stringResource(R.string.create_playlist),
            initial = "",
            onDismiss = { showCreate = false },
            onConfirm = { viewModel.createPlaylist(it); showCreate = false }
        )
    }
    renameTarget?.let { pl ->
        NamePlaylistDialog(
            title = stringResource(R.string.rename_playlist),
            initial = pl.name,
            onDismiss = { renameTarget = null },
            onConfirm = { viewModel.rename(pl.id, it); renameTarget = null }
        )
    }
    deleteTarget?.let { pl ->
        ConfirmDialog(
            title = stringResource(R.string.delete_playlist),
            message = "Delete \"${pl.name}\"? This cannot be undone.",
            confirmLabel = "Delete",
            onDismiss = { deleteTarget = null },
            onConfirm = { viewModel.delete(pl.id); deleteTarget = null }
        )
    }
}
