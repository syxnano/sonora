package com.personal.sonora.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.R
import com.personal.sonora.data.db.PlaylistDao
import com.personal.sonora.data.db.PlaylistEntity
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.CoverArt
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val playlistDao: PlaylistDao
) : ViewModel() {
    val playlists = playlistDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            if (playlistDao.getLikedSongs() == null) {
                playlistDao.upsert(
                    PlaylistEntity(
                        id = "liked_songs",
                        name = "Liked Songs",
                        isLikedSongs = true
                    )
                )
            }
        }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            playlistDao.upsert(
                PlaylistEntity(id = UUID.randomUUID().toString(), name = name)
            )
        }
    }
}

@Composable
fun LibraryScreen(
    playerController: PlayerController,
    onOpenSettings: () -> Unit,
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val playlists by viewModel.playlists.collectAsState()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.nav_library), style = MaterialTheme.typography.headlineMedium)
            Row {
                IconButton(onClick = { viewModel.createPlaylist("New playlist") }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                }
            }
        }
        LazyColumn {
            items(playlists) { pl ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CoverArt(pl.coverUrl, size = 64.dp)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(pl.name, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            if (pl.isLikedSongs) stringResource(R.string.liked_songs) else "Playlist",
                            color = SpotifySecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
