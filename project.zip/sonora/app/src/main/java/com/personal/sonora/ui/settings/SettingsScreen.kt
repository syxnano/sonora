package com.personal.sonora.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.R
import com.personal.sonora.data.db.ResolvedStreamDao
import com.personal.sonora.data.db.SeenTrackDao
import com.personal.sonora.data.settings.SettingsRepository
import com.personal.sonora.data.settings.StreamQuality
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val resolvedStreamDao: ResolvedStreamDao,
    private val seenTrackDao: SeenTrackDao
) : ViewModel() {
    val wifiQuality = settings.wifiQuality
    val mobileQuality = settings.mobileQuality
    val discoverCount = settings.discoverCount
    val crossfade = settings.crossfadeSec
    val normalization = settings.normalization

    fun setWifi(q: StreamQuality) = viewModelScope.launch { settings.setWifiQuality(q) }
    fun setMobile(q: StreamQuality) = viewModelScope.launch { settings.setMobileQuality(q) }
    fun setDiscover(n: Int) = viewModelScope.launch { settings.setDiscoverCount(n) }
    fun setCrossfade(s: Float) = viewModelScope.launch { settings.setCrossfadeSec(s) }
    fun setNorm(b: Boolean) = viewModelScope.launch { settings.setNormalization(b) }
    fun clearCache() = viewModelScope.launch { resolvedStreamDao.clearAll() }
    fun clearSeen() = viewModelScope.launch { seenTrackDao.clearAll() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val discover by viewModel.discoverCount.collectAsState(60)
    val crossfade by viewModel.crossfade.collectAsState(0f)

    Column(Modifier.fillMaxSize().background(SpotifyBlack)) {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = SpotifyBlack,
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White
            )
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(stringResource(R.string.discover_count), style = MaterialTheme.typography.titleMedium)
            Text("$discover", color = SpotifySecondary)
            Slider(
                value = discover.toFloat(),
                onValueChange = { viewModel.setDiscover(it.toInt()) },
                valueRange = 50f..100f,
                steps = 9
            )

            Text(stringResource(R.string.crossfade), style = MaterialTheme.typography.titleMedium)
            Text("${crossfade.toInt()} s", color = SpotifySecondary)
            Slider(
                value = crossfade,
                onValueChange = { viewModel.setCrossfade(it) },
                valueRange = 0f..12f
            )

            Text(
                stringResource(R.string.clear_cache),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .clickableSimple { viewModel.clearCache() }
            )
            Text(
                stringResource(R.string.clear_seen),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .clickableSimple { viewModel.clearSeen() }
            )

            Text(
                stringResource(R.string.legal_note),
                style = MaterialTheme.typography.bodySmall,
                color = SpotifySecondary,
                modifier = Modifier.padding(top = 24.dp)
            )
        }
    }
}

private fun Modifier.clickableSimple(onClick: () -> Unit): Modifier {
    return this.then(clickable(onClick = onClick))
}
