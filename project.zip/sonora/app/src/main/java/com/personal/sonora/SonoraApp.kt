package com.personal.sonora

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class SonoraApp : Application() {
    // Forces NewPipe init via AppModule
    @Inject lateinit var newPipeInit: Boolean
}
