package com.personal.sonora

import android.app.Application
import com.personal.sonora.di.NewPipeInit
import com.personal.sonora.util.CrashLog
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class SonoraApp : Application() {
    /**
     * Injecting this marker forces Hilt to create the NewPipeInit binding,
     * which runs NewPipe.init(...) in its provider.
     */
    @Inject lateinit var newPipeInit: NewPipeInit

    override fun onCreate() {
        // Install before anything else so even start-up crashes are captured.
        CrashLog.install(this)
        super.onCreate()
    }
}
