package com.personal.sonora.data.resolver

import com.personal.sonora.data.catalog.Track
import kotlin.math.abs
import kotlin.math.max

data class ScoredCandidate(
    val videoId: String,
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val score: Double
)

object StreamScoring {

    private val penaltyWords = listOf(
        "live", "cover", "remix", "slowed", "sped up", "reverb", "karaoke",
        "instrumental", "8d", "nightcore", "lyrics video", "reaction",
        "mix", "compilation", "playlist", "full album"
    )

    fun score(
        candidateTitle: String,
        candidateUploader: String,
        candidateDurationSec: Long,
        track: Track
    ): Double {
        var score = 0.0
        val targetDurationSec = if (track.durationMs > 0) track.durationMs / 1000.0 else 0.0

        // Duration match (strong)
        if (targetDurationSec > 0 && candidateDurationSec > 0) {
            val diff = abs(candidateDurationSec - targetDurationSec)
            val pct = diff / targetDurationSec
            when {
                diff <= 5 || pct <= 0.08 -> score += 40.0
                diff <= 15 || pct <= 0.15 -> score += 20.0
                candidateDurationSec > targetDurationSec + 60 -> score -= 30.0
            }
        }

        // Title / artist fuzzy similarity
        val normTitle = normalize(candidateTitle)
        val normTrackTitle = normalize(track.title)
        val normArtist = normalize(track.artist)
        val normUploader = normalize(candidateUploader)

        score += fuzzyScore(normTitle, normTrackTitle) * 25.0
        if (normTitle.contains(normArtist) || normUploader.contains(normArtist)) {
            score += 15.0
        }

        // Official / Topic channel boost
        when {
            candidateUploader.endsWith("- Topic", ignoreCase = true) -> score += 20.0
            candidateUploader.equals(track.artist, ignoreCase = true) -> score += 15.0
            candidateUploader.contains("VEVO", ignoreCase = true) -> score += 12.0
            candidateUploader.contains("Official", ignoreCase = true) -> score += 8.0
        }

        // Penalty words
        val originalHasPenalty = penaltyWords.any { normalize(track.title).contains(it) }
        if (!originalHasPenalty) {
            for (word in penaltyWords) {
                if (normTitle.contains(word)) {
                    score -= 25.0
                    break
                }
            }
        }

        // Prefer "official audio" / "audio" in title
        if (normTitle.contains("official audio") || normTitle.contains("audio")) {
            score += 10.0
        }

        return score
    }

    fun normalize(s: String): String {
        return s.lowercase()
            .replace(Regex("\\(.*?\\)|\\[.*?]|\\{.*?}"), "")
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .replace(Regex("\\b(feat|ft|featuring)\\b.*"), "")
            .trim()
    }

    fun fuzzyScore(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        if (a.contains(b) || b.contains(a)) return 0.85
        val tokensA = a.split(" ").filter { it.length > 1 }.toSet()
        val tokensB = b.split(" ").filter { it.length > 1 }.toSet()
        if (tokensA.isEmpty() || tokensB.isEmpty()) return 0.0
        val inter = tokensA.intersect(tokensB).size.toDouble()
        val union = tokensA.union(tokensB).size.toDouble()
        return inter / max(union, 1.0)
    }
}
