package com.personal.sonora.morning

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MorningSongScheduler @Inject constructor(private val context: Context) {
    companion object {
        const val REQUEST_CODE = 7001
        const val PREFS = "sonora_morning"
        const val KEY_ENABLED = "enabled"
        const val KEY_HOUR = "hour"
        const val KEY_MINUTE = "minute"
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun schedule(hour: Int, minute: Int) {
        val h = hour.coerceIn(0, 23)
        val m = minute.coerceIn(0, 59)
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = pendingIntent()
        // setAndAllowWhileIdle does not require the special exact-alarm permission.
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        prefs.edit()
            .putBoolean(KEY_ENABLED, true)
            .putInt(KEY_HOUR, h)
            .putInt(KEY_MINUTE, m)
            .apply()
    }

    fun cancel() {
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        alarm.cancel(pendingIntent())
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
    }

    fun rescheduleIfEnabled() {
        if (!prefs.getBoolean(KEY_ENABLED, false)) return
        schedule(
            prefs.getInt(KEY_HOUR, 7),
            prefs.getInt(KEY_MINUTE, 0)
        )
    }

    private fun pendingIntent(): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_CODE,
        Intent(context, MorningSongReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
