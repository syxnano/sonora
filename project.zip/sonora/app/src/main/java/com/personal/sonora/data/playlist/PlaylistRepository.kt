package com.personal.sonora.data.playlist

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.PlaylistDao
import com.personal.sonora.data.db.PlaylistEntity
import com.personal.sonora.data.db.PlaylistTrackDao
import com.personal.sonora.data.db.PlaylistTrackEntity
import com.personal.sonora.data.db.TrackDao
import com.personal.sonora.data.db.TrackEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

const val LIKED_SONGS_ID = "liked_songs"

fun Track.toEntity() = TrackEntity(
    id = id,
    title = title,
    artist = artist,
    album = album,
    durationMs = durationMs,
    coverUrl = coverUrl,
    source = source,
    externalId = externalId
)

fun TrackEntity.toTrack() = Track(
    id = id,
    title = title,
    artist = artist,
    album = album,
    durationMs = durationMs,
    coverUrl = coverUrl,
    source = source,
    externalId = externalId
)

@Singleton
class PlaylistRepository @Inject constructor(
    private val playlistDao: PlaylistDao,
    private val playlistTrackDao: PlaylistTrackDao,
    private val trackDao: TrackDao
) {
    fun observePlaylists(): Flow<List<PlaylistEntity>> = playlistDao.observeAll()

    fun observePlaylist(id: String): Flow<PlaylistEntity?> = playlistDao.observeById(id)

    fun observeTracks(playlistId: String): Flow<List<Track>> =
        playlistTrackDao.observeTrackEntities(playlistId).map { list -> list.map { it.toTrack() } }

    fun observeLiked(trackId: String): Flow<Boolean> =
        playlistTrackDao.observeContains(LIKED_SONGS_ID, trackId)

    suspend fun ensureLikedSongs() {
        if (playlistDao.getById(LIKED_SONGS_ID) == null) {
            playlistDao.upsert(
                PlaylistEntity(id = LIKED_SONGS_ID, name = "Liked Songs", isLikedSongs = true)
            )
        }
    }

    suspend fun create(name: String): String {
        val id = UUID.randomUUID().toString()
        playlistDao.upsert(PlaylistEntity(id = id, name = name.trim().ifBlank { "New playlist" }))
        return id
    }

    suspend fun rename(id: String, name: String) {
        val pl = playlistDao.getById(id) ?: return
        if (pl.isLikedSongs) return
        // @Update, not upsert: INSERT OR REPLACE would cascade-delete the playlist's tracks.
        playlistDao.update(pl.copy(name = name.trim().ifBlank { pl.name }, updatedAt = System.currentTimeMillis()))
    }

    suspend fun delete(id: String) {
        val pl = playlistDao.getById(id) ?: return
        if (pl.isLikedSongs) return
        playlistTrackDao.clearPlaylist(id)
        playlistDao.delete(id)
    }

    /** Returns false if the track was already in the playlist. */
    suspend fun addTrack(playlistId: String, track: Track): Boolean {
        if (playlistId == LIKED_SONGS_ID) ensureLikedSongs()
        val pl = playlistDao.getById(playlistId) ?: return false
        if (playlistTrackDao.getTrackIds(playlistId).contains(track.id)) return false
        // The track row must exist first (foreign key on playlist_tracks.trackId).
        trackDao.upsert(track.toEntity())
        val next = (playlistTrackDao.maxPosition(playlistId) ?: -1) + 1
        playlistTrackDao.upsert(PlaylistTrackEntity(playlistId = playlistId, trackId = track.id, position = next))
        playlistDao.update(
            pl.copy(
                coverUrl = pl.coverUrl ?: track.coverUrl,
                updatedAt = System.currentTimeMillis()
            )
        )
        return true
    }

    suspend fun removeTrack(playlistId: String, trackId: String) {
        playlistTrackDao.remove(playlistId, trackId)
    }

    suspend fun toggleLike(track: Track) {
        ensureLikedSongs()
        val ids = playlistTrackDao.getTrackIds(LIKED_SONGS_ID)
        if (ids.contains(track.id)) removeTrack(LIKED_SONGS_ID, track.id)
        else addTrack(LIKED_SONGS_ID, track)
    }
}
