package com.personal.sonora.ui.playlist

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.PlaylistEntity
import com.personal.sonora.data.playlist.PlaylistRepository
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.ConfirmDialog
import com.personal.sonora.ui.components.CoverArt
import com.personal.sonora.ui.components.NamePlaylistDialog
import com.personal.sonora.ui.components.TrackRow
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaylistViewModel @Inject constructor(
    private val repo: PlaylistRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val playlistId: String = savedStateHandle.get<String>("id") ?: ""

    val playlist = repo.observePlaylist(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null as PlaylistEntity?)

    val tracks = repo.observeTracks(playlistId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<Track>())

    fun remove(trackId: String) {
        viewModelScope.launch { repo.removeTrack(playlistId, trackId) }
    }

    fun rename(name: String) {
        viewModelScope.launch { repo.rename(playlistId, name) }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            repo.delete(playlistId)
            onDone()
        }
    }
}

@Composable
fun PlaylistScreen(
    playerController: PlayerController,
    onBack: () -> Unit,
    viewModel: PlaylistViewModel = hiltViewModel()
) {
    val playlist by viewModel.playlist.collectAsState()
    val tracks by viewModel.tracks.collectAsState()
    val playerState by playerController.state.collectAsState()

    var menuOpen by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var removeTarget by remember { mutableStateOf<Track?>(null) }

    val pl = playlist
    val isLiked = pl?.isLikedSongs == true

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = null)
            }
            if (pl != null && !isLiked) {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = null)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Rename playlist") },
                            onClick = { menuOpen = false; showRename = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete playlist") },
                            onClick = { menuOpen = false; showDelete = true }
                        )
                    }
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CoverArt(pl?.coverUrl, size = 180.dp)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (isLiked) "Liked Songs" else (pl?.name ?: ""),
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        "${tracks.size} songs",
                        color = SpotifySecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { if (tracks.isNotEmpty()) playerController.play(tracks.first(), tracks, 0) },
                        enabled = tracks.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SpotifyGreen,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Text("Play")
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
            if (tracks.isEmpty()) {
                item {
                    Text(
                        "No songs yet. Use the + button on a song to add it here.",
                        color = SpotifySecondary,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
            items(tracks, key = { it.id }) { track ->
                TrackRow(
                    track = track,
                    isPlaying = playerState.currentTrack?.id == track.id && playerState.isPlaying,
                    onClick = { playerController.play(track, tracks, tracks.indexOf(track)) },
                    onMore = { removeTarget = track }
                )
            }
        }
    }

    if (showRename && pl != null) {
        NamePlaylistDialog(
            title = "Rename playlist",
            initial = pl.name,
            onDismiss = { showRename = false },
            onConfirm = { viewModel.rename(it); showRename = false }
        )
    }
    if (showDelete && pl != null) {
        ConfirmDialog(
            title = "Delete playlist",
            message = "Delete \"${pl.name}\"? This cannot be undone.",
            confirmLabel = "Delete",
            onDismiss = { showDelete = false },
            onConfirm = { showDelete = false; viewModel.delete(onBack) }
        )
    }
    removeTarget?.let { t ->
        ConfirmDialog(
            title = "Remove song",
            message = "Remove \"${t.title}\" from this playlist?",
            confirmLabel = "Remove",
            onDismiss = { removeTarget = null },
            onConfirm = { viewModel.remove(t.id); removeTarget = null }
        )
    }
}
