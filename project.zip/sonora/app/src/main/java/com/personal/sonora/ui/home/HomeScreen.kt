package com.personal.sonora.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.personal.sonora.R
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.PlaylistCard
import com.personal.sonora.ui.components.ShimmerBox
import com.personal.sonora.ui.components.TrackRow
import com.personal.sonora.ui.theme.SpotifySecondary
import java.util.Calendar

@Composable
fun HomeScreen(
    playerController: PlayerController,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val playerState by playerController.state.collectAsState()

    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> stringResource(R.string.greeting_morning)
        in 12..17 -> stringResource(R.string.greeting_afternoon)
        else -> stringResource(R.string.greeting_evening)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(greeting, style = MaterialTheme.typography.headlineMedium)
                Row {
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                    }
                }
            }
        }

        // Quick playlists
        if (state.playlists.isNotEmpty()) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.playlists.take(6)) { pl ->
                        PlaylistCard(
                            name = pl.name,
                            coverUrl = pl.coverUrl,
                            onClick = { /* open playlist */ }
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }

        // Recently played
        if (state.recent.isNotEmpty()) {
            item {
                Text(
                    stringResource(R.string.recently_played),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
            items(state.recent.take(6)) { track ->
                TrackRow(
                    track = track,
                    isPlaying = playerState.currentTrack?.id == track.id && playerState.isPlaying,
                    onClick = { playerController.play(track, state.recent, state.recent.indexOf(track)) }
                )
            }
            item { Spacer(Modifier.height(16.dp)) }
        }

        // Popular for you
        item {
            Text(
                stringResource(R.string.popular_for_you),
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        when {
            state.isLoading -> {
                items(8) {
                    ShimmerBox(
                        Modifier
                            .fillMaxWidth()
                            .height(72.dp)
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }
            state.error != null -> {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(state.error ?: "", color = SpotifySecondary)
                        TextButton(onClick = { viewModel.load() }) {
                            Text(stringResource(R.string.retry))
                        }
                    }
                }
            }
            else -> {
                items(state.discover) { track ->
                    TrackRow(
                        track = track,
                        isPlaying = playerState.currentTrack?.id == track.id && playerState.isPlaying,
                        onClick = {
                            playerController.play(track, state.discover, state.discover.indexOf(track))
                        },
                        onAdd = { /* add to playlist sheet */ }
                    )
                }
            }
        }
    }
}
