package com.personal.sonora.data.recommend

import com.personal.sonora.data.catalog.LastFmCatalog
import com.personal.sonora.data.catalog.MusicCatalog
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.PlaylistDao
import com.personal.sonora.data.db.PlaylistTrackDao
import com.personal.sonora.data.db.SeenTrackDao
import com.personal.sonora.data.db.SeenTrackEntity
import com.personal.sonora.data.db.TrackDao
import com.personal.sonora.data.db.TrackEntity
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DiscoverEngine @Inject constructor(
    private val catalog: MusicCatalog,
    private val lastFm: LastFmCatalog,
    private val playlistDao: PlaylistDao,
    private val playlistTrackDao: PlaylistTrackDao,
    private val trackDao: TrackDao,
    private val seenTrackDao: SeenTrackDao
) {
    suspend fun buildTasteProfile(playlistId: String? = null): TasteProfile {
        val playlists = if (playlistId != null) {
            listOfNotNull(playlistDao.getById(playlistId))
        } else {
            playlistDao.observeAll().first()
        }
        val artistCounts = mutableMapOf<String, Int>()
        val tagCounts = mutableMapOf<String, Int>()
        val seedTracks = mutableListOf<Track>()

        for (pl in playlists) {
            val ids = playlistTrackDao.getTrackIds(pl.id)
            val tracks = trackDao.getByIds(ids)
            for (t in tracks) {
                artistCounts[t.artist] = (artistCounts[t.artist] ?: 0) + 1
                seedTracks.add(
                    Track(t.id, t.title, t.artist, t.album, t.durationMs, t.coverUrl, t.source, t.externalId)
                )
                val tags = lastFm.artistTopTags(t.artist)
                tags.forEach { tag -> tagCounts[tag] = (tagCounts[tag] ?: 0) + 1 }
            }
        }

        return TasteProfile(
            topArtists = artistCounts.entries.sortedByDescending { it.value }.map { it.key }.take(10),
            topTags = tagCounts.entries.sortedByDescending { it.value }.map { it.key }.take(5),
            seedTracks = seedTracks.shuffled().take(15)
        )
    }

    suspend fun discover(count: Int = 60, playlistId: String? = null): List<Track> {
        val profile = buildTasteProfile(playlistId)
        val seen = seenTrackDao.getAllIds().toSet()
        val inPlaylists = mutableSetOf<String>()
        playlistDao.observeAll().first().forEach { pl ->
            inPlaylists.addAll(playlistTrackDao.getTrackIds(pl.id))
        }

        val candidates = mutableListOf<Track>()

        // From tags
        for (tag in profile.topTags.take(5)) {
            val page = (1..5).random()
            candidates += catalog.tracksByTag(tag, page, 20)
        }

        // Similar to seeds
        for (seed in profile.seedTracks.shuffled().take(8)) {
            candidates += catalog.similarTracks(seed, 10)
        }

        // Top tracks of top artists
        for (artist in profile.topArtists.take(5)) {
            candidates += catalog.artistTopTracks(artist, 8)
        }

        // If empty profile, use trending
        if (candidates.isEmpty()) {
            candidates += catalog.trending(count * 2)
        }

        val filtered = candidates
            .filter { it.id !in seen && it.id !in inPlaylists }
            .distinctBy { "${it.artist.lowercase()}|${it.title.lowercase()}" }
            .shuffled()
            .take(count)

        // Mark as seen
        seenTrackDao.markSeenAll(filtered.map { SeenTrackEntity(it.id) })
        // Cache tracks
        trackDao.upsertAll(filtered.map {
            TrackEntity(it.id, it.title, it.artist, it.album, it.durationMs, it.coverUrl, it.source, it.externalId)
        })

        return filtered
    }

    suspend fun resetSeen() {
        seenTrackDao.clearAll()
    }
}

data class TasteProfile(
    val topArtists: List<String>,
    val topTags: List<String>,
    val seedTracks: List<Track>
)
