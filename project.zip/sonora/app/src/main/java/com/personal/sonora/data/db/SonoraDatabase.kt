package com.personal.sonora.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        TrackEntity::class,
        PlaylistEntity::class,
        PlaylistTrackEntity::class,
        ResolvedStreamEntity::class,
        SeenTrackEntity::class,
        RecentSearchEntity::class,
        PlayHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SonoraDatabase : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun playlistTrackDao(): PlaylistTrackDao
    abstract fun resolvedStreamDao(): ResolvedStreamDao
    abstract fun seenTrackDao(): SeenTrackDao
    abstract fun recentSearchDao(): RecentSearchDao
    abstract fun playHistoryDao(): PlayHistoryDao
}
