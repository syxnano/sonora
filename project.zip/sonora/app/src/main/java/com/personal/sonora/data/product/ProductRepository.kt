package com.personal.sonora.data.product

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.personal.sonora.data.catalog.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

private val Context.productStore: DataStore<Preferences> by preferencesDataStore("sonora_product")

@Singleton
class ProductRepository @Inject constructor(private val context: Context) {
    private val ds = context.productStore
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private object Keys {
        val CARDS = stringPreferencesKey("music_cards")
        val TASTE = stringPreferencesKey("taste_memory")
        val MORNING = stringPreferencesKey("morning_song")
    }

    val cards: Flow<List<MusicCard>> = ds.data.map { p ->
        runCatching { json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]") }.getOrDefault(emptyList())
    }
    val taste: Flow<TasteMemory> = ds.data.map { p ->
        runCatching { json.decodeFromString(TasteMemory.serializer(), p[Keys.TASTE] ?: "{}") }.getOrDefault(TasteMemory())
    }
    val morning: Flow<MorningSong> = ds.data.map { p ->
        runCatching { json.decodeFromString(MorningSong.serializer(), p[Keys.MORNING] ?: "{}") }.getOrDefault(MorningSong())
    }

    suspend fun createCard(track: Track, message: String, mood: String): MusicCard {
        val card = MusicCard(UUID.randomUUID().toString(), track, message.trim(), mood.trim())
        ds.edit { p ->
            val old = runCatching { json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]") }.getOrDefault(emptyList())
            p[Keys.CARDS] = json.encodeToString(ListSerializer(MusicCard.serializer()), (listOf(card) + old).take(100))
        }
        return card
    }

    suspend fun deleteCard(id: String) = ds.edit { p ->
        val old = runCatching { json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]") }.getOrDefault(emptyList())
        p[Keys.CARDS] = json.encodeToString(ListSerializer(MusicCard.serializer()), old.filterNot { it.id == id })
    }

    suspend fun saveTaste(taste: TasteMemory) = ds.edit { it[Keys.TASTE] = json.encodeToString(TasteMemory.serializer(), taste) }

    suspend fun clearTaste() = saveTaste(TasteMemory())

    suspend fun recordTrackFeedback(track: Track, liked: Boolean) {
        val current = taste.first()
        if (!current.learningEnabled) return
        val likedIds = current.likedTrackIds.toMutableSet()
        val dislikedIds = current.dislikedTrackIds.toMutableSet()
        if (liked) {
            dislikedIds.remove(track.id)
            likedIds.add(track.id)
        } else {
            likedIds.remove(track.id)
            dislikedIds.add(track.id)
        }
        saveTaste(current.copy(
            likedArtists = if (liked && track.artist.isNotBlank()) (current.likedArtists + track.artist).distinct().take(100) else current.likedArtists,
            likedTrackIds = likedIds.take(200).toList(),
            dislikedTrackIds = dislikedIds.take(200).toList()
        ))
    }

    suspend fun saveMorning(morning: MorningSong) = ds.edit { it[Keys.MORNING] = json.encodeToString(MorningSong.serializer(), morning) }
}
