package com.personal.sonora.data.resolver

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.ResolvedStreamDao
import com.personal.sonora.data.db.ResolvedStreamEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import javax.inject.Inject
import javax.inject.Singleton

data class ResolvedStream(
    val trackId: String,
    val videoId: String,
    val streamUrl: String,
    val codec: String,
    val bitrate: Int,
    val expiresAt: Long
)

@Singleton
class YouTubeResolver @Inject constructor(
    private val resolvedStreamDao: ResolvedStreamDao
) {
    private val service get() = ServiceList.YouTube
    private val streamTtlMs = 5 * 60 * 60 * 1000L // ~5 hours

    /** Last failure reason, shown to the user so problems can be diagnosed. */
    @Volatile
    var lastError: String? = null
        private set

    suspend fun resolve(track: Track, preferHighest: Boolean = true): ResolvedStream? =
        withContext(Dispatchers.IO) {
            lastError = null
            val cached = resolvedStreamDao.get(track.id)
            if (cached != null) {
                if (cached.streamUrl != null && cached.streamExpiresAt > System.currentTimeMillis()) {
                    return@withContext ResolvedStream(
                        trackId = track.id,
                        videoId = cached.videoId,
                        streamUrl = cached.streamUrl,
                        codec = cached.codec ?: "unknown",
                        bitrate = cached.bitrate,
                        expiresAt = cached.streamExpiresAt
                    )
                }
                extractStream(track.id, cached.videoId, preferHighest)?.let { return@withContext it }
            }

            val query = "${track.artist} - ${track.title} official audio"
            val candidates = searchCandidates(query)
            val scored = candidates.map { c ->
                val score = StreamScoring.score(c.title, c.uploader, c.durationSec, track)
                c.copy(score = score)
            }.sortedByDescending { it.score }

            val best = scored.firstOrNull { it.score > 10.0 } ?: scored.firstOrNull()
            if (best == null) {
                if (lastError == null) lastError = "YouTube search returned no results"
                return@withContext null
            }

            resolvedStreamDao.upsert(
                ResolvedStreamEntity(
                    trackId = track.id,
                    videoId = best.videoId,
                    streamUrl = null,
                    streamExpiresAt = 0
                )
            )

            extractStream(track.id, best.videoId, preferHighest)
        }

    suspend fun invalidate(trackId: String) {
        resolvedStreamDao.delete(trackId)
    }

    private fun searchCandidates(query: String): List<ScoredCandidate> {
        return try {
            val search = SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(query))
            search.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .take(10)
                .mapNotNull { item ->
                    val itemUrl = item.url ?: return@mapNotNull null
                    val vid = extractVideoId(itemUrl) ?: return@mapNotNull null
                    ScoredCandidate(
                        videoId = vid,
                        title = item.name ?: "",
                        uploader = item.uploaderName ?: "",
                        durationSec = item.duration,
                        score = 0.0
                    )
                }
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            lastError = "Search failed: ${e.javaClass.simpleName} ${e.message?.take(120) ?: ""}"
            emptyList()
        }
    }

    private suspend fun extractStream(
        trackId: String,
        videoId: String,
        preferHighest: Boolean
    ): ResolvedStream? {
        return try {
            val url = "https://www.youtube.com/watch?v=$videoId"
            val info = StreamInfo.getInfo(service, url)
            // ExoPlayer here has no HLS/DASH module, so only plain HTTP streams are playable.
            val allStreams = info.audioStreams
            val audioStreams = allStreams.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            if (audioStreams.isEmpty()) {
                lastError = "No playable audio stream (found ${allStreams.size}, none progressive)"
                return null
            }

            val chosen: AudioStream = if (preferHighest) {
                audioStreams.maxByOrNull { bitrateOf(it) } ?: audioStreams.first()
            } else {
                audioStreams.sortedBy { bitrateOf(it) }.let { sorted ->
                    sorted.getOrNull(sorted.size / 2) ?: sorted.first()
                }
            }

            // NewPipe 0.26: use getContent() (Kotlin: .content); getUrl() is deprecated
            val streamUrl = chosen.content?.takeIf { it.isNotBlank() }
            if (streamUrl == null) {
                lastError = "Stream has no URL"
                return null
            }
            val expiresAt = System.currentTimeMillis() + streamTtlMs
            val formatName = chosen.format?.name ?: chosen.codec ?: ""
            val codec = when {
                formatName.contains("webm", true) || formatName.contains("opus", true) -> "Opus"
                formatName.contains("m4a", true) || formatName.contains("aac", true) -> "AAC"
                chosen.codec?.isNotBlank() == true -> chosen.codec!!
                else -> formatName.ifBlank { "unknown" }
            }
            val bitrateKbps = bitrateOf(chosen)

            resolvedStreamDao.upsert(
                ResolvedStreamEntity(
                    trackId = trackId,
                    videoId = videoId,
                    streamUrl = streamUrl,
                    streamExpiresAt = expiresAt,
                    codec = codec,
                    bitrate = bitrateKbps
                )
            )

            ResolvedStream(
                trackId = trackId,
                videoId = videoId,
                streamUrl = streamUrl,
                codec = codec,
                bitrate = bitrateKbps,
                expiresAt = expiresAt
            )
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            lastError = "Extract failed: ${e.javaClass.simpleName} ${e.message?.take(120) ?: ""}"
            null
        }
    }

    /** Prefer averageBitrate (kbps); fall back to bitrate (may be bps). */
    private fun bitrateOf(stream: AudioStream): Int {
        val avg = stream.averageBitrate
        if (avg > 0) return avg
        val br = stream.bitrate
        return when {
            br <= 0 -> 0
            br > 1000 -> br / 1000 // treat as bps
            else -> br
        }
    }

    private fun extractVideoId(url: String): String? {
        val regex = Regex("(?:v=|/embed/|/shorts/|youtu\\.be/)([\\w\\-]{11})")
        return regex.find(url)?.groupValues?.getOrNull(1)
    }
}
