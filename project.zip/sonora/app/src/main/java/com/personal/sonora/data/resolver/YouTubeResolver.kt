package com.personal.sonora.data.resolver

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.ResolvedStreamDao
import com.personal.sonora.data.db.ResolvedStreamEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import javax.inject.Inject
import javax.inject.Singleton

data class ResolvedStream(
    val trackId: String,
    val videoId: String,
    val streamUrl: String,
    val codec: String,
    val bitrate: Int,
    val expiresAt: Long
)

@Singleton
class YouTubeResolver @Inject constructor(
    private val resolvedStreamDao: ResolvedStreamDao
) {
    private val service get() = ServiceList.YouTube
    private val streamTtlMs = 5 * 60 * 60 * 1000L // ~5 hours

    suspend fun resolve(track: Track, preferHighest: Boolean = true): ResolvedStream? =
        withContext(Dispatchers.IO) {
            // Check permanent videoId cache + valid stream URL
            val cached = resolvedStreamDao.get(track.id)
            if (cached != null) {
                if (cached.streamUrl != null && cached.streamExpiresAt > System.currentTimeMillis()) {
                    return@withContext ResolvedStream(
                        trackId = track.id,
                        videoId = cached.videoId,
                        streamUrl = cached.streamUrl,
                        codec = cached.codec ?: "unknown",
                        bitrate = cached.bitrate,
                        expiresAt = cached.streamExpiresAt
                    )
                }
                // Re-extract stream for known videoId
                extractStream(track.id, cached.videoId, preferHighest)?.let { return@withContext it }
            }

            // Search and score
            val query = "${track.artist} - ${track.title} official audio"
            val candidates = searchCandidates(query)
            val scored = candidates.map { c ->
                val score = StreamScoring.score(c.title, c.uploader, c.durationSec, track)
                c.copy(score = score)
            }.sortedByDescending { it.score }

            val best = scored.firstOrNull { it.score > 10.0 } ?: scored.firstOrNull()
                ?: return@withContext null

            // Persist videoId permanently
            resolvedStreamDao.upsert(
                ResolvedStreamEntity(
                    trackId = track.id,
                    videoId = best.videoId,
                    streamUrl = null,
                    streamExpiresAt = 0
                )
            )

            extractStream(track.id, best.videoId, preferHighest)
        }

    suspend fun invalidate(trackId: String) {
        resolvedStreamDao.delete(trackId)
    }

    private fun searchCandidates(query: String): List<ScoredCandidate> {
        return try {
            val search = SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(query))
            search.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .take(10)
                .mapNotNull { item ->
                    val vid = extractVideoId(item.url ?: return@mapNotNull null) ?: return@mapNotNull null
                    ScoredCandidate(
                        videoId = vid,
                        title = item.name ?: "",
                        uploader = item.uploaderName ?: "",
                        durationSec = item.duration,
                        score = 0.0
                    )
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun extractStream(
        trackId: String,
        videoId: String,
        preferHighest: Boolean
    ): ResolvedStream? {
        return try {
            val url = "https://www.youtube.com/watch?v=$videoId"
            val info = StreamInfo.getInfo(service, url)
            val audioStreams = info.audioStreams
            if (audioStreams.isEmpty()) return null

            val chosen: AudioStream = if (preferHighest) {
                audioStreams.maxByOrNull { it.bitrate } ?: audioStreams.first()
            } else {
                // Prefer mid-range for data saver
                audioStreams.sortedBy { it.bitrate }.let { sorted ->
                    sorted.getOrNull(sorted.size / 2) ?: sorted.first()
                }
            }

            val streamUrl = chosen.content ?: chosen.url ?: return null
            val expiresAt = System.currentTimeMillis() + streamTtlMs
            val codec = when {
                chosen.format?.toString()?.contains("webm", true) == true ||
                        chosen.format?.toString()?.contains("opus", true) == true -> "Opus"
                chosen.format?.toString()?.contains("m4a", true) == true ||
                        chosen.format?.toString()?.contains("aac", true) == true -> "AAC"
                else -> chosen.format?.name ?: "unknown"
            }
            val bitrate = chosen.bitrate / 1000 // kbps

            resolvedStreamDao.upsert(
                ResolvedStreamEntity(
                    trackId = trackId,
                    videoId = videoId,
                    streamUrl = streamUrl,
                    streamExpiresAt = expiresAt,
                    codec = codec,
                    bitrate = bitrate
                )
            )

            ResolvedStream(
                trackId = trackId,
                videoId = videoId,
                streamUrl = streamUrl,
                codec = codec,
                bitrate = bitrate,
                expiresAt = expiresAt
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun extractVideoId(url: String): String? {
        val regex = Regex("(?:v=|/embed/|/shorts/|youtu\\.be/)([\\w-]{11})")
        return regex.find(url)?.groupValues?.getOrNull(1)
    }
}
