# Sonora

Personal Spotify-style music player for Android. Metadata from online catalogs; audio is resolved to YouTube audio-only streams (no video, no ads).

**Personal use only.** Audio extraction depends on NewPipe Extractor and may break when YouTube changes. Quality is limited by what YouTube serves (typically ~160 kbps Opus / ~128–256 kbps AAC), not lossless.

## Features

- **Home / Discover** – “Popular for you” recommendations from your playlists (Last.fm tags + similar tracks when an API key is set; otherwise YouTube search)
- **Search** – Songs via YouTube / Last.fm
- **Library** – Local playlists (Room), Liked Songs
- **Player** – Mini player, full Now Playing, queue, MediaSession notification, background playback
- **Audio resolver** – Scores YouTube results by duration, title/artist match, official channels; caches video IDs and stream URLs
- **Settings** – Streaming quality hints, discover count, crossfade, clear caches
- **Thai + English** UI strings

## Screenshots

*(Add screenshots here after building)*

## Optional: Last.fm API key

1. Create a free account and API key: https://www.last.fm/api/account/create  
2. Put it in `local.properties`:

```properties
LASTFM_API_KEY=your_key_here
```

Or set the GitHub secret `LASTFM_API_KEY` for CI. Without a key, the app falls back to YouTube Music–style search only.

## Build with GitHub Actions (zero local setup)

1. Create a new empty GitHub repository.
2. Push this project:

```bash
git init
git add .
git commit -m "Initial Sonora app"
git branch -M main
git remote add origin https://github.com/YOUR_USER/sonora.git
git push -u origin main
```

3. Open the **Actions** tab → workflow **Build APK** → download the artifact `sonora-debug-apk`.
4. Optional: add repository secret `LASTFM_API_KEY`.
5. Tagging `v*` also creates a GitHub Release with the APK.

## Build locally

Requirements: JDK 17, Android SDK (compileSdk 35).

```bash
# optional
cp local.properties.example local.properties
# edit sdk.dir and LASTFM_API_KEY

gradle assembleDebug
# or open in Android Studio and Run
```

APK path: `app/build/outputs/apk/debug/app-debug.apk`

CI uses **Gradle 8.13** (not the wrapper). AGP is **8.13.2**.

## Tech stack

- Kotlin, Jetpack Compose, Material 3 (dark theme)
- minSdk 26, targetSdk 35
- MVVM + Hilt + Coroutines/Flow
- Room, DataStore, Media3 (ExoPlayer + MediaSessionService)
- NewPipe Extractor (JitPack), OkHttp, Coil, kotlinx.serialization

## Limitations & legal

- YouTube extraction can break; update the NewPipe Extractor version when needed.
- Audio quality ceiling is YouTube’s, not CD/lossless.
- Spotify catalog cannot be fully listed; optional import of *your* playlists only (not implemented in this scaffold beyond Client ID field).
- Intended for **personal use**. Automated downloading/streaming may conflict with YouTube’s Terms of Service. Use at your own risk.

## Project structure

```
sonora/
├── app/
│   ├── build.gradle.kts
│   └── src/main/java/com/personal/sonora/
│       ├── data/ (db, catalog, resolver, recommend, settings)
│       ├── player/
│       ├── ui/
│       └── di/
├── gradle/libs.versions.toml
├── .github/workflows/build.yml
└── README.md
```

## License

Use and modify freely for personal projects. No warranty.
