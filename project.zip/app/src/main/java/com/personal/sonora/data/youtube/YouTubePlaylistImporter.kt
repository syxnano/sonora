package com.personal.sonora.data.youtube

import com.personal.sonora.BuildConfig
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.spotify.ImportedPlaylist
import com.personal.sonora.data.spotify.PlaylistImportException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YouTubePlaylistImporter @Inject constructor(
    private val client: OkHttpClient
) {
    private val listRegex = Regex("[?&]list=([A-Za-z0-9_\\-]+)")
    private val videoRegex = Regex("(?:v=|/embed/|/shorts/|youtu\\.be/)([A-Za-z0-9_-]{11})")
    private val maxTracks = 300

    fun looksLikeYouTube(link: String): Boolean {
        val t = link.lowercase()
        return t.contains("youtube.com") || t.contains("youtu.be") || t.contains("music.youtube")
    }

    suspend fun fetch(link: String): ImportedPlaylist = withContext(Dispatchers.IO) {
        val key = BuildConfig.YOUTUBE_API_KEY.trim()
        val listId = listRegex.find(link)?.groupValues?.get(1)
            ?: throw PlaylistImportException("That link has no playlist in it. Copy a YouTube playlist link containing list=...")
        if (key.isBlank()) throw PlaylistImportException("YouTube API key is not configured.")
        val found = LinkedHashMap<String, Track>()
        var pageToken: String? = null
        var playlistTitle = "YouTube playlist"
        while (found.size < maxTracks) {
            val url = "https://www.googleapis.com/youtube/v3/playlistItems".toHttpUrl().newBuilder()
                .addQueryParameter("part", "snippet,contentDetails")
                .addQueryParameter("playlistId", listId)
                .addQueryParameter("maxResults", "50")
                .addQueryParameter("key", key)
                .apply { if (!pageToken.isNullOrBlank()) addQueryParameter("pageToken", pageToken) }
                .build()
            val json = get(url.toString()) ?: throw PlaylistImportException("Could not read the YouTube playlist.")
            val items = json.optJSONArray("items") ?: break
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val sn = item.optJSONObject("snippet") ?: continue
                val id = item.optJSONObject("contentDetails")?.optString("videoId").orEmpty()
                if (!id.matches(Regex("[A-Za-z0-9_-]{11}"))) continue
                val title = sn.optString("title").trim()
                if (title.isEmpty() || title.startsWith("[Deleted") || title.startsWith("[Private")) continue
                val thumbs = sn.optJSONObject("thumbnails")
                val thumb = thumbs?.optJSONObject("high")?.optString("url")
                    ?: thumbs?.optJSONObject("medium")?.optString("url")
                found[id] = Track(id = "yt_$id", title = title, artist = sn.optString("videoOwnerChannelTitle").ifBlank { sn.optString("channelTitle") }, album = null, durationMs = 0L, coverUrl = thumb, source = "youtube", externalId = id)
                if (found.size >= maxTracks) break
            }
            pageToken = json.optString("nextPageToken").takeIf { it.isNotBlank() }
            if (pageToken == null) break
        }
        ImportedPlaylist(playlistTitle, found.values.firstOrNull()?.coverUrl, found.values.toList())
    }

    private fun get(url: String): JSONObject? = runCatching {
        client.newCall(Request.Builder().url(url).get().build()).execute().use { r ->
            if (!r.isSuccessful) null else JSONObject(r.body?.string().orEmpty())
        }
    }.getOrNull()
}
