package com.personal.sonora.di

import android.content.Context
import androidx.room.Room
import com.personal.sonora.data.catalog.LastFmCatalog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.personal.sonora.data.catalog.MusicCatalog
import com.personal.sonora.data.db.SonoraDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides
    @Singleton
    fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SonoraDatabase {
        return Room.databaseBuilder(context, SonoraDatabase::class.java, "sonora.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides fun provideTrackDao(db: SonoraDatabase) = db.trackDao()
    @Provides fun providePlaylistDao(db: SonoraDatabase) = db.playlistDao()
    @Provides fun providePlaylistTrackDao(db: SonoraDatabase) = db.playlistTrackDao()
    @Provides fun provideResolvedStreamDao(db: SonoraDatabase) = db.resolvedStreamDao()
    @Provides fun provideSeenTrackDao(db: SonoraDatabase) = db.seenTrackDao()
    @Provides fun provideRecentSearchDao(db: SonoraDatabase) = db.recentSearchDao()
    @Provides fun providePlayHistoryDao(db: SonoraDatabase) = db.playHistoryDao()
    @Provides fun provideDownloadDao(db: SonoraDatabase) = db.downloadDao()
    @Provides fun provideOfflineTrackDao(db: SonoraDatabase) = db.offlineTrackDao()

    @Provides
    @Singleton
    fun provideMusicCatalog(lastFm: LastFmCatalog): MusicCatalog = lastFm


}
