package com.personal.sonora.data.download

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.DownloadDao
import com.personal.sonora.data.db.DownloadEntity
import com.personal.sonora.data.db.OfflineTrackDao
import com.personal.sonora.data.db.OfflineTrackEntity
import com.personal.sonora.data.db.PlaylistDao
import com.personal.sonora.data.db.PlaylistTrackDao
import com.personal.sonora.data.db.TrackDao
import com.personal.sonora.data.playlist.toEntity
import com.personal.sonora.data.settings.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Serial download queue (one active download at a time).
 * Progress is exposed via StateFlow for clean UI.
 */
@Singleton
class DownloadManager @Inject constructor(
    private val downloadDao: DownloadDao,
    private val offlineTrackDao: OfflineTrackDao,
    private val trackDao: TrackDao,
    private val playlistDao: PlaylistDao,
    private val playlistTrackDao: PlaylistTrackDao,
    private val mediaWriter: MediaStoreAudioWriter,
    private val snapshotStore: PlaylistSnapshotStore,
    private val settings: SettingsRepository,
    private val okHttp: OkHttpClient
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val workerMutex = Mutex()
    private var workerJob: Job? = null
    private val paused = AtomicBoolean(false)

    private val _currentProgress = MutableStateFlow<DownloadProgress?>(null)
    val currentProgress: StateFlow<DownloadProgress?> = _currentProgress.asStateFlow()

    val queue: Flow<List<DownloadEntity>> = downloadDao.observeAll()
    val activeCount: Flow<Int> = downloadDao.observeActiveCount()
    val offlineIds: Flow<Set<String>> = offlineTrackDao.observeIds().map { it.toSet() }

    fun isOffline(trackId: String): Flow<Boolean> = offlineTrackDao.observeIsOffline(trackId)

    suspend fun enqueueTrack(track: Track, quality: DownloadQuality? = null, playlistId: String? = null) {
        trackDao.upsert(track.toEntity())
        val q = quality ?: DownloadQuality.fromKey(settings.getDownloadQuality())
        val existing = offlineTrackDao.get(track.id)
        if (existing != null) return // already offline

        val pos = (downloadDao.maxPosition() ?: -1) + 1
        val entity = DownloadEntity(
            id = UUID.randomUUID().toString(),
            trackId = track.id,
            playlistId = playlistId,
            title = track.title,
            artist = track.artist,
            coverUrl = track.coverUrl,
            quality = q.key,
            status = DownloadStatus.QUEUED.name,
            position = pos
        )
        downloadDao.upsert(entity)
        ensureWorker()
    }

    suspend fun enqueuePlaylist(playlistId: String, quality: DownloadQuality? = null) {
        val trackIds = playlistTrackDao.getTrackIds(playlistId)
        val tracks = trackDao.getByIds(trackIds)
        val q = quality ?: DownloadQuality.fromKey(settings.getDownloadQuality())
        trackIds.forEach { tid ->
            val t = tracks.find { it.id == tid } ?: return@forEach
            enqueueTrack(
                Track(
                    id = t.id, title = t.title, artist = t.artist, album = t.album,
                    durationMs = t.durationMs, coverUrl = t.coverUrl, source = t.source,
                    externalId = t.externalId
                ),
                quality = q,
                playlistId = playlistId
            )
        }
    }

    suspend fun pause(id: String) {
        val item = downloadDao.getById(id) ?: return
        if (item.status == DownloadStatus.DOWNLOADING.name || item.status == DownloadStatus.QUEUED.name) {
            downloadDao.markFailed(id, DownloadStatus.PAUSED.name, null, System.currentTimeMillis())
            if (item.status == DownloadStatus.DOWNLOADING.name) {
                paused.set(true)
            }
        }
    }

    suspend fun resume(id: String) {
        val item = downloadDao.getById(id) ?: return
        if (item.status == DownloadStatus.PAUSED.name || item.status == DownloadStatus.FAILED.name) {
            downloadDao.markFailed(id, DownloadStatus.QUEUED.name, null, System.currentTimeMillis())
            paused.set(false)
            ensureWorker()
        }
    }

    suspend fun cancel(id: String) {
        downloadDao.markFailed(id, DownloadStatus.CANCELLED.name, null, System.currentTimeMillis())
        downloadDao.delete(id)
    }

    suspend fun clearFinished() {
        downloadDao.clearFinished()
    }

    suspend fun reorder(orderedIds: List<String>) {
        orderedIds.forEachIndexed { index, id ->
            downloadDao.setPosition(id, index)
        }
    }

    suspend fun removeOffline(trackId: String) {
        offlineTrackDao.delete(trackId)
        // Note: we intentionally do not delete the MediaStore file so user can keep it in system library
    }

    private fun ensureWorker() {
        if (workerJob?.isActive == true) return
        workerJob = scope.launch {
            workerMutex.withLock {
                while (isActive) {
                    if (paused.get()) {
                        delay(500)
                        continue
                    }
                    val next = downloadDao.nextQueued() ?: break
                    runOne(next)
                    // Small pause between songs so YouTube does not rate-limit a long queue.
                    delay(1_500)
                }
            }
        }
    }

    private suspend fun runOne(item: DownloadEntity) {
        val now = System.currentTimeMillis()
        downloadDao.updateProgress(
            item.id, DownloadStatus.DOWNLOADING.name, 0f, 0, 0, 0, null, now
        )
        _currentProgress.value = DownloadProgress(
            id = item.id, trackId = item.trackId, title = item.title, artist = item.artist,
            status = DownloadStatus.DOWNLOADING, progress = 0f, bytesDownloaded = 0, totalBytes = 0,
            speedBps = 0, playlistId = item.playlistId
        )

        try {
            val track = trackDao.getById(item.trackId)
                ?: throw IllegalStateException("Track not found")
            throw IllegalStateException("Provider media download is disabled. Sonora uses official provider playback APIs.")
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            downloadDao.markFailed(
                item.id, DownloadStatus.FAILED.name,
                e.message?.take(200) ?: "Unknown error",
                System.currentTimeMillis()
            )
            _currentProgress.value = DownloadProgress(
                id = item.id, trackId = item.trackId, title = item.title, artist = item.artist,
                status = DownloadStatus.FAILED, progress = 0f, bytesDownloaded = 0, totalBytes = 0,
                speedBps = 0, error = e.message, playlistId = item.playlistId
            )
        } finally {
            delay(300)
            _currentProgress.value = null
        }
    }

    suspend fun exportFullSnapshot() {
        try {
            val pls = playlistDao.observeAll().first()
            val trackMap = mutableMapOf<String, com.personal.sonora.data.db.TrackEntity>()
            val snapPls = pls.map { pl ->
                val ids = playlistTrackDao.getTrackIds(pl.id)
                ids.forEach { tid ->
                    trackDao.getById(tid)?.let { trackMap[tid] = it }
                }
                PlaylistSnapshotStore.SnapshotPlaylist(
                    id = pl.id,
                    name = pl.name,
                    coverUrl = pl.coverUrl,
                    localCoverUri = pl.localCoverUri,
                    isLikedSongs = pl.isLikedSongs,
                    trackIds = ids
                )
            }
            val snapTracks = trackMap.values.map {
                PlaylistSnapshotStore.SnapshotTrack(
                    id = it.id, title = it.title, artist = it.artist, album = it.album,
                    durationMs = it.durationMs, coverUrl = it.coverUrl, source = it.source,
                    externalId = it.externalId
                )
            }
            snapshotStore.export(
                PlaylistSnapshotStore.Snapshot(playlists = snapPls, tracks = snapTracks)
            )
        } catch (_: Exception) { }
    }

    private suspend fun exportSnapshotSafe() {
        exportFullSnapshot()
    }
}
