package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

class UnavailableConnector(
    override val platform: Platform,
    private val message: String
) : SonoraConnector {
    override suspend fun capabilities() = Capability.entries.map {
        CapabilityStatus(it, CapabilityState.UNSUPPORTED, message)
    }
    override suspend fun connect(): Result<Unit> = Result.failure(UnsupportedOperationException(message))
    override suspend fun disconnect() = Result.success(Unit)
    override suspend fun refresh(): Result<Unit> = Result.failure(UnsupportedOperationException(message))
}
