# Sonora Android — Official YouTube Card Playback

The public Music Card path uses the official YouTube Embedded Player inside Android WebView.

- No YouTube audio extraction for Music Cards.
- No NewPipe stream URL is used by Music Card playback.
- Card shows title, artist, message, embedded YouTube video, and an `เปิดบน YouTube` button.
- The player can be minimized while staying inside the Card screen.
- The WebView is paused when the Activity lifecycle enters `ON_PAUSE`, so the Card path does not intentionally provide hidden/background playback.
- `sonora://card/<id>` opens the Android Card screen.
- `https://sonora-9d7f4.web.app/card/<id>` is accepted as the Android App Link host.

The legacy resolver remains for older catalog/download features in the prototype codebase. It is not part of the Music Card playback path and should be removed/disabled before a commercial public compliance review if those features are not independently authorized.
