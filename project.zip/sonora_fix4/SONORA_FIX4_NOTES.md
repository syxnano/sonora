# Sonora Fix 4 — in-app YouTube playback + real Mood/Tone use

## Fixed
- YouTube tracks no longer hand off to YouTube Music / external browser when selected.
- Added `YouTubeEmbedController` using the official YouTube IFrame Player API inside Android WebView.
- `PlayerController` routes YouTube tracks to the in-app embed player while keeping other external providers on their existing hand-off path.
- Now Playing renders the YouTube player in-app for YouTube tracks.
- Search/Home/Sonora selections navigate to Now Playing after starting the selected track.
- YouTube play/pause/seek and room play/seek/speed hooks are wired to the embedded player.
- Taste Memory now stores `toneTags` as well as `moodTags`.
- Taste AI has real Mood/Tone selectors and the Apply button actually appends the selected Mood/Tone to the catalog search and ranking request.
- Saving Taste AI persists the selected Mood/Tone.

## Important
- The Android catalog search implementation in this package is still the existing catalog implementation. This fix changes playback to the official YouTube IFrame player; it does not claim that the old catalog implementation has been replaced with YouTube Data API v3.
- Other non-YouTube providers may still use their existing hand-off behavior.
