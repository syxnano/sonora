# Sonora — production deployment

## Firebase
- Project: `sonora-9d7f4`
- Enable Authentication → Anonymous.
- Enable Realtime Database.
- Apply `firebase-rules.json`.
- Enable App Check for Android and Web before broad public use.

## Web
From the project root:

```bash
npm install -g firebase-tools
firebase login
firebase use sonora-9d7f4
firebase deploy --only hosting,database
```

Public Card URL:
`https://sonora-9d7f4.web.app/card/<CARD_ID>`

The production web bundle contains only the send/search Music Card flow plus the public Card page. The unused web room/reply pages are not part of the final bundle.

## Android
Open the project in Android Studio, sync Gradle, configure release signing, then build:

```bash
./gradlew bundleRelease
```

The workspace used for this handoff has no usable Gradle executable, so this step must be run in a real Android/Gradle environment.

## Provider / compliance boundary
The official Music Card playback path is YouTube Embedded Player. The repository still contains legacy NewPipe/stream-resolver code for older prototype playback/download features. That code is not used by Music Cards, but it must be removed or disabled before a public/commercial launch unless independently authorized by the relevant provider.
