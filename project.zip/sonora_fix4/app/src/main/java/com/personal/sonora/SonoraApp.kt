package com.personal.sonora

import android.app.Application
import com.personal.sonora.data.download.OfflineRecovery
import com.personal.sonora.data.social.RoomPlaybackCoordinator
import com.personal.sonora.data.social.RoomTts
import com.personal.sonora.di.NewPipeInit
import com.personal.sonora.util.CrashLog
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class SonoraApp : Application() {
    /**
     * Injecting this marker forces Hilt to create the NewPipeInit binding,
     * which runs NewPipe.init(...) in its provider.
     */
    @Inject lateinit var newPipeInit: NewPipeInit
    @Inject lateinit var offlineRecovery: OfflineRecovery
    @Inject lateinit var roomCoordinator: RoomPlaybackCoordinator
    @Inject lateinit var roomTts: RoomTts

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        // Install before anything else so even start-up crashes are captured.
        CrashLog.install(this)
        super.onCreate()
        // "Listen with friends": runs for the whole app life so sync + chat voice work on every screen.
        roomCoordinator.start()
        roomTts.start()
        // Recover playlists + offline files after reinstall (best-effort)
        appScope.launch {
            offlineRecovery.runIfNeeded()
        }
    }
}
