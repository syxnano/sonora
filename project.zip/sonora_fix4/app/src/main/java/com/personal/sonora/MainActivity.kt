package com.personal.sonora

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.CrashDialog
import com.personal.sonora.ui.navigation.SonoraNavGraph
import com.personal.sonora.ui.theme.SonoraTheme
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.util.CrashLog
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var playerController: PlayerController

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val cardIntentId = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        playerController.connect()
        cardIntentId.value = cardIdFromIntent(intent)
        setContent {
            SonoraTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SpotifyBlack
                ) {
                    SonoraNavGraph(playerController = playerController, initialCardId = cardIntentId.value)
                    var crash by remember { mutableStateOf(CrashLog.read(applicationContext)) }
                    crash?.let { report ->
                        CrashDialog(
                            report = report,
                            onDismiss = {
                                CrashLog.clear(applicationContext)
                                crash = null
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        cardIntentId.value = cardIdFromIntent(intent)
    }

    private fun cardIdFromIntent(intent: Intent?): String? {
        val data = intent?.data ?: return null
        return when (data.scheme) {
            "sonora" -> if (data.host == "card") data.pathSegments.firstOrNull() else null
            "https" -> if (data.host == "sonora-9d7f4.web.app") data.pathSegments.let { if (it.firstOrNull() == "card") it.getOrNull(1) else null } else null
            else -> null
        }
    }

    // The MediaController is deliberately NOT released here: the room keeps the music in sync while
    // the app is in the background, and PlayerController only holds the application context.
}
