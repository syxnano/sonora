package com.personal.sonora.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.R
import com.personal.sonora.data.catalog.MusicCatalog
import com.personal.sonora.data.catalog.SearchResult
import com.personal.sonora.data.catalog.SearchType
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.db.RecentSearchDao
import com.personal.sonora.data.db.RecentSearchEntity
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.components.AddToPlaylistSheet
import com.personal.sonora.ui.components.TrackRow
import com.personal.sonora.ui.theme.SpotifyElevated
import com.personal.sonora.ui.theme.SpotifySecondary
import com.personal.sonora.ui.theme.SpotifyWhite
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val query: String = "",
    val results: List<Track> = emptyList(),
    val recent: List<String> = emptyList(),
    val isLoading: Boolean = false
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val catalog: MusicCatalog,
    private val recentSearchDao: RecentSearchDao
) : ViewModel() {
    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state

    private val queryFlow = MutableStateFlow("")

    init {
        viewModelScope.launch {
            recentSearchDao.observeRecent().collect { list ->
                _state.value = _state.value.copy(recent = list.map { it.query })
            }
        }
        @OptIn(FlowPreview::class)
        viewModelScope.launch {
            queryFlow.debounce(300).collect { q ->
                if (q.isBlank()) {
                    _state.value = _state.value.copy(results = emptyList(), isLoading = false)
                } else {
                    _state.value = _state.value.copy(isLoading = true)
                    val result = try {
                        catalog.search(q, SearchType.SONGS, 30)
                    } catch (e: Exception) {
                        SearchResult()
                    }
                    if (result.tracks.isNotEmpty()) {
                        recentSearchDao.upsert(RecentSearchEntity(q.trim()))
                    }
                    _state.value = _state.value.copy(results = result.tracks, isLoading = false)
                }
            }
        }
    }

    fun onQueryChange(q: String) {
        _state.value = _state.value.copy(query = q)
        queryFlow.value = q
    }

    fun clearRecent() {
        viewModelScope.launch { recentSearchDao.clearAll() }
    }

    fun deleteRecent(q: String) {
        viewModelScope.launch { recentSearchDao.delete(q) }
    }
}

@Composable
fun SearchScreen(
    playerController: PlayerController,
    onTrackSelected: (Track) -> Unit = { track -> playerController.play(track) },
    viewModel: SearchViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val playerState by playerController.state.collectAsState()
    var addTrack by remember { mutableStateOf<Track?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = state.query,
            onValueChange = { viewModel.onQueryChange(it) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (state.query.isNotEmpty()) {
                    IconButton(onClick = { viewModel.onQueryChange("") }) {
                        Icon(Icons.Default.Clear, null)
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = SpotifyElevated,
                unfocusedContainerColor = SpotifyElevated,
                focusedTextColor = SpotifyWhite,
                unfocusedTextColor = SpotifyWhite,
                cursorColor = SpotifyWhite,
                focusedBorderColor = SpotifySecondary,
                unfocusedBorderColor = SpotifySecondary
            )
        )

        LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp)) {
            if (state.query.isBlank() && state.recent.isNotEmpty()) {
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            stringResource(R.string.recent_searches),
                            color = SpotifySecondary,
                            modifier = Modifier
                                .weight(1f)
                                .padding(vertical = 8.dp)
                        )
                        TextButton(onClick = { viewModel.clearRecent() }) {
                            Text(stringResource(R.string.clear_all), color = SpotifySecondary)
                        }
                    }
                }
                items(state.recent, key = { it }) { q ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.onQueryChange(q) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            q,
                            modifier = Modifier
                                .weight(1f)
                                .padding(vertical = 12.dp),
                            color = SpotifyWhite
                        )
                        IconButton(onClick = { viewModel.deleteRecent(q) }) {
                            Icon(Icons.Default.Clear, contentDescription = null, tint = SpotifySecondary)
                        }
                    }
                }
            }
            if (state.isLoading) {
                item {
                    Text(
                        "Searching...",
                        color = SpotifySecondary,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            } else if (state.query.isNotBlank() && state.results.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.no_results),
                        color = SpotifySecondary,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }
            }
            items(state.results) { track ->
                TrackRow(
                    track = track,
                    isPlaying = playerState.currentTrack?.id == track.id,
                    onClick = {
                        playerController.play(track, state.results, state.results.indexOf(track))
                        onTrackSelected(track)
                    },
                    onAdd = { addTrack = track }
                )
            }
        }
    }

    addTrack?.let { t ->
        AddToPlaylistSheet(track = t, onDismiss = { addTrack = null })
    }
}
