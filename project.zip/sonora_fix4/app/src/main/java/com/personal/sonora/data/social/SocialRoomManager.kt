package com.personal.sonora.data.social

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Lightweight peer room system (6-digit code).
 * Current implementation is local-only scaffolding:
 * - Generate / join room code
 * - Hold room state for UI
 * Real-time sync (WebRTC / signaling server) can be plugged in later.
 */
@Singleton
class SocialRoomManager @Inject constructor() {

    data class ChatMessage(
        val id: String = UUID.randomUUID().toString(),
        val sender: String,
        val text: String,
        val timestamp: Long = System.currentTimeMillis(),
        val isTts: Boolean = false
    )

    data class RoomState(
        val code: String? = null,
        val isHost: Boolean = false,
        val connectedPeers: Int = 0,
        val messages: List<ChatMessage> = emptyList(),
        val status: String = "idle" // idle, hosting, joining, connected
    )

    private val _room = MutableStateFlow(RoomState())
    val room: StateFlow<RoomState> = _room.asStateFlow()

    fun createRoom(): String {
        val code = (100000..999999).random().toString()
        _room.value = RoomState(code = code, isHost = true, status = "hosting", connectedPeers = 1)
        return code
    }

    fun joinRoom(code: String): Boolean {
        if (code.length != 6 || !code.all { it.isDigit() }) return false
        _room.value = RoomState(code = code, isHost = false, status = "joining", connectedPeers = 1)
        // In a full implementation this would connect to a signaling server.
        _room.value = _room.value.copy(status = "connected")
        return true
    }

    fun leaveRoom() {
        _room.value = RoomState()
    }

    fun sendChat(sender: String, text: String, tts: Boolean = false) {
        val msg = ChatMessage(sender = sender, text = text, isTts = tts)
        _room.value = _room.value.copy(messages = _room.value.messages + msg)
    }
}
