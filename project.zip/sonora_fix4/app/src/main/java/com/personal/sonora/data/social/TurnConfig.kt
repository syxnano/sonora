package com.personal.sonora.data.social

import android.util.Log
import com.personal.sonora.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.PeerConnection
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves ICE servers without hosting anything:
 * 1) Static TURN_* from local.properties
 * 2) Or Metered Open Relay REST with METERED_API_KEY (free tier)
 * 3) Always includes public STUN
 */
@Singleton
class TurnConfig @Inject constructor(
    private val client: OkHttpClient
) {
    data class Resolved(
        val servers: List<PeerConnection.IceServer>,
        val source: String
    )

    suspend fun resolve(): Resolved = withContext(Dispatchers.IO) {
        val list = mutableListOf<PeerConnection.IceServer>()
        list += PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        list += PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        list += PeerConnection.IceServer.builder("stun:stun.relay.metered.ca:80").createIceServer()

        val staticUrls = BuildConfig.TURN_URLS
        val user = BuildConfig.TURN_USERNAME
        val cred = BuildConfig.TURN_CREDENTIAL
        if (staticUrls.isNotBlank() && user.isNotBlank() && cred.isNotBlank()) {
            staticUrls.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { url ->
                list += PeerConnection.IceServer.builder(url)
                    .setUsername(user)
                    .setPassword(cred)
                    .createIceServer()
            }
            return@withContext Resolved(list, "static_local_properties")
        }

        val apiKey = BuildConfig.METERED_API_KEY
        if (apiKey.isNotBlank()) {
            try {
                // Metered: https://www.metered.ca/docs — credentials endpoint varies by app name.
                // Common pattern for Open Relay credential API:
                val url = "https://sonora.metered.live/api/v1/turn/credentials?apiKey=$apiKey"
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string() ?: "[]"
                        parseMeteredIce(body, list)
                        return@withContext Resolved(list, "metered_api")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Metered fetch failed: ${e.message}")
            }
        }

        Log.w(TAG, "No TURN — only STUN. Same Wi‑Fi OK; cross-network often needs free Metered key.")
        Resolved(list, "stun_only")
    }

    private fun parseMeteredIce(body: String, out: MutableList<PeerConnection.IceServer>) {
        // Response may be array of {urls, username, credential} or {iceServers:[...]}
        val trimmed = body.trim()
        val arr = when {
            trimmed.startsWith("[") -> JSONArray(trimmed)
            else -> JSONObject(trimmed).optJSONArray("iceServers") ?: JSONArray()
        }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val username = o.optString("username", "")
            val credential = o.optString("credential", o.optString("password", ""))
            val urlsVal = o.opt("urls")
            val urlList = mutableListOf<String>()
            when (urlsVal) {
                is String -> urlList += urlsVal
                is JSONArray -> for (j in 0 until urlsVal.length()) urlList += urlsVal.getString(j)
            }
            for (u in urlList) {
                val b = PeerConnection.IceServer.builder(u)
                if (username.isNotBlank()) b.setUsername(username)
                if (credential.isNotBlank()) b.setPassword(credential)
                out += b.createIceServer()
            }
        }
    }

    companion object {
        private const val TAG = "TurnConfig"
    }
}
