package com.personal.sonora.ui.social

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import com.personal.sonora.data.social.RoomPlaybackCoordinator
import com.personal.sonora.data.social.RoomPlaybackCoordinator.OutStatus
import com.personal.sonora.ui.theme.SpotifyElevated
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class RoomOverlayViewModel @Inject constructor(
    val coordinator: RoomPlaybackCoordinator
) : ViewModel()

/**
 * Drawn on top of every screen:
 *  - friend asked to change to a song outside the playlist -> Accept / Decline dialog
 *  - I asked -> "waiting for approval" / "approved" / "declined" banner
 */
@Composable
fun RoomOverlay(vm: RoomOverlayViewModel = hiltViewModel()) {
    val coordinator = vm.coordinator
    val incoming by coordinator.incoming.collectAsState()
    val outgoing by coordinator.outgoing.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        coordinator.events.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    incoming?.let { req ->
        AlertDialog(
            onDismissRequest = { /* must answer explicitly */ },
            containerColor = SpotifyElevated,
            title = {
                Text(
                    "${req.byName.ifBlank { "เพื่อน" }} อยากเปลี่ยนเพลง",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        req.track?.title ?: "",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(req.track?.artist ?: "", color = SpotifySecondary, maxLines = 1)
                    Text(
                        "เพลงนี้ไม่ได้อยู่ในเพลย์ลิสต์ที่ฟังอยู่ ฟังด้วยกันเลยไหม?",
                        color = SpotifySecondary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { coordinator.approve() }) {
                    Text("ฟังเลย", color = SpotifyGreen, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { coordinator.decline() }) {
                    Text("ไม่เอา", color = Color.White)
                }
            }
        )
    }

    outgoing?.let { out ->
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Surface(
                color = SpotifyElevated,
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(12.dp)
                    .fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when (out.status) {
                        OutStatus.WAITING -> CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp,
                            color = SpotifyGreen
                        )
                        OutStatus.APPROVED -> Text("✓", color = SpotifyGreen, fontWeight = FontWeight.Bold)
                        OutStatus.REJECTED -> Text("✕", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold)
                        OutStatus.EXPIRED -> Text("⌛", color = SpotifySecondary)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(
                            when (out.status) {
                                OutStatus.WAITING -> "รออีกฝ่ายอนุมัติ…"
                                OutStatus.APPROVED -> "อนุมัติแล้ว กำลังเปลี่ยนเพลง"
                                OutStatus.REJECTED -> "อีกฝ่ายไม่อนุมัติ"
                                OutStatus.EXPIRED -> "หมดเวลา ไม่มีการตอบกลับ"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (out.title.isNotBlank()) {
                            Text(out.title, color = SpotifySecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (out.status == OutStatus.WAITING) {
                        TextButton(onClick = { coordinator.cancelMyRequest() }) {
                            Text("ยกเลิก", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
