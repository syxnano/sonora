package com.personal.sonora.ui.sonora

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.product.PublicCardRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PublicCardViewModel @Inject constructor(private val repo: PublicCardRepository) : ViewModel() {
    var state by mutableStateOf<State>(State.Loading); private set

    sealed interface State {
        data object Loading : State
        data class Ready(
            val title: String,
            val artist: String,
            val message: String,
            val videoId: String?
        ) : State
        data class Error(val message: String) : State
    }

    fun load(id: String) = viewModelScope.launch {
        runCatching { repo.get(id) }
            .onSuccess { s ->
                if (!s.exists()) {
                    state = State.Error("ไม่พบ Music Card นี้")
                } else {
                    state = State.Ready(
                        title = s.child("title").getValue(String::class.java).orEmpty(),
                        artist = s.child("artist").getValue(String::class.java).orEmpty(),
                        message = s.child("message").getValue(String::class.java).orEmpty(),
                        videoId = (s.child("youtubeVideoId").getValue(String::class.java) ?: s.child("externalId").getValue(String::class.java))?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
                    )
                }
            }
            .onFailure { state = State.Error("เปิด Music Card ไม่สำเร็จ ลองใหม่อีกครั้ง") }
    }
}

private const val YOUTUBE_ORIGIN = "https://www.youtube.com"

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeEmbeddedPlayer(
    videoId: String,
    minimized: Boolean,
    onToggleMinimized: () -> Unit,
    modifier: Modifier = Modifier
) {
    val embedUrl = remember(videoId) {
        "$YOUTUBE_ORIGIN/embed/$videoId?playsinline=1&rel=0&modestbranding=1&origin=https%3A%2F%2Fsonora-9d7f4.web.app"
    }

    val lifecycleOwner = LocalLifecycleOwner.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(if (minimized) 86.dp else 230.dp)
            .background(Color.Black, RoundedCornerShape(14.dp))
    ) {
        val webViewHolder = remember { arrayOfNulls<WebView>(1) }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webViewClient = WebViewClient()
                    webChromeClient = WebChromeClient()
                    setBackgroundColor(Color.Black.value.toInt())
                    loadUrl(embedUrl)
                    webViewHolder[0] = this
                }
            },
            update = { webView ->
                webViewHolder[0] = webView
            }
        )

        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_PAUSE -> webViewHolder[0]?.onPause()
                    Lifecycle.Event.ON_RESUME -> webViewHolder[0]?.onResume()
                    else -> Unit
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                lifecycleOwner.lifecycle.removeObserver(observer)
                webViewHolder[0]?.onPause()
                webViewHolder[0]?.destroy()
                webViewHolder[0] = null
            }
        }

        IconButton(
            onClick = onToggleMinimized,
            modifier = Modifier.align(Alignment.TopEnd)
        ) {
            Icon(
                imageVector = if (minimized) Icons.Default.Fullscreen else Icons.Default.KeyboardArrowDown,
                contentDescription = if (minimized) "ขยายวิดีโอ" else "ย่อวิดีโอ",
                tint = Color.White
            )
        }
    }
}

@Composable
fun PublicCardScreen(
    id: String,
    onBack: () -> Unit,
    vm: PublicCardViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    var minimized by remember { mutableStateOf(false) }

    LaunchedEffect(id) { vm.load(id) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(8, 8, 8))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Sonora", color = Color.White, fontSize = 26.sp)
            Text("Music Card", color = Color(30, 215, 96), fontSize = 14.sp)
        }
        Spacer(Modifier.height(14.dp))

        when (val s = vm.state) {
            PublicCardViewModel.State.Loading -> Text("กำลังเปิด Music Card…", color = Color.White)
            is PublicCardViewModel.State.Error -> {
                Text(s.message, color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onBack) { Text("กลับ") }
            }
            is PublicCardViewModel.State.Ready -> {
                Text(s.title, color = Color.White, fontSize = 24.sp)
                Text(s.artist, color = Color.LightGray, fontSize = 16.sp)

                if (s.message.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text("“${s.message}”", color = Color.White, fontSize = 18.sp)
                }

                Spacer(Modifier.height(16.dp))

                if (s.videoId != null) {
                    YouTubeEmbeddedPlayer(
                        videoId = s.videoId,
                        minimized = minimized,
                        onToggleMinimized = { minimized = !minimized }
                    )

                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val url = "https://www.youtube.com/watch?v=${s.videoId}"
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(30, 215, 96))
                    ) {
                        Text("▶ เปิดบน YouTube", color = Color.Black)
                    }
                } else {
                    Text("การ์ดนี้ไม่มี YouTube videoId", color = Color.LightGray)
                }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("กลับ") }
            }
        }
    }
}
