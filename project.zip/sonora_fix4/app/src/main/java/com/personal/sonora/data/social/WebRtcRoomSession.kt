package com.personal.sonora.data.social

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Orchestrates room code + real WebRTC engine + playback sync bridge.
 */
@Singleton
class WebRtcRoomSession @Inject constructor(
    private val socialRoomManager: SocialRoomManager,
    private val engine: WebRtcEngine,
    private val syncBridge: PlaybackSyncBridge
) {
    data class SessionUi(
        val roomCode: String? = null,
        val role: String? = null,
        val localSignal: String? = null,
        val connected: Boolean = false,
        val status: String = "idle",
        val lastError: String? = null
    )

    private val _ui = MutableStateFlow(SessionUi())
    val ui: StateFlow<SessionUi> = _ui.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    init {
        syncBridge.start()
        scope.launch {
            engine.connectionState.collectLatest { st ->
                val connected = st == WebRtcEngine.ConnState.CONNECTED
                _ui.value = _ui.value.copy(
                    connected = connected,
                    status = st.name.lowercase()
                )
            }
        }
        scope.launch {
            engine.localSdp.collectLatest { sdp ->
                if (sdp != null) {
                    _ui.value = _ui.value.copy(localSignal = sdp)
                }
            }
        }
        scope.launch {
            engine.lastError.collectLatest { err ->
                if (err != null) _ui.value = _ui.value.copy(lastError = err)
            }
        }
    }

    fun hostCreate() {
        val code = socialRoomManager.createRoom()
        _ui.value = SessionUi(roomCode = code, role = "host", status = "creating_offer")
        engine.createOffer(code) { signal ->
            _ui.value = _ui.value.copy(
                localSignal = signal,
                status = "waiting_answer"
            )
        }
    }

    fun guestAcceptOffer(offerJson: String): Boolean {
        return try {
            val codeMatch = Regex("\"roomCode\"\\s*:\\s*\"(\\d{6})\"").find(offerJson)
            val code = codeMatch?.groupValues?.get(1) ?: "000000"
            socialRoomManager.joinRoom(code)
            _ui.value = SessionUi(roomCode = code, role = "guest", status = "creating_answer")
            engine.createAnswer(offerJson) { signal ->
                _ui.value = _ui.value.copy(
                    localSignal = signal,
                    status = "answer_ready"
                )
            }
            true
        } catch (e: Exception) {
            _ui.value = _ui.value.copy(lastError = e.message, status = "error")
            false
        }
    }

    fun hostAcceptAnswer(answerJson: String) {
        engine.acceptAnswer(answerJson) { ok ->
            _ui.value = _ui.value.copy(
                status = if (ok) "connecting" else "error",
                lastError = if (!ok) engine.lastError.value else null
            )
        }
    }

    fun sendChat(sender: String, text: String) {
        socialRoomManager.sendChat(sender, text, tts = true)
        syncBridge.broadcastChat(sender, text)
    }

    fun leave() {
        engine.close()
        socialRoomManager.leaveRoom()
        _ui.value = SessionUi()
    }
}
