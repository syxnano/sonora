package com.personal.sonora.ui.nowplaying

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.personal.sonora.player.PlayerController
import com.personal.sonora.player.YouTubeEmbedController
import com.personal.sonora.data.download.DownloadManager
import com.personal.sonora.data.lyrics.LyricsRepository
import com.personal.sonora.data.lyrics.LyricsResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.personal.sonora.data.download.DownloadQuality
import com.personal.sonora.data.settings.SettingsRepository
import com.personal.sonora.ui.components.DownloadQualitySheet
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.personal.sonora.ui.components.AddToPlaylistSheet
import com.personal.sonora.ui.components.PlaylistActionsViewModel
import com.personal.sonora.ui.queue.QueueSheet
import com.personal.sonora.ui.components.CoverArt
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flowOf


@HiltViewModel
class NowPlayingActionsViewModel @Inject constructor(
    private val downloadManager: DownloadManager,
    private val settings: SettingsRepository,
    private val lyricsRepository: LyricsRepository
) : ViewModel() {
    val offlineIds = downloadManager.offlineIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())
    val downloadQuality = settings.downloadQuality
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "HIGH")

    private val _lyrics = MutableStateFlow<LyricsResult?>(null)
    val lyrics = _lyrics.asStateFlow()

    fun download(track: com.personal.sonora.data.catalog.Track) {
        viewModelScope.launch {
            downloadManager.enqueueTrack(track, DownloadQuality.fromKey(settings.getDownloadQuality()))
        }
    }
    fun setQuality(q: DownloadQuality) = viewModelScope.launch { settings.setDownloadQuality(q.key) }

    fun loadLyrics(track: com.personal.sonora.data.catalog.Track?) {
        if (track == null) {
            _lyrics.value = null
            return
        }
        viewModelScope.launch {
            _lyrics.value = lyricsRepository.fetch(track)
        }
    }
}

@HiltViewModel
class YouTubeHostViewModel @Inject constructor(
    val youtube: YouTubeEmbedController
) : ViewModel()

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeNowPlaying(
    controller: YouTubeEmbedController,
    videoId: String,
    modifier: Modifier = Modifier
) {
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(12.dp)),
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webChromeClient = WebChromeClient()
                controller.attach(this)
            }
        },
        update = { controller.attach(it) }
    )
    DisposableEffect(Unit) {
        onDispose { controller.detach() }
    }
}

@Composable
fun NowPlayingScreen(
    playerController: PlayerController,
    onBack: () -> Unit
) {
    val state by playerController.state.collectAsState()
    val track = state.currentTrack
    val actions: PlaylistActionsViewModel = hiltViewModel()
    val nowActions: NowPlayingActionsViewModel = hiltViewModel()
    val youtubeHost: YouTubeHostViewModel = hiltViewModel()
    val offlineIds by nowActions.offlineIds.collectAsState()
    val qualityKey by nowActions.downloadQuality.collectAsState()
    var showDlQuality by remember { mutableStateOf(false) }
    val likedFlow = remember(track?.id) {
        if (track != null) actions.observeLiked(track.id) else flowOf(false)
    }
    val liked by likedFlow.collectAsState(initial = false)
    var showAdd by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val lyrics by nowActions.lyrics.collectAsState()
    val isOffline = track?.id in offlineIds

    LaunchedEffect(Unit) {
        while (true) {
            playerController.updatePosition()
            delay(500)
        }
    }
    LaunchedEffect(track?.id) {
        nowActions.loadLyrics(track)
    }

    Box(Modifier.fillMaxSize()) {
        CanvasBackground(coverUrl = track?.coverUrl)
        Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White)
                }
                Text("Now playing", style = MaterialTheme.typography.labelLarge, color = Color.White)
                Row {
                    IconButton(onClick = { if (track != null) showDlQuality = true }) {
                        Icon(
                            if (isOffline) Icons.Default.DownloadDone else Icons.Default.Download,
                            contentDescription = "Download",
                            tint = if (isOffline) SpotifyGreen else Color.White
                        )
                    }
                    IconButton(onClick = { showQueue = true }) {
                        Icon(Icons.Default.QueueMusic, null, tint = Color.White)
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            if (track?.source.equals("youtube", ignoreCase = true) && track?.externalId?.matches(Regex("[A-Za-z0-9_-]{11}")) == true) {
                YouTubeNowPlaying(
                    controller = youtubeHost.youtube,
                    videoId = track.externalId!!
                )
            } else {
                CoverArt(
                    url = track?.coverUrl,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(8.dp)),
                    size = 320.dp,
                    corner = 8.dp
                )
            }

            Spacer(Modifier.height(32.dp))

            Text(
                track?.title ?: "",
                style = MaterialTheme.typography.headlineMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Color.White
            )
            Text(
                track?.artist ?: "",
                style = MaterialTheme.typography.bodyLarge,
                color = SpotifySecondary
            )

            TextButton(onClick = { showLyrics = !showLyrics }) {
                Text(if (showLyrics) "Hide lyrics" else "Lyrics", color = SpotifyGreen)
            }
            if (showLyrics) {
                SyncedLyricsView(
                    lines = lyrics?.synced ?: emptyList(),
                    positionMs = state.positionMs,
                    plainFallback = lyrics?.plain,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                )
            }

            if (state.codec != null) {
                Text(
                    "${state.codec} ${state.bitrate} kbps",
                    style = MaterialTheme.typography.bodySmall,
                    color = SpotifySecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(Modifier.height(16.dp))

            val progress = if (state.durationMs > 0)
                state.positionMs.toFloat() / state.durationMs else 0f
            var dragging by remember { mutableStateOf(false) }
            var dragValue by remember { mutableStateOf(0f) }
            Slider(
                value = (if (dragging) dragValue else progress).coerceIn(0f, 1f),
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = {
                    playerController.seekTo((dragValue * state.durationMs).toLong())
                    dragging = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = SpotifySecondary.copy(alpha = 0.3f)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(if (dragging) (dragValue * state.durationMs).toLong() else state.positionMs), color = SpotifySecondary, style = MaterialTheme.typography.bodySmall)
                Text(formatTime(state.durationMs), color = SpotifySecondary, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { playerController.setShuffle(!state.shuffle) }) {
                    Icon(
                        Icons.Default.Shuffle,
                        null,
                        tint = if (state.shuffle) SpotifyGreen else Color.White
                    )
                }
                IconButton(onClick = { playerController.skipPrevious() }) {
                    Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                IconButton(
                    onClick = { playerController.togglePlayPause() },
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        null,
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onClick = { playerController.skipNext() }) {
                    Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { playerController.cycleRepeat() }) {
                    Icon(
                        if (state.repeatMode == 1) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        null,
                        tint = if (state.repeatMode != 0) SpotifyGreen else Color.White
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                IconButton(onClick = { track?.let { actions.toggleLike(it) } }) {
                    if (liked) {
                        Icon(Icons.Default.Favorite, null, tint = SpotifyGreen)
                    } else {
                        Icon(Icons.Default.FavoriteBorder, null, tint = Color.White)
                    }
                }
                IconButton(onClick = { if (track != null) showAdd = true }) {
                    Icon(Icons.Default.Add, null, tint = Color.White)
                }
            }
        }
    }

    }

    if (showDlQuality) {
        DownloadQualitySheet(
            selected = DownloadQuality.fromKey(qualityKey),
            onSelect = { q ->
                nowActions.setQuality(q)
                track?.let { nowActions.download(it) }
                showDlQuality = false
            },
            onDismiss = { showDlQuality = false }
        )
    }
    if (showQueue) {
        QueueSheet(playerController = playerController, onDismiss = { showQueue = false })
    }

    if (showAdd && track != null) {
        AddToPlaylistSheet(track = track, onDismiss = { showAdd = false })
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}
