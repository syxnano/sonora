package com.personal.sonora.ui.social

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.data.settings.SettingsRepository
import com.personal.sonora.data.social.RoomPlaybackCoordinator
import com.personal.sonora.data.social.FirebaseRoomRepository
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SocialViewModel @Inject constructor(
    val rooms: FirebaseRoomRepository,
    val coordinator: RoomPlaybackCoordinator,
    val playerController: PlayerController,
    private val settings: SettingsRepository,
    profileRepository: ProfileRepository
) : ViewModel() {
    val profile = profileRepository.profile
    val ttsEnabled = settings.roomTtsEnabled

    fun create(name: String) = viewModelScope.launch { rooms.createRoom(name) }
    fun join(code: String, name: String) = viewModelScope.launch { rooms.joinRoom(code, name) }
    fun leave() = rooms.leave()
    fun chat(sender: String, text: String) = rooms.sendChat(sender, text)
    fun setTts(on: Boolean) = viewModelScope.launch { settings.setRoomTtsEnabled(on) }
}

@Composable
fun SocialScreen(
    viewModel: SocialViewModel = hiltViewModel()
) {
    val room by viewModel.rooms.room.collectAsState()
    val messages by viewModel.rooms.messages.collectAsState()
    val profile by viewModel.profile.collectAsState(
        initial = com.personal.sonora.data.profile.GuestProfile()
    )
    val ttsOn by viewModel.ttsEnabled.collectAsState(initial = true)
    val sync by viewModel.coordinator.sync.collectAsState()
    val playerState by viewModel.playerController.state.collectAsState()
    val incoming by viewModel.coordinator.incoming.collectAsState()
    val outgoing by viewModel.coordinator.outgoing.collectAsState()
    val username = profile.username
    var joinCode by remember { mutableStateOf("") }
    var chatText by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Listen with Friends", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))

        room.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }

        if (room.code == null) {
            Button(
                onClick = { viewModel.create(username) },
                colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("สร้างห้อง", color = Color.Black)
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = joinCode,
                onValueChange = { if (it.length <= 6) joinCode = it.filter { c -> c.isDigit() } },
                label = { Text("รหัส 6 หลัก") },
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.join(joinCode, username) },
                enabled = joinCode.length == 6,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) {
                Text("เข้าร่วมห้อง", color = Color.White)
            }
        } else {
            Text(
                "ห้อง ${room.code}",
                color = SpotifyGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp
            )
            Text(
                if (room.isHost) "คุณเป็น Host / DJ" else "คุณเป็นผู้ฟัง • Host คุมเพลง",
                color = if (room.isHost) SpotifyGreen else SpotifySecondary,
                fontSize = 13.sp
            )
            Text(
                "ออนไลน์ ${room.peerCount} คน",
                color = SpotifySecondary
            )
            Spacer(Modifier.height(4.dp))
            val syncText = when {
                playerState.currentTrack == null -> "เลือกเพลงจากหน้าไหนก็ได้ ทั้งสองฝั่งจะฟังพร้อมกัน"
                sync.waiting -> "กำลังเตรียมเพลง…"
                kotlin.math.abs(sync.driftMs) < 150 -> "ซิงค์อัตโนมัติ ✓"
                else -> "กำลังปรับให้ตรงกัน (${sync.driftMs} ms)"
            }
            Text(syncText, color = SpotifySecondary, fontSize = 12.sp)
            Text(
                if (room.isHost) "คุณควบคุม Play / Pause / เลื่อน / ข้าม แล้วทุกคนจะตามกันอัตโนมัติ" else "Host / DJ ควบคุมเพลงให้ทั้งห้อง ส่วนคุณเสนอเพลงได้จากตัวเล่นปกติ",
                color = SpotifySecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.coordinator.forceResync() }, modifier = Modifier.weight(1f)) { Text("Resync") }
                if (outgoing != null) {
                    Text(
                        when (outgoing!!.status) {
                            RoomPlaybackCoordinator.OutStatus.WAITING -> "รอ Host อนุมัติ"
                            RoomPlaybackCoordinator.OutStatus.APPROVED -> "อนุมัติแล้ว"
                            RoomPlaybackCoordinator.OutStatus.REJECTED -> "ถูกปฏิเสธ"
                            RoomPlaybackCoordinator.OutStatus.EXPIRED -> "หมดเวลา"
                        },
                        color = SpotifySecondary, modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("อ่านข้อความเพื่อนด้วยเสียง (TTS)", color = Color.White, modifier = Modifier.weight(1f))
                Switch(
                    checked = ttsOn,
                    onCheckedChange = { viewModel.setTts(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = SpotifyGreen)
                )
            }

            Spacer(Modifier.height(8.dp))
            Text("แชท", color = Color.White, fontWeight = FontWeight.SemiBold)
            messages.takeLast(40).forEach { msg ->
                Text(
                    "${msg.sender}: ${msg.text}",
                    color = Color.White,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = chatText,
                    onValueChange = { chatText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("ข้อความ…") },
                    colors = fieldColors()
                )
                Button(
                    onClick = {
                        if (chatText.isNotBlank()) {
                            viewModel.chat(username, chatText)
                            chatText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)
                ) { Text("ส่ง", color = Color.Black) }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { viewModel.leave() }) {
                Text("ออกจากห้อง")
            }
        }
    }

    incoming?.let { req ->
        AlertDialog(
            onDismissRequest = { viewModel.coordinator.decline() },
            title = { Text("มีคนเสนอเพลง") },
            text = { Text("${req.byName}: ${req.track?.title ?: "เพลง"}") },
            confirmButton = { TextButton(onClick = { viewModel.coordinator.approve() }) { Text("อนุมัติ") } },
            dismissButton = { TextButton(onClick = { viewModel.coordinator.decline() }) { Text("ปฏิเสธ") } }
        )
    }
}

@Composable
private fun fieldColors() = TextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = Color(0xFF1E1E1E),
    unfocusedContainerColor = Color(0xFF1E1E1E)
)
