package com.personal.sonora.data.catalog

/**
 * Sonora recommendation/search duration guard.
 * Only normal song-length results are allowed into discovery/search:
 * - at least 1 minute (avoid Shorts/clips)
 * - at most 15 minutes (avoid playlists/long-form uploads)
 */
object TrackDurationPolicy {
    const val MIN_DURATION_MS = 60_000L
    const val MAX_DURATION_MS = 900_000L

    fun isAllowed(durationMs: Long): Boolean =
        durationMs in MIN_DURATION_MS..MAX_DURATION_MS

    fun <T : Track> filterAllowed(tracks: List<T>): List<T> =
        tracks.filter { isAllowed(it.durationMs) }
}
