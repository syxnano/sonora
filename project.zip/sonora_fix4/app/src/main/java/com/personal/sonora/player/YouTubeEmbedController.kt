package com.personal.sonora.player

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Controls an official YouTube IFrame Player running inside Sonora's WebView.
 * It is deliberately separate from Media3/NewPipe: YouTube tracks are played by
 * youtube.com/embed rather than by extracting a stream URL.
 */
data class YouTubeEmbedState(
    val videoId: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val ready: Boolean = false
)

@Singleton
class YouTubeEmbedController @Inject constructor() {
    private var webView: WebView? = null
    private var pendingVideoId: String? = null
    private var pendingStartMs: Long = 0L
    private var pendingPlay: Boolean = true

    private val _state = MutableStateFlow(YouTubeEmbedState())
    val state: StateFlow<YouTubeEmbedState> = _state.asStateFlow()

    @SuppressLint("SetJavaScriptEnabled")
    fun attach(view: WebView) {
        if (webView === view) return
        webView = view
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.mediaPlaybackRequiresUserGesture = false
        view.settings.allowFileAccess = false
        view.settings.allowContentAccess = false
        view.webViewClient = WebViewClient()
        view.addJavascriptInterface(Bridge(), "SonoraYT")
        view.loadDataWithBaseURL(
            "https://sonora-9d7f4.web.app/",
            HTML,
            "text/html",
            "UTF-8",
            null
        )
    }

    fun detach(view: WebView? = webView) {
        if (view === webView) webView = null
    }

    fun open(videoId: String, startMs: Long = 0L, play: Boolean = true) {
        pendingVideoId = videoId
        pendingStartMs = startMs.coerceAtLeast(0L)
        pendingPlay = play
        _state.value = YouTubeEmbedState(videoId, play, pendingStartMs, 0L, false)
        runJs("loadVideo(${JSONObject.quote(videoId)}, ${pendingStartMs / 1000.0}, $play);")
    }

    fun play() {
        pendingPlay = true
        runJs("if(window.sonoraPlayer){sonoraPlayer.playVideo();}")
        _state.value = _state.value.copy(isPlaying = true)
    }

    fun pause() {
        pendingPlay = false
        runJs("if(window.sonoraPlayer){sonoraPlayer.pauseVideo();}")
        _state.value = _state.value.copy(isPlaying = false)
    }

    fun toggle() {
        if (_state.value.isPlaying) pause() else play()
    }

    fun seekTo(ms: Long) {
        val safe = ms.coerceAtLeast(0L)
        runJs("if(window.sonoraPlayer){sonoraPlayer.seekTo(${safe / 1000.0}, true);}")
        _state.value = _state.value.copy(positionMs = safe)
    }

    fun setSpeed(speed: Float) {
        val safe = speed.coerceIn(0.25f, 2f)
        runJs("if(window.sonoraPlayer){sonoraPlayer.setPlaybackRate($safe);}")
    }

    fun stop() {
        runJs("if(window.sonoraPlayer){sonoraPlayer.stopVideo();}")
        _state.value = YouTubeEmbedState()
        pendingVideoId = null
    }

    private fun runJs(script: String) {
        webView?.post { webView?.evaluateJavascript("javascript:$script", null) }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun ready() {
            val id = pendingVideoId ?: return
            runJs("loadVideo(${JSONObject.quote(id)}, ${pendingStartMs / 1000.0}, $pendingPlay);")
            _state.value = _state.value.copy(ready = true)
        }

        @JavascriptInterface
        fun state(position: Double, duration: Double, playerState: Int) {
            val pos = (position * 1000.0).toLong().coerceAtLeast(0L)
            val dur = (duration * 1000.0).toLong().coerceAtLeast(0L)
            _state.value = _state.value.copy(
                positionMs = pos,
                durationMs = dur,
                isPlaying = playerState == 1
            )
        }

        @JavascriptInterface
        fun ended() {
            _state.value = _state.value.copy(isPlaying = false, positionMs = _state.value.durationMs)
        }
    }

    private companion object {
        val HTML = """
<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body,#player{margin:0;width:100%;height:100%;background:#000;overflow:hidden}</style>
</head><body><div id="player"></div>
<script>
var sonoraPlayer=null;
function onYouTubeIframeAPIReady(){
  sonoraPlayer=new YT.Player('player',{
    width:'100%',height:'100%',
    playerVars:{playsinline:1,rel:0,modestbranding:1,controls:1,enablejsapi:1,origin:'https://sonora-9d7f4.web.app'},
    events:{onReady:function(){SonoraYT.ready();},onStateChange:function(e){
      if(window.sonoraPlayer){SonoraYT.state(sonoraPlayer.getCurrentTime(),sonoraPlayer.getDuration(),e.data);}
      if(e.data===0) SonoraYT.ended();
    }}
  });
}
function loadVideo(id,start,play){
  if(!sonoraPlayer || !sonoraPlayer.loadVideoById) return;
  sonoraPlayer.loadVideoById({videoId:id,startSeconds:start});
  if(!play) sonoraPlayer.pauseVideo();
}
setInterval(function(){
  if(window.sonoraPlayer && sonoraPlayer.getCurrentTime){
    SonoraYT.state(sonoraPlayer.getCurrentTime(),sonoraPlayer.getDuration(),sonoraPlayer.getPlayerState());
  }
},500);
</script>
<script src="https://www.youtube.com/iframe_api"></script>
</body></html>
        """.trimIndent()
    }
}
