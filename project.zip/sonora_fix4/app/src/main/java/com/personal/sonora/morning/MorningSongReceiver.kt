package com.personal.sonora.morning

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.personal.sonora.MainActivity
import com.personal.sonora.R

class MorningSongReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                "morning_song",
                "Morning Song",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        val open = PendingIntent.getActivity(
            context,
            7002,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "morning_song")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Sonora ☀️")
            .setContentText("เพลงเช้าของมึงวันนี้ — เปิด Sonora เพื่อดูเพลงและส่งกลับ")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(7001, notification)
        MorningSongScheduler(context).rescheduleIfEnabled()
    }
}
