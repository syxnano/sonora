package com.personal.sonora.data.social

import android.os.SystemClock
import androidx.media3.common.Player
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.player.PlayerController
import com.personal.sonora.player.RoomHook
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs
import kotlin.math.min

/**
 * "Listen with friends" brain.
 *
 * Model: the room owns ONE timeline (rooms/{code}/state) and ONE playlist (rooms/{code}/queue).
 * Every user action is written to the room (never applied directly); every device — including the
 * one that acted — follows the room through [reconcile]. [reconcile] runs on every change and every
 * second, so devices converge on their own: small drift is absorbed by a ±5 % tempo nudge (no
 * stutter), large drift (buffering, backgrounding) by a single seek.
 */
@Singleton
class RoomPlaybackCoordinator @Inject constructor(
    private val rooms: FirebaseRoomRepository,
    private val player: PlayerController
) : RoomHook {

    enum class OutStatus { WAITING, APPROVED, REJECTED, EXPIRED }

    /** What the person who asked for a song change sees. */
    data class OutgoingUi(val id: String, val title: String, val status: OutStatus)

    /** For the status line on the social screen. */
    data class SyncInfo(val driftMs: Long = 0L, val nudging: Boolean = false, val waiting: Boolean = false)

    private companion object {
        /** Silence before a song the user picked starts, so every phone can load it first. */
        const val USER_LEAD_MS = 1200L
        const val APPROVE_LEAD_MS = 2000L
        /** Gap between two songs of the playlist. */
        const val AUTO_GAP_MS = 400L
        const val START_SLACK_MS = 20L
        /** A hard seek lands slightly ahead to compensate for the seek itself. */
        const val SEEK_LEAD_MS = 150L
        const val SEEK_COOLDOWN_MS = 1500L
        const val RUNWAY_RETRY_MS = 15_000L
        const val RESULT_SHOW_MS = 2500L
        const val MAX_REQUEST_QUEUE = 200
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false

    private val _incoming = MutableStateFlow<RoomRequest?>(null)
    /** A friend wants to change the song: show Accept / Decline. */
    val incoming: StateFlow<RoomRequest?> = _incoming.asStateFlow()

    private val _outgoing = MutableStateFlow<OutgoingUi?>(null)
    val outgoing: StateFlow<OutgoingUi?> = _outgoing.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val _sync = MutableStateFlow(SyncInfo())
    val sync: StateFlow<SyncInfo> = _sync.asStateFlow()

    private var appliedSpeed = 1f
    private var nudging = false
    private var scheduleJob: Job? = null
    private var scheduledFor = 0L
    private var lastSeekAt = 0L
    private var recoverKey = ""
    private var recoverCount = 0
    private var lastRecoverAt = 0L
    private var runwayJob: Job? = null
    private var lastRunwayAt = -RUNWAY_RETRY_MS
    private var watchedRequestId: String? = null
    private var timeoutJob: Job? = null
    private var clearJob: Job? = null
    private var incomingExpiryJob: Job? = null

    override val active: Boolean
        get() = rooms.room.value.let { it.connected && it.code != null }

    fun start() {
        if (started) return
        started = true
        player.roomHook = this
        scope.launch { rooms.state.collect { reconcile() } }
        scope.launch { rooms.queue.collect { reconcile() } }
        scope.launch { rooms.offsetMs.collect { reconcile() } }
        scope.launch { rooms.request.collect { onRequestChanged(it) } }
        scope.launch { rooms.stateLoaded.collect { if (it) onRoomReady() } }
        scope.launch {
            rooms.room.map { it.code }.distinctUntilChanged().collect { code ->
                if (code == null) onRoomLeft()
            }
        }
        // The 1-second heartbeat: this is the "auto sync every second".
        scope.launch {
            while (true) {
                delay(1000)
                if (active) {
                    reconcile()
                    requestRunway()
                }
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    private fun onRoomReady() {
        if (!active) return
        player.roomEntered()
        val st = rooms.state.value
        if (st?.track == null && rooms.room.value.isHost) {
            // Empty room: the host's current song becomes the room's music.
            val snap = player.snapshotQueue()
            val cur = snap.items.getOrNull(snap.index)
            if (cur != null && player.hasMedia) {
                val q = RoomQueue(rooms.queue.value.rev + 1, snap.items, snap.autoIds)
                val s = RoomPlayState(
                    seq = (st?.seq ?: 0L) + 1,
                    index = snap.index,
                    track = cur,
                    isPlaying = player.livePlayWhenReady,
                    positionMs = player.livePositionMs,
                    anchorTs = rooms.serverNow(),
                    by = rooms.myId,
                    byName = rooms.myName
                )
                rooms.publishQueueAndState(q, s)
            }
        }
        reconcile()
    }

    private fun onRoomLeft() {
        scheduleJob?.cancel()
        runwayJob?.cancel()
        timeoutJob?.cancel()
        clearJob?.cancel()
        incomingExpiryJob?.cancel()
        watchedRequestId = null
        _incoming.value = null
        _outgoing.value = null
        nudging = false
        appliedSpeed = 1f
        _sync.value = SyncInfo()
        player.roomLeft()
    }

    // ------------------------------------------------------------------ the sync loop

    private fun reconcile() {
        if (!active) return
        val st = rooms.state.value ?: return
        val track = st.track
        if (track == null) {
            if (player.hasMedia) player.roomStop()
            _sync.value = SyncInfo()
            return
        }
        mirrorQueue(st, track)
        val now = rooms.serverNow()

        // 1) right song?
        if (player.liveMediaId != track.id) {
            if (player.isLoading(track.id)) return
            if (player.loadFailedId == track.id &&
                SystemClock.elapsedRealtime() - player.loadFailedAt < 8000L
            ) return
            loadTrack(track)
            return
        }

        val pb = player.livePlaybackState
        if (pb == Player.STATE_IDLE) {
            recover(track, st)
            return
        }
        if (pb == Player.STATE_ENDED) return

        val mono = SystemClock.elapsedRealtime()
        val coolingDown = mono - lastSeekAt < SEEK_COOLDOWN_MS
        val live = player.livePositionMs

        // 2) scheduled start (song picked a moment ago: everybody waits for the same instant)
        if (st.isPlaying && now < st.anchorTs - START_SLACK_MS) {
            scheduleReconcileAt(st.anchorTs)
            if (player.livePlayWhenReady) player.roomPlay(false)
            if (!coolingDown && abs(live - st.positionMs) > 400L) {
                player.roomSeek(st.positionMs)
                lastSeekAt = mono
            }
            setSpeed(1f)
            nudging = false
            _sync.value = SyncInfo(0L, false, waiting = true)
            return
        }

        // 3) play / pause
        val wantPlay = st.isPlaying
        if (player.livePlayWhenReady != wantPlay) player.roomPlay(wantPlay)
        if (!wantPlay) {
            if (!coolingDown && abs(live - st.positionMs) > 250L) {
                player.roomSeek(st.positionMs)
                lastSeekAt = mono
            }
            setSpeed(1f)
            nudging = false
            _sync.value = SyncInfo()
            return
        }

        // 4) position: chase the shared timeline
        if (pb != Player.STATE_READY) return // buffering: wait, the drift is corrected afterwards
        if (coolingDown) return
        val expected = st.expectedPositionMs(now)
        val dur = player.liveDurationMs
        if (dur > 0L && expected > dur + 1500L) return // timeline already past the end; ENDED handles it
        val drift = live - expected
        if (abs(drift) > SyncMath.HARD_SEEK_MS) {
            player.roomSeek(expected + SEEK_LEAD_MS)
            lastSeekAt = mono
            setSpeed(1f)
            nudging = false
        } else {
            val s = SyncMath.speedFor(drift, nudging)
            nudging = s != 1f
            setSpeed(s)
        }
        _sync.value = SyncInfo(drift, nudging, false)
    }

    private fun setSpeed(s: Float) {
        if (s == appliedSpeed) return
        if (s != 1f && abs(s - appliedSpeed) < 0.004f) return
        appliedSpeed = s
        player.roomSetSpeed(s)
    }

    private fun loadTrack(track: Track) {
        appliedSpeed = 1f
        nudging = false
        player.roomLoadTrack(
            track,
            startProvider = {
                val s = rooms.state.value
                if (s != null && s.track?.id == track.id) {
                    s.expectedPositionMs(rooms.serverNow()).coerceAtLeast(0L)
                } else 0L
            },
            playProvider = {
                val s = rooms.state.value
                s != null && s.track?.id == track.id && s.isPlaying &&
                    rooms.serverNow() >= s.anchorTs - START_SLACK_MS
            }
        )
        rooms.state.value?.let { if (it.isPlaying) scheduleReconcileAt(it.anchorTs) }
    }

    /** Player went IDLE with the right song loaded (stream error): retry a few times. */
    private fun recover(track: Track, st: RoomPlayState) {
        val key = "${track.id}#${st.seq}"
        if (key != recoverKey) {
            recoverKey = key
            recoverCount = 0
        }
        val mono = SystemClock.elapsedRealtime()
        if (recoverCount >= 3 || mono - lastRecoverAt < 5000L) return
        recoverCount++
        lastRecoverAt = mono
        loadTrack(track)
    }

    private fun scheduleReconcileAt(ts: Long) {
        if (scheduledFor == ts && scheduleJob?.isActive == true) return
        scheduledFor = ts
        scheduleJob?.cancel()
        scheduleJob = scope.launch {
            val wait = ts - rooms.serverNow()
            if (wait > 0L) delay(wait)
            reconcile()
        }
    }

    private fun mirrorQueue(st: RoomPlayState, track: Track) {
        val q = rooms.queue.value
        if (q.items.isEmpty()) {
            player.roomApplyQueue(listOf(track), 0, emptySet())
            return
        }
        val idx = if (q.items.getOrNull(st.index)?.id == track.id) st.index
        else q.items.indexOfFirst { it.id == track.id }
        if (idx < 0) player.roomApplyQueue(listOf(track), 0, emptySet()) // queue not here yet
        else player.roomApplyQueue(q.items, idx, q.autoIds)
    }

    // ------------------------------------------------------------------ writing to the room

    private fun trackState(t: Track, index: Int, leadMs: Long, anchor: Long? = null): RoomPlayState =
        RoomPlayState(
            seq = (rooms.state.value?.seq ?: 0L) + 1,
            index = index,
            track = t,
            isPlaying = true,
            positionMs = 0L,
            anchorTs = anchor ?: (rooms.serverNow() + leadMs),
            by = rooms.myId,
            byName = rooms.myName
        )

    private fun publishJump(index: Int) {
        val t = rooms.queue.value.items.getOrNull(index) ?: return
        rooms.publishState(trackState(t, index, USER_LEAD_MS))
    }

    private fun publishSeek(positionMs: Long) {
        val st = rooms.state.value ?: return
        rooms.publishState(
            st.copy(
                seq = st.seq + 1,
                positionMs = positionMs.coerceAtLeast(0L),
                anchorTs = rooms.serverNow(),
                by = rooms.myId,
                byName = rooms.myName
            )
        )
    }

    private fun toast(msg: String) {
        _events.tryEmit(msg)
    }

    private fun canControlRoom(): Boolean {
        if (rooms.room.value.isHost) return true
        toast("เฉพาะ Host/DJ ของห้องเป็นคนควบคุมเพลง")
        return false
    }

    /** Force this device onto the room timeline immediately; the room state is unchanged. */
    fun forceResync() {
        if (!active) return
        val st = rooms.state.value ?: return
        val track = st.track ?: return
        if (player.liveMediaId != track.id) {
            loadTrack(track)
            return
        }
        val expected = st.expectedPositionMs(rooms.serverNow()).coerceAtLeast(0L)
        player.roomSeek(expected)
        setSpeed(1f)
        nudging = false
        _sync.value = SyncInfo(player.livePositionMs - expected, false, false)
    }

    // ------------------------------------------------------------------ RoomHook: user intents

    override fun onPlay(track: Track, queue: List<Track>, startIndex: Int): Boolean {
        val st = rooms.state.value
        val shared = rooms.queue.value
        val sharedIds = shared.items.map { it.id }
        val sameList = sharedIds.isNotEmpty() && queue.map { it.id } == sharedIds
        val inShared = track.id in sharedIds
        val nothingPlaying = st?.track == null
        val alone = rooms.room.value.peerCount <= 1

        when {
            // Part of the playlist we're already listening to -> change right away.
            !nothingPlaying && (sameList || (inShared && queue.size == 1)) -> {
                val idx = if (sameList) startIndex else sharedIds.indexOf(track.id)
                publishJump(idx)
            }
            // Host can start the room. A guest always asks the Host/DJ first.
            nothingPlaying || alone -> {
                if (rooms.room.value.isHost) {
                    val q = RoomQueue(shared.rev + 1, queue, emptySet())
                    rooms.publishQueueAndState(q, trackState(track, startIndex, USER_LEAD_MS))
                } else {
                    sendRequest(track, queue, startIndex)
                }
            }
            // Not part of the playlist -> ask the other side first.
            else -> sendRequest(track, queue, startIndex)
        }
        return true
    }

    private fun sendRequest(track: Track, queue: List<Track>, startIndex: Int) {
        val from = (startIndex - MAX_REQUEST_QUEUE / 2).coerceAtLeast(0)
        val to = min(queue.size, from + MAX_REQUEST_QUEUE)
        val sub = queue.subList(from, to)
        val req = RoomRequest(
            id = UUID.randomUUID().toString(),
            by = rooms.myId,
            byName = rooms.myName,
            status = RoomRequest.STATUS_PENDING,
            ts = rooms.serverNow(),
            track = track,
            queue = sub,
            autoIds = emptySet(),
            startIndex = startIndex - from
        )
        rooms.createRequest(req) { ok ->
            if (!ok) toast("มีคำขอเปลี่ยนเพลงรออยู่แล้ว รอให้อีกฝ่ายตอบก่อน")
        }
    }

    override fun onPlayPause(): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value ?: return true
        val now = rooms.serverNow()
        rooms.publishState(
            st.copy(
                seq = st.seq + 1,
                isPlaying = !st.isPlaying,
                positionMs = st.expectedPositionMs(now),
                anchorTs = now,
                by = rooms.myId,
                byName = rooms.myName
            )
        )
        return true
    }

    override fun onSeek(positionMs: Long): Boolean {
        if (!canControlRoom()) return true
        publishSeek(positionMs)
        return true
    }

    override fun onSkip(delta: Int): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value ?: return true
        val q = rooms.queue.value
        if (delta > 0) {
            val next = st.index + 1
            if (next in q.items.indices) {
                publishJump(next)
            } else {
                toast("ยังไม่มีเพลงถัดไป กำลังหาเพลงต่อ…")
                lastRunwayAt = -RUNWAY_RETRY_MS
                requestRunway()
            }
        } else {
            val pos = st.expectedPositionMs(rooms.serverNow())
            if (pos > 3000L || st.index <= 0) publishSeek(0L) else publishJump(st.index - 1)
        }
        return true
    }

    override fun onPlayAt(index: Int): Boolean {
        if (!canControlRoom()) return true
        if (index in rooms.queue.value.items.indices) publishJump(index)
        return true
    }

    override fun onAddToQueue(track: Track, playNext: Boolean): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value
        val cur = st?.track
        if (st == null || cur == null) return onPlay(track, listOf(track), 0)
        val q = rooms.queue.value
        if (q.items.any { it.id == track.id }) {
            toast("มีเพลงนี้ในคิวของห้องแล้ว")
            return true
        }
        val items = q.items.toMutableList()
        val at = if (playNext) (st.index + 1).coerceAtMost(items.size) else items.size
        items.add(at, track)
        rooms.publishQueue(RoomQueue(q.rev + 1, items, q.autoIds))
        toast("เพิ่มในคิวของห้องแล้ว")
        return true
    }

    override fun onRemoveFromQueue(index: Int): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value ?: return true
        val q = rooms.queue.value
        if (index !in q.items.indices || index == st.index) return true
        val items = q.items.toMutableList()
        val removed = items.removeAt(index)
        val newIdx = if (index < st.index) st.index - 1 else st.index
        rooms.publishQueueAndState(
            RoomQueue(q.rev + 1, items, q.autoIds - removed.id),
            st.copy(index = newIdx)
        )
        return true
    }

    override fun onReorderQueue(from: Int, to: Int): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value ?: return true
        val q = rooms.queue.value
        if (from !in q.items.indices || to !in q.items.indices) return true
        val items = q.items.toMutableList()
        items.add(to, items.removeAt(from))
        val curId = st.track?.id
        val newIdx = items.indexOfFirst { it.id == curId }.let { if (it < 0) st.index else it }
        rooms.publishQueueAndState(RoomQueue(q.rev + 1, items, q.autoIds), st.copy(index = newIdx))
        return true
    }

    override fun onClearQueue(): Boolean {
        if (!canControlRoom()) return true
        val st = rooms.state.value
        val q = rooms.queue.value
        rooms.publishQueueAndState(
            RoomQueue(q.rev + 1, emptyList(), emptySet()),
            RoomPlayState(seq = (st?.seq ?: 0L) + 1, by = rooms.myId, byName = rooms.myName)
        )
        return true
    }

    // ------------------------------------------------------------------ RoomHook: player events

    override fun onTrackEnded(mediaId: String?, durationMs: Long) {
        if (!rooms.room.value.isHost) return
        val st = rooms.state.value ?: return
        val cur = st.track ?: return
        if (cur.id != mediaId || !st.isPlaying) return
        val next = st.index + 1
        // The next song starts at a moment fixed by the OLD timeline, so two phones that both notice
        // "song ended" write (almost) the same thing and nobody drifts by the notice delay.
        val oldEnd = if (durationMs > 0L) st.anchorTs + (durationMs - st.positionMs) else rooms.serverNow()
        val anchor = oldEnd + AUTO_GAP_MS

        val t = rooms.queue.value.items.getOrNull(next)
        if (t != null) {
            rooms.publishState(trackState(t, next, 0L, anchor))
            return
        }

        // Last song of the shared playlist and the auto-continue batch hasn't arrived yet.
        scope.launch {
            val base = rooms.queue.value
            if (!rooms.room.value.isHost) delay(1500)
            if (rooms.queue.value.items.size <= next) {
                val batch = player.buildAutoplayBatch(base.items, base.autoIds)
                if (batch.isNotEmpty()) rooms.appendQueueIfUnchanged(base.rev, batch) { }
            }
            var waited = 0
            while (rooms.queue.value.items.size <= next && waited < 4000) {
                delay(100)
                waited += 100
            }
            val now = rooms.state.value
            if (now != null && now.track?.id == cur.id) { // nobody moved on meanwhile
                val t2 = rooms.queue.value.items.getOrNull(next)
                if (t2 != null) {
                    val a = maxOf(anchor, rooms.serverNow() + USER_LEAD_MS)
                    rooms.publishState(trackState(t2, next, 0L, a))
                } else {
                    rooms.publishState(
                        now.copy(
                            seq = now.seq + 1,
                            isPlaying = false,
                            positionMs = durationMs.coerceAtLeast(0L),
                            anchorTs = rooms.serverNow(),
                            by = rooms.myId,
                            byName = rooms.myName
                        )
                    )
                }
            }
        }
    }

    override fun onExternalPlayWhenReady(playWhenReady: Boolean) {
        val st = rooms.state.value ?: return
        val cur = st.track ?: return
        if (st.isPlaying == playWhenReady) return
        if (player.liveMediaId != cur.id) return
        val now = rooms.serverNow()
        if (st.isPlaying && now < st.anchorTs) return // we paused ourselves while waiting for the start
        rooms.publishState(
            st.copy(
                seq = st.seq + 1,
                isPlaying = playWhenReady,
                positionMs = st.expectedPositionMs(now),
                anchorTs = now,
                by = rooms.myId,
                byName = rooms.myName
            )
        )
    }

    override fun onNeedMoreTracks() {
        requestRunway()
    }

    /** Keep >= 2 songs queued behind the current one. First phone to write wins. */
    private fun requestRunway() {
        if (!rooms.room.value.isHost) return
        if (runwayJob?.isActive == true) return
        val mono = SystemClock.elapsedRealtime()
        if (mono - lastRunwayAt < RUNWAY_RETRY_MS) return
        val st = rooms.state.value ?: return
        if (st.track == null) return
        if (rooms.queue.value.items.size - 1 - st.index >= 2) return
        lastRunwayAt = mono
        runwayJob = scope.launch {
            if (!rooms.room.value.isHost) delay(4000) // let the host do it first
            val q = rooms.queue.value
            val s = rooms.state.value ?: return@launch
            if (q.items.size - 1 - s.index >= 2) return@launch
            val batch = player.buildAutoplayBatch(q.items, q.autoIds)
            if (batch.isNotEmpty()) rooms.appendQueueIfUnchanged(q.rev, batch) { }
        }
    }

    // ------------------------------------------------------------------ change-song requests

    private fun onRequestChanged(r: RoomRequest?) {
        val me = rooms.myId
        if (r == null) {
            _incoming.value = null
            incomingExpiryJob?.cancel()
            if (_outgoing.value?.status == OutStatus.WAITING) _outgoing.value = null
            timeoutJob?.cancel()
            watchedRequestId = null
            return
        }
        if (r.by == me) {
            _incoming.value = null
            val status = when (r.status) {
                RoomRequest.STATUS_PENDING -> OutStatus.WAITING
                RoomRequest.STATUS_ACCEPTED -> OutStatus.APPROVED
                RoomRequest.STATUS_REJECTED -> OutStatus.REJECTED
                RoomRequest.STATUS_EXPIRED -> OutStatus.EXPIRED
                else -> null
            } ?: return
            _outgoing.value = OutgoingUi(r.id, r.track?.title ?: "", status)
            if (status == OutStatus.WAITING) {
                if (watchedRequestId != r.id) {
                    watchedRequestId = r.id
                    timeoutJob?.cancel()
                    val left = (FirebaseRoomRepository.REQUEST_TTL_MS - (rooms.serverNow() - r.ts))
                        .coerceAtLeast(1000L)
                    timeoutJob = scope.launch {
                        delay(left)
                        rooms.setRequestStatus(r.id, RoomRequest.STATUS_EXPIRED)
                    }
                }
            } else {
                timeoutJob?.cancel()
                watchedRequestId = null
                clearJob?.cancel()
                clearJob = scope.launch {
                    delay(RESULT_SHOW_MS)
                    if (_outgoing.value?.id == r.id) _outgoing.value = null
                    rooms.clearRequest(r.id)
                }
            }
        } else {
            _outgoing.value = null
            val left = FirebaseRoomRepository.REQUEST_TTL_MS - (rooms.serverNow() - r.ts)
            val show = rooms.room.value.isHost && r.status == RoomRequest.STATUS_PENDING && left > 0L && r.track != null
            incomingExpiryJob?.cancel()
            _incoming.value = if (show) r else null
            if (show) {
                incomingExpiryJob = scope.launch {
                    delay(left)
                    if (_incoming.value?.id == r.id) _incoming.value = null
                }
            }
        }
    }

    /** Friend accepted: the room switches to the requested song (and its playlist) for both of us. */
    fun approve() {
        if (!rooms.room.value.isHost) return
        val r = _incoming.value ?: return
        _incoming.value = null
        val q = r.queue.ifEmpty { listOfNotNull(r.track) }
        if (q.isEmpty()) return
        val idx = r.startIndex.coerceIn(0, q.lastIndex)
        val newQueue = RoomQueue(rooms.queue.value.rev + 1, q, r.autoIds)
        rooms.acceptRequest(newQueue, trackState(q[idx], idx, APPROVE_LEAD_MS))
    }

    fun decline() {
        if (!rooms.room.value.isHost) return
        val r = _incoming.value ?: return
        _incoming.value = null
        rooms.setRequestStatus(r.id, RoomRequest.STATUS_REJECTED)
    }

    fun cancelMyRequest() {
        val o = _outgoing.value ?: return
        _outgoing.value = null
        timeoutJob?.cancel()
        watchedRequestId = null
        rooms.clearRequest(o.id)
    }
}
