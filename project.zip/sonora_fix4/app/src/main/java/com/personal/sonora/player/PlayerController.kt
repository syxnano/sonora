package com.personal.sonora.player

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.recommend.DiscoverEngine
import com.personal.sonora.data.resolver.YouTubeResolver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

data class PlayerUiState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val codec: String? = null,
    val bitrate: Int = 0,
    val error: String? = null
)

/**
 * Implemented by the "Listen with friends" coordinator. While a room is [active], every user
 * intent (play / pause / seek / skip / queue edits) is handed to the room instead of acting on the
 * local player; the room then drives the local player through the room* functions below.
 * Return true = "handled, don't touch the local player".
 */
interface RoomHook {
    val active: Boolean
    fun onPlay(track: Track, queue: List<Track>, startIndex: Int): Boolean
    fun onPlayPause(): Boolean
    fun onSeek(positionMs: Long): Boolean
    fun onSkip(delta: Int): Boolean
    fun onPlayAt(index: Int): Boolean
    fun onAddToQueue(track: Track, playNext: Boolean): Boolean
    fun onRemoveFromQueue(index: Int): Boolean
    fun onReorderQueue(from: Int, to: Int): Boolean
    fun onClearQueue(): Boolean

    /** Local player reached the end of [mediaId]. */
    fun onTrackEnded(mediaId: String?, durationMs: Long)

    /** playWhenReady changed for a reason we did not cause (notification button, headset, call...). */
    fun onExternalPlayWhenReady(playWhenReady: Boolean)

    /** Queue is about to run out: room should append more tracks. */
    fun onNeedMoreTracks()
}

data class QueueSnapshot(val items: List<Track>, val index: Int, val autoIds: Set<String>)

@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val resolver: YouTubeResolver,
    private val youtubeEmbed: YouTubeEmbedController,
    private val offlineTrackDao: com.personal.sonora.data.db.OfflineTrackDao,
    private val discover: DiscoverEngine
) {
    private class PendingLoad(val item: MediaItem, val startMs: Long, val play: Boolean, val trackId: String)
    private class RoomProviders(val start: () -> Long, val play: () -> Boolean)

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    // Any uncaught error inside a player coroutine is shown on screen instead of killing the app.
    private val errorHandler = CoroutineExceptionHandler { _, e ->
        _state.value = _state.value.copy(
            error = "Player error: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
        )
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + errorHandler)

    private val queue = mutableListOf<Track>()
    private var currentIndex = 0
    private val autoIds = mutableSetOf<String>()
    private var originalOrder: List<Track>? = null
    private var pending: PendingLoad? = null
    private var retriedTrackId: String? = null
    private var repeat = Player.REPEAT_MODE_OFF

    private var loadJob: Job? = null
    private var loadToken = 0L
    private var loadingId: String? = null
    private var autoplayJob: Job? = null
    private var providers: RoomProviders? = null

    @Volatile
    var roomHook: RoomHook? = null

    /** Last track whose stream could not be resolved, and when (lets the room avoid retry-spam). */
    var loadFailedId: String? = null
        private set
    var loadFailedAt: Long = 0L
        private set

    /** Last time the room itself changed the player (used to ignore our own callbacks). */
    @Volatile
    var lastRoomApplyAt: Long = 0L
        private set

    private inline fun inRoom(block: (RoomHook) -> Boolean): Boolean {
        val h = roomHook ?: return false
        return h.active && block(h)
    }

    // ---------------------------------------------------------------- connection

    fun connect() {
        if (controller != null || controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            try {
                val c = controllerFuture?.get()
                controller = c
                c?.addListener(playerListener)
                val p = pending
                if (c != null && p != null) {
                    c.setPlaybackSpeed(1f)
                    c.setMediaItem(p.item, p.startMs)
                    c.prepare()
                    if (p.play) c.play() else c.pause()
                    pending = null
                }
                syncState()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = "Player service error: ${e.message}")
            }
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    // ---------------------------------------------------------------- user intents

    fun play(track: Track, newQueue: List<Track> = listOf(track), startIndex: Int = 0) {
        val (q, idx) = normalize(track, newQueue, startIndex)
        if (inRoom { it.onPlay(q[idx], q, idx) }) return
        providers = null
        localSetQueue(q, idx)
        retriedTrackId = null
        startLoad(q[idx])
    }

    fun playNext(track: Track) {
        if (inRoom { it.onAddToQueue(track, true) }) return
        val insertAt = (currentIndex + 1).coerceAtMost(queue.size)
        queue.add(insertAt, track)
        originalOrder = originalOrder?.plus(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun addToQueue(track: Track) {
        if (inRoom { it.onAddToQueue(track, false) }) return
        queue.add(track)
        originalOrder = originalOrder?.plus(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun togglePlayPause() {
        if (inRoom { it.onPlayPause() }) return
        if (isYouTubeTrack(_state.value.currentTrack)) {
            youtubeEmbed.toggle()
            return
        }
        val c = controller ?: return
        if (c.playbackState == Player.STATE_ENDED) {
            c.seekTo(0)
            c.play()
        } else if (c.playWhenReady) {
            c.pause()
        } else {
            c.play()
        }
    }

    fun playAt(index: Int) {
        if (inRoom { it.onPlayAt(index) }) return
        if (index !in queue.indices) return
        providers = null
        currentIndex = index
        retriedTrackId = null
        startLoad(queue[index])
    }

    fun skipNext() {
        if (inRoom { it.onSkip(+1) }) return
        localNext(userInitiated = true)
    }

    fun skipPrevious() {
        if (inRoom { it.onSkip(-1) }) return
        if ((controller?.currentPosition ?: 0L) > 3000L) {
            controller?.seekTo(0)
        } else if (currentIndex > 0) {
            providers = null
            currentIndex--
            retriedTrackId = null
            startLoad(queue[currentIndex])
        } else {
            controller?.seekTo(0)
        }
    }

    fun seekTo(ms: Long) {
        if (inRoom { it.onSeek(ms) }) return
        if (isYouTubeTrack(_state.value.currentTrack)) {
            youtubeEmbed.seekTo(ms)
            return
        }
        controller?.seekTo(ms)
        _state.value = _state.value.copy(positionMs = ms)
    }

    fun setShuffle(enabled: Boolean) {
        if (blockedInRoom()) return
        setShuffleInternal(enabled)
    }

    fun cycleRepeat() {
        if (blockedInRoom()) return
        repeat = when (repeat) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        // ONE is looped by the player itself; ALL is handled by our own queue (wrap-around).
        controller?.repeatMode =
            if (repeat == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        _state.value = _state.value.copy(repeatMode = repeat)
    }

    fun clearQueue() {
        if (inRoom { it.onClearQueue() }) return
        autoplayJob?.cancel()
        loadJob?.cancel()
        loadingId = null
        providers = null
        queue.clear()
        autoIds.clear()
        originalOrder = null
        currentIndex = 0
        controller?.stop()
        controller?.clearMediaItems()
        _state.value = PlayerUiState(shuffle = _state.value.shuffle, repeatMode = repeat)
    }

    fun reorderQueue(from: Int, to: Int) {
        if (inRoom { it.onReorderQueue(from, to) }) return
        if (from in queue.indices && to in queue.indices) {
            val item = queue.removeAt(from)
            queue.add(to, item)
            when {
                currentIndex == from -> currentIndex = to
                from < currentIndex && to >= currentIndex -> currentIndex--
                from > currentIndex && to <= currentIndex -> currentIndex++
            }
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun removeFromQueue(index: Int) {
        if (inRoom { it.onRemoveFromQueue(index) }) return
        if (index in queue.indices && index != currentIndex) {
            val removed = queue.removeAt(index)
            autoIds.remove(removed.id)
            originalOrder = originalOrder?.filter { it.id != removed.id }
            if (index < currentIndex) currentIndex--
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun updatePosition() {
        if (isYouTubeTrack(_state.value.currentTrack)) {
            val y = youtubeEmbed.state.value
            _state.value = _state.value.copy(
                isPlaying = y.isPlaying,
                positionMs = y.positionMs,
                durationMs = y.durationMs.coerceAtLeast(_state.value.currentTrack?.durationMs ?: 0L)
            )
            return
        }
        controller?.let {
            _state.value = _state.value.copy(
                positionMs = it.currentPosition,
                durationMs = it.duration.coerceAtLeast(0)
            )
        }
    }

    // ---------------------------------------------------------------- room API (driven by RoomPlaybackCoordinator)

    val liveMediaId: String? get() = if (isYouTubeTrack(_state.value.currentTrack)) _state.value.currentTrack?.id else controller?.currentMediaItem?.mediaId
    val livePositionMs: Long get() = if (isYouTubeTrack(_state.value.currentTrack)) youtubeEmbed.state.value.positionMs else controller?.currentPosition ?: 0L
    val liveDurationMs: Long get() = if (isYouTubeTrack(_state.value.currentTrack)) youtubeEmbed.state.value.durationMs.coerceAtLeast(_state.value.currentTrack?.durationMs ?: 0L) else (controller?.duration ?: 0L).coerceAtLeast(0L)
    val livePlayWhenReady: Boolean get() = if (isYouTubeTrack(_state.value.currentTrack)) youtubeEmbed.state.value.isPlaying else controller?.playWhenReady ?: false
    val livePlaybackState: Int get() = if (isYouTubeTrack(_state.value.currentTrack)) if (youtubeEmbed.state.value.isPlaying) Player.STATE_READY else Player.STATE_READY else controller?.playbackState ?: Player.STATE_IDLE
    val hasMedia: Boolean get() = controller?.currentMediaItem != null

    /** true while [id] is being resolved / waiting for the service connection. */
    fun isLoading(id: String): Boolean = loadingId == id || pending?.trackId == id

    fun snapshotQueue() = QueueSnapshot(queue.toList(), currentIndex, autoIds.toSet())

    /** Replace the local queue with the room's queue without touching playback. */
    fun roomApplyQueue(items: List<Track>, index: Int, auto: Set<String>) {
        val same = queue.size == items.size && queue.indices.all { queue[it].id == items[it].id }
        val idx = index.coerceIn(0, (items.size - 1).coerceAtLeast(0))
        if (same && currentIndex == idx && autoIds == auto) return
        queue.clear()
        queue.addAll(items)
        currentIndex = idx
        autoIds.clear()
        autoIds.addAll(auto)
        originalOrder = null
        _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
    }

    /**
     * Load [track] for the room. [startProvider] / [playProvider] are evaluated AFTER the stream
     * has been resolved, so the time spent resolving doesn't put us behind the shared timeline.
     */
    fun roomLoadTrack(track: Track, startProvider: () -> Long, playProvider: () -> Boolean) {
        lastRoomApplyAt = SystemClock.elapsedRealtime()
        val idx = queue.indexOfFirst { it.id == track.id }
        if (idx >= 0) currentIndex = idx
        providers = RoomProviders(startProvider, playProvider)
        retriedTrackId = null
        startLoad(track)
    }

    fun roomPlay(play: Boolean) {
        lastRoomApplyAt = SystemClock.elapsedRealtime()
        if (isYouTubeTrack(_state.value.currentTrack)) {
            if (play) youtubeEmbed.play() else youtubeEmbed.pause()
            return
        }
        val c = controller ?: return
        if (play) c.play() else c.pause()
    }

    fun roomSeek(ms: Long) {
        lastRoomApplyAt = SystemClock.elapsedRealtime()
        if (isYouTubeTrack(_state.value.currentTrack)) {
            youtubeEmbed.seekTo(ms)
            return
        }
        controller?.seekTo(ms.coerceAtLeast(0L))
    }

    fun roomSetSpeed(speed: Float) {
        if (isYouTubeTrack(_state.value.currentTrack)) youtubeEmbed.setSpeed(speed) else controller?.setPlaybackSpeed(speed)
    }

    fun roomStop() {
        lastRoomApplyAt = SystemClock.elapsedRealtime()
        loadJob?.cancel()
        loadingId = null
        controller?.stop()
        controller?.clearMediaItems()
        _state.value = _state.value.copy(currentTrack = null, isPlaying = false, positionMs = 0L, durationMs = 0L)
    }

    /** Called when we join a room: modes that can't be shared are switched off. */
    fun roomEntered() {
        if (repeat != Player.REPEAT_MODE_OFF) {
            repeat = Player.REPEAT_MODE_OFF
            controller?.repeatMode = Player.REPEAT_MODE_OFF
            _state.value = _state.value.copy(repeatMode = repeat)
        }
        if (_state.value.shuffle) setShuffleInternal(false)
        autoplayJob?.cancel()
    }

    /** Called when we leave a room: keep playing locally at normal speed. */
    fun roomLeft() {
        providers = null
        controller?.setPlaybackSpeed(1f)
    }

    /** More songs in the style of the (non-auto) tracks of [items]. */
    suspend fun buildAutoplayBatch(items: List<Track>, auto: Set<String>): List<Track> {
        val seeds = items.filter { it.id !in auto }.ifEmpty { items.takeLast(10) }
        if (seeds.isEmpty()) return emptyList()
        return try {
            withContext(Dispatchers.IO) {
                discover.autoplayFor(seeds, items.map { it.id }.toHashSet(), 15)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            emptyList()
        }
    }

    // ---------------------------------------------------------------- internals

    private fun normalize(track: Track, newQueue: List<Track>, startIndex: Int): Pair<List<Track>, Int> {
        val q = newQueue.ifEmpty { listOf(track) }
        val idx = if (q.getOrNull(startIndex)?.id == track.id) startIndex
        else q.indexOfFirst { it.id == track.id }
        return if (idx >= 0) q to idx else (listOf(track) + q) to 0
    }

    private fun localSetQueue(q: List<Track>, idx: Int) {
        queue.clear()
        queue.addAll(q)
        currentIndex = idx.coerceIn(0, queue.lastIndex.coerceAtLeast(0))
        autoIds.clear()
        originalOrder = null
        if (_state.value.shuffle && queue.size > 1) shuffleKeepingCurrent()
    }

    private fun shuffleKeepingCurrent() {
        originalOrder = queue.toList()
        val cur = queue.getOrNull(currentIndex)
        val rest = queue.filterIndexed { i, _ -> i != currentIndex }.shuffled()
        queue.clear()
        if (cur != null) queue.add(cur)
        queue.addAll(rest)
        currentIndex = 0
    }

    private fun setShuffleInternal(enabled: Boolean) {
        if (enabled == _state.value.shuffle) return
        if (enabled) {
            if (queue.size > 1) shuffleKeepingCurrent()
        } else {
            val orig = originalOrder
            if (orig != null) {
                val cur = queue.getOrNull(currentIndex)
                val extras = queue.filter { q -> orig.none { it.id == q.id } }
                queue.clear()
                queue.addAll(orig + extras)
                currentIndex = cur?.let { c -> queue.indexOfFirst { it.id == c.id } }
                    ?.takeIf { it >= 0 } ?: 0
            }
            originalOrder = null
        }
        _state.value = _state.value.copy(
            shuffle = enabled,
            queue = queue.toList(),
            queueIndex = currentIndex
        )
    }

    private fun blockedInRoom(): Boolean {
        val h = roomHook
        if (h != null && h.active) {
            notice("ใช้ไม่ได้ตอนฟังกับเพื่อน (คิวเป็นของห้อง)")
            return true
        }
        return false
    }

    private fun notice(msg: String) {
        _state.value = _state.value.copy(error = msg)
        scope.launch {
            delay(3500)
            if (_state.value.error == msg) _state.value = _state.value.copy(error = null)
        }
    }

    /** Start loading [track]; any load still in flight is cancelled so an older tap can't win. */
    private fun openExternalProvider(track: Track) {
        val url = when (track.source.lowercase()) {
            "spotify" -> "https://open.spotify.com/track/${track.externalId}"
            "apple" -> "https://music.apple.com/"
            else -> "https://music.youtube.com/watch?v=${track.externalId}"
        }
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            _state.value = _state.value.copy(currentTrack = track, isPlaying = false, positionMs = 0L, durationMs = track.durationMs)
        }.onFailure {
            _state.value = _state.value.copy(error = "เปิดบริการเพลงภายนอกไม่ได้")
        }
    }

    private fun isYouTubeTrack(track: Track?): Boolean =
        track?.source.equals("youtube", ignoreCase = true) &&
            track?.externalId?.matches(Regex("[A-Za-z0-9_-]{11}")) == true

    private fun startLoad(track: Track) {
        // YouTube catalog tracks stay inside Sonora through the official YouTube IFrame player.
        // Other external providers keep the existing hand-off behavior.
        if (isYouTubeTrack(track)) {
            loadJob?.cancel()
            loadingId = null
            _state.value = _state.value.copy(
                currentTrack = track,
                queue = queue.toList(),
                queueIndex = currentIndex,
                error = null,
                isPlaying = false,
                positionMs = 0L,
                durationMs = track.durationMs,
                codec = "YouTube"
            )
            val prov = providers
            val startMs = if (prov != null) prov.start() else 0L
            val play = if (prov != null) prov.play() else true
            if (prov != null) lastRoomApplyAt = SystemClock.elapsedRealtime()
            youtubeEmbed.open(track.externalId!!, startMs, play)
            providers = null
            return
        }
        if (track.externalId != null && track.source != "local" && track.source != "file") {
            openExternalProvider(track)
            return
        }
        loadJob?.cancel()
        val token = ++loadToken
        loadingId = track.id
        loadJob = scope.launch {
            try {
                loadAndPlay(track)
            } finally {
                if (loadToken == token) loadingId = null
            }
        }
    }

    private fun localNext(userInitiated: Boolean) {
        providers = null
        when {
            currentIndex < queue.lastIndex -> {
                currentIndex++
                retriedTrackId = null
                startLoad(queue[currentIndex])
            }
            repeat == Player.REPEAT_MODE_ALL && queue.isNotEmpty() -> {
                currentIndex = 0
                retriedTrackId = null
                startLoad(queue[0])
            }
            else -> {
                // Playlist is over: keep the music going with songs in the same style.
                autoplayJob?.cancel()
                autoplayJob = scope.launch {
                    val more = buildAutoplayBatch(queue.toList(), autoIds.toSet())
                    if (more.isNotEmpty()) {
                        appendAuto(more)
                        if (currentIndex < queue.lastIndex) {
                            currentIndex++
                            retriedTrackId = null
                            startLoad(queue[currentIndex])
                        }
                    } else if (userInitiated) {
                        notice("หาเพลงต่อไม่ได้ ตรวจอินเทอร์เน็ต / Last.fm key")
                    }
                }
            }
        }
    }

    private fun appendAuto(more: List<Track>) {
        val existing = queue.map { it.id }.toHashSet()
        val add = more.filter { existing.add(it.id) }
        if (add.isEmpty()) return
        queue.addAll(add)
        autoIds.addAll(add.map { it.id })
        originalOrder = originalOrder?.plus(add)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    /** Keep at least two songs queued behind the current one, so the end of a playlist is seamless. */
    private fun ensureRunway() {
        val h = roomHook
        if (h != null && h.active) {
            h.onNeedMoreTracks()
            return
        }
        if (repeat != Player.REPEAT_MODE_OFF) return
        if (queue.size - 1 - currentIndex >= 2) return
        if (autoplayJob?.isActive == true) return
        autoplayJob = scope.launch {
            val more = buildAutoplayBatch(queue.toList(), autoIds.toSet())
            if (more.isNotEmpty()) appendAuto(more)
        }
    }

    private suspend fun loadAndPlay(track: Track) {
        try {
            loadAndPlayInner(track)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            markFailed(track.id)
            _state.value = _state.value.copy(
                isPlaying = false,
                error = "Cannot play: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
            )
        }
    }

    private fun markFailed(id: String) {
        loadFailedId = id
        loadFailedAt = SystemClock.elapsedRealtime()
    }

    private suspend fun loadAndPlayInner(track: Track) {
        _state.value = _state.value.copy(
            currentTrack = track,
            queue = queue.toList(),
            queueIndex = currentIndex,
            error = null,
            isPlaying = false,
            positionMs = 0L,
            durationMs = 0L
        )
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .apply { track.coverUrl?.let { setArtworkUri(android.net.Uri.parse(it)) } }
            .build()

        // Downloaded songs play straight from the local file (no internet needed).
        val offline = if (retriedTrackId != track.id) {
            try {
                offlineTrackDao.get(track.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        } else null
        val mediaItem: MediaItem
        if (offline != null) {
            mediaItem = MediaItem.Builder()
                .setUri(android.net.Uri.parse(offline.localUri))
                .setMediaId(track.id)
                .setMediaMetadata(metadata)
                .build()
            _state.value = _state.value.copy(codec = offline.codec, bitrate = offline.bitrate)
        } else {
            val resolved = resolver.resolve(track, preferHighest = true)
            if (resolved == null) {
                markFailed(track.id)
                _state.value = _state.value.copy(
                    error = resolver.lastError ?: "Could not resolve stream"
                )
                return
            }
            mediaItem = MediaItem.Builder()
                .setUri(resolved.streamUrl)
                .setMediaId(track.id)
                .setMediaMetadata(metadata)
                .build()
            _state.value = _state.value.copy(codec = resolved.codec, bitrate = resolved.bitrate)
        }

        // In a room, ask the room *now* where the shared timeline is (and whether it is playing).
        val prov = providers
        val startMs = if (prov != null) prov.start() else 0L
        val play = if (prov != null) prov.play() else true
        if (prov != null) lastRoomApplyAt = SystemClock.elapsedRealtime()
        loadFailedId = null

        val c = controller
        if (c == null) {
            // Service connection not ready yet: play as soon as it connects.
            pending = PendingLoad(mediaItem, startMs, play, track.id)
            connect()
        } else {
            c.setPlaybackSpeed(1f)
            c.setMediaItem(mediaItem, startMs)
            c.prepare()
            if (play) c.play() else c.pause()
        }
        // Prefetch next track (not needed for offline files)
        if (offline == null) prefetchNext()
        ensureRunway()
    }

    private fun prefetchNext() {
        val upcoming = (1..1).mapNotNull { queue.getOrNull(currentIndex + it) }
        if (upcoming.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            for (t in upcoming) {
                try {
                    resolver.resolve(t, preferHighest = true)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // prefetch is best-effort
                }
            }
        }
    }

    private fun handleEnded() {
        val c = controller
        val h = roomHook
        if (h != null && h.active) {
            h.onTrackEnded(c?.currentMediaItem?.mediaId, (c?.duration ?: 0L).coerceAtLeast(0L))
        } else {
            localNext(userInitiated = false)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val track = _state.value.currentTrack ?: return
            if (retriedTrackId != track.id) {
                // Stream URLs expire or get rejected: drop the cache and resolve once more.
                retriedTrackId = track.id
                scope.launch {
                    resolver.invalidate(track.id)
                    startLoad(track)
                }
            } else {
                val detail = error.cause?.message ?: error.message ?: ""
                _state.value = _state.value.copy(
                    isPlaying = false,
                    error = "Playback failed (${error.errorCodeName}) $detail".take(160)
                )
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            val h = roomHook ?: return
            if (!h.active) return
            // Changes we caused ourselves arrive within ~1.5 s of the call; everything else is the
            // user (notification button, headset) or the system (call) and is shared with the room.
            if (SystemClock.elapsedRealtime() - lastRoomApplyAt < 1500L) return
            h.onExternalPlayWhenReady(playWhenReady)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) handleEnded()
            syncState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncState()
        }
    }

    private fun syncState() {
        val c = controller ?: return
        _state.value = _state.value.copy(
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0),
            repeatMode = repeat
        )
    }
}
