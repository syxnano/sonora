package com.personal.sonora.data.product

import com.personal.sonora.data.catalog.Track
import javax.inject.Inject
import javax.inject.Singleton

/** Deterministic, local ranking prototype. It never invents tracks; candidates come from catalog search. */
@Singleton
class TasteAgent @Inject constructor() {
    fun rank(request: String, taste: TasteMemory, candidates: List<Track>): AgentResult {
        val q = request.lowercase()
        val scored = candidates.map { t ->
            var score = 0
            if (t.id in taste.likedTrackIds) score += 70
            if (t.id in taste.dislikedTrackIds) score -= 120
            if (taste.likedArtists.any { t.artist.contains(it, true) }) score += 40
            if (taste.dislikedArtists.any { t.artist.contains(it, true) }) score -= 80
            if (taste.moodTags.any { tag -> q.contains(tag.lowercase()) }) score += 10
            if (taste.toneTags.any { tag -> q.contains(tag.lowercase()) }) score += 10
            if (q.contains("ไทย") && looksThai(t)) score += 25
            if (q.containsAny("ชิล", "ช้า", "calm", "ละมุน", "soft", "อบอุ่น")) score += calmScore(t)
            if (q.containsAny("เร็ว", "มัน", "energy", "สนุก", "แดนซ์", "dance")) score += energyScore(t)
            if (q.containsAny("เศร้า", "sad", "เหงา", "lonely")) score += sadScore(t)
            if (q.containsAny("มืด", "dark", "ดาร์ก")) score += darkScore(t)
            if (q.containsAny("ฝัน", "dreamy", "dream", "ล่องลอย")) score += dreamyScore(t)
            t to score
        }.sortedByDescending { it.second }
        val chosen = scored.take(10).map { it.first }
        val explanation = if (chosen.isEmpty()) "ยังหาเพลงที่ตรงเงื่อนไขจากรายการที่ตรวจแล้วไม่เจอ" else "คัดจากเพลงที่ค้นพบจริง แล้วให้น้ำหนักตามสิ่งที่คุณบอกไว้ก่อน"
        return AgentResult(chosen.map { it.id }, explanation, if (chosen.size < 3) "ลองเพิ่มเงื่อนไขหรือศิลปินที่ชอบอีกนิด" else null)
    }

    private fun looksThai(t: Track): Boolean = Regex("[ก-๙]").containsMatchIn(t.title + t.artist)
    private fun calmScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("acoustic|piano|slow|ballad", RegexOption.IGNORE_CASE))) 10 else 0
    private fun energyScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("live|mix|remix|rock|dance|party|club|festival", RegexOption.IGNORE_CASE))) 10 else 0
    private fun sadScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("sad|lonely|heart|broken|เศร้า|เหงา|ลา", RegexOption.IGNORE_CASE))) 10 else 0
    private fun darkScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("dark|night|shadow|midnight|ดาร์ก|มืด|คืน", RegexOption.IGNORE_CASE))) 10 else 0
    private fun dreamyScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("dream|cloud|moon|sleep|ambient|dreamy|ฝัน|ลอย", RegexOption.IGNORE_CASE))) 10 else 0
    private fun String.containsAny(vararg terms: String): Boolean = terms.any { contains(it, true) }
}
