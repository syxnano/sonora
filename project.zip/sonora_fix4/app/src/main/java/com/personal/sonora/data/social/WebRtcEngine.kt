package com.personal.sonora.data.social

import android.content.Context
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Real WebRTC DataChannel engine for cross-device chat + playback sync.
 * Signaling = manual copy/paste of SDP (no own server).
 * ICE = public Google STUN (optional TURN can be added later for strict NATs).
 */
@Singleton
class WebRtcEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val turnConfig: TurnConfig
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val executor = Executors.newSingleThreadExecutor()

    private var factory: PeerConnectionFactory? = null
    private var peer: PeerConnection? = null
    private var dataChannel: DataChannel? = null

    private val pendingRemoteCandidates = mutableListOf<IceCandidate>()
    private var remoteDescriptionSet = false

    private val _connectionState = MutableStateFlow(ConnState.IDLE)
    val connectionState: StateFlow<ConnState> = _connectionState.asStateFlow()

    private val _localSdp = MutableStateFlow<String?>(null)
    val localSdp: StateFlow<String?> = _localSdp.asStateFlow()

    private val _incoming = MutableSharedFlow<PeerMessage>(extraBufferCapacity = 64)
    val incoming: SharedFlow<PeerMessage> = _incoming.asSharedFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    enum class ConnState { IDLE, CREATING_OFFER, WAITING_ANSWER, CREATING_ANSWER, CONNECTING, CONNECTED, FAILED, CLOSED }

    @Serializable
    data class PeerMessage(
        val type: String, // chat | play | pause | seek | track | ping
        val text: String? = null,
        val sender: String? = null,
        val positionMs: Long = 0,
        val trackId: String? = null,
        val trackTitle: String? = null,
        val trackArtist: String? = null,
        val coverUrl: String? = null,
        val ts: Long = System.currentTimeMillis()
    )

    @Serializable
    data class SignalBundle(
        val sdpType: String, // offer | answer
        val sdp: String,
        val roomCode: String = "",
        val ice: List<IceDto> = emptyList()
    )

    @Serializable
    data class IceDto(val sdpMid: String?, val sdpMLineIndex: Int, val candidate: String)

    private val gatheredIce = mutableListOf<IceDto>()
    @Volatile private var cachedIceServers: List<PeerConnection.IceServer>? = null

    @Synchronized
    private fun ensureFactory() {
        if (factory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        factory = PeerConnectionFactory.builder()
            .setOptions(PeerConnectionFactory.Options())
            .createPeerConnectionFactory()
    }

    /**
     * STUN always free (Google).
     * TURN from third-party free tier (Metered / ExpressTurn) via local.properties —
     * you never host TURN yourself; traffic is relayed by their servers so peers
     * on different networks can connect.
     */
    private fun iceServers(): List<PeerConnection.IceServer> {
        val list = mutableListOf<PeerConnection.IceServer>()
        list += PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        list += PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        list += PeerConnection.IceServer.builder("stun:stun.relay.metered.ca:80").createIceServer()

        val urls = com.personal.sonora.BuildConfig.TURN_URLS
        val user = com.personal.sonora.BuildConfig.TURN_USERNAME
        val cred = com.personal.sonora.BuildConfig.TURN_CREDENTIAL
        if (urls.isNotBlank() && user.isNotBlank() && cred.isNotBlank()) {
            urls.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { url ->
                list += PeerConnection.IceServer.builder(url)
                    .setUsername(user)
                    .setPassword(cred)
                    .createIceServer()
            }
            Log.d(TAG, "Using ${urls.split(',').size} TURN url(s) from local.properties")
        } else {
            Log.w(TAG, "No TURN credentials — cross-network may fail. Add free Metered TURN in local.properties")
        }
        return list
    }

    private fun createPeer(): PeerConnection {
        ensureFactory()
        gatheredIce.clear()
        pendingRemoteCandidates.clear()
        remoteDescriptionSet = false

        val ice = cachedIceServers ?: iceServers()
        val rtcConfig = PeerConnection.RTCConfiguration(ice).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "ICE connection: $state")
                when (state) {
                    PeerConnection.IceConnectionState.CONNECTED,
                    PeerConnection.IceConnectionState.COMPLETED ->
                        _connectionState.value = ConnState.CONNECTED
                    PeerConnection.IceConnectionState.FAILED -> {
                        _connectionState.value = ConnState.FAILED
                        _lastError.value = "ICE failed (network/NAT). Try same Wi‑Fi or add TURN."
                    }
                    PeerConnection.IceConnectionState.DISCONNECTED,
                    PeerConnection.IceConnectionState.CLOSED ->
                        if (_connectionState.value == ConnState.CONNECTED) {
                            _connectionState.value = ConnState.CLOSED
                        }
                    else -> {}
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                Log.d(TAG, "ICE gathering: $state")
            }
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate ?: return
                gatheredIce.add(
                    IceDto(candidate.sdpMid, candidate.sdpMLineIndex, candidate.sdp)
                )
                // Refresh local signal bundle so copy includes latest ICE
                refreshLocalBundle()
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: org.webrtc.MediaStream?) {}
            override fun onRemoveStream(stream: org.webrtc.MediaStream?) {}
            override fun onDataChannel(dc: DataChannel?) {
                Log.d(TAG, "Remote DataChannel: ${dc?.label()}")
                dc?.let { attachDataChannel(it) }
            }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: org.webrtc.RtpReceiver?, streams: Array<out org.webrtc.MediaStream>?) {}
        }

        return factory!!.createPeerConnection(rtcConfig, observer)
            ?: throw IllegalStateException("createPeerConnection returned null")
    }

    private var currentRoomCode: String = ""
    private var currentSdpType: String = "offer"

    private fun refreshLocalBundle() {
        val sdp = peer?.localDescription ?: return
        val bundle = SignalBundle(
            sdpType = currentSdpType,
            sdp = sdp.description,
            roomCode = currentRoomCode,
            ice = gatheredIce.toList()
        )
        _localSdp.value = json.encodeToString(bundle)
    }

    private fun attachDataChannel(dc: DataChannel) {
        dataChannel = dc
        dc.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(amount: Long) {}
            override fun onStateChange() {
                Log.d(TAG, "DataChannel state: ${dc.state()}")
                if (dc.state() == DataChannel.State.OPEN) {
                    _connectionState.value = ConnState.CONNECTED
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer?) {
                buffer ?: return
                try {
                    val bytes = ByteArray(buffer.data.remaining())
                    buffer.data.get(bytes)
                    val text = String(bytes, StandardCharsets.UTF_8)
                    val msg = json.decodeFromString<PeerMessage>(text)
                    _incoming.tryEmit(msg)
                } catch (e: Exception) {
                    Log.e(TAG, "Bad peer message", e)
                }
            }
        })
    }

    /** Host: create offer + local DataChannel */
    fun createOffer(roomCode: String, onDone: (String) -> Unit) {
        executor.execute {
            try {
                closeInternal()
                currentRoomCode = roomCode
                currentSdpType = "offer"
                _connectionState.value = ConnState.CREATING_OFFER
                // Resolve free third-party TURN (Metered etc.) — no self-hosted server
                try {
                    val resolved = kotlinx.coroutines.runBlocking { turnConfig.resolve() }
                    cachedIceServers = resolved.servers
                    Log.d(TAG, "ICE source: ${resolved.source}")
                } catch (e: Exception) {
                    Log.w(TAG, "TURN resolve failed: ${e.message}")
                }
                peer = createPeer()

                val init = DataChannel.Init().apply {
                    ordered = true
                    negotiated = false
                }
                val dc = peer!!.createDataChannel("sonora", init)
                attachDataChannel(dc)

                val constraints = MediaConstraints()
                peer!!.createOffer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(desc: SessionDescription?) {
                        desc ?: return
                        peer!!.setLocalDescription(object : SimpleSdpObserver() {
                            override fun onSetSuccess() {
                                refreshLocalBundle()
                                _connectionState.value = ConnState.WAITING_ANSWER
                                // Give ICE a moment to gather, then deliver
                                Thread.sleep(1500)
                                refreshLocalBundle()
                                _localSdp.value?.let { onDone(it) }
                            }
                        }, desc)
                    }
                    override fun onCreateFailure(error: String?) {
                        _lastError.value = error
                        _connectionState.value = ConnState.FAILED
                    }
                }, constraints)
            } catch (e: Exception) {
                _lastError.value = e.message
                _connectionState.value = ConnState.FAILED
            }
        }
    }

    /** Guest: apply remote offer, create answer */
    fun createAnswer(offerJson: String, onDone: (String) -> Unit) {
        executor.execute {
            try {
                closeInternal()
                val bundle = json.decodeFromString<SignalBundle>(offerJson)
                currentRoomCode = bundle.roomCode
                currentSdpType = "answer"
                _connectionState.value = ConnState.CREATING_ANSWER
                try {
                    val resolved = kotlinx.coroutines.runBlocking { turnConfig.resolve() }
                    cachedIceServers = resolved.servers
                    Log.d(TAG, "ICE source: ${resolved.source}")
                } catch (e: Exception) {
                    Log.w(TAG, "TURN resolve failed: ${e.message}")
                }
                peer = createPeer()

                val remote = SessionDescription(
                    SessionDescription.Type.OFFER,
                    bundle.sdp
                )
                peer!!.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        flushRemoteIce(bundle.ice)
                        peer!!.createAnswer(object : SimpleSdpObserver() {
                            override fun onCreateSuccess(desc: SessionDescription?) {
                                desc ?: return
                                peer!!.setLocalDescription(object : SimpleSdpObserver() {
                                    override fun onSetSuccess() {
                                        refreshLocalBundle()
                                        _connectionState.value = ConnState.CONNECTING
                                        Thread.sleep(1500)
                                        refreshLocalBundle()
                                        _localSdp.value?.let { onDone(it) }
                                    }
                                }, desc)
                            }
                            override fun onCreateFailure(error: String?) {
                                _lastError.value = error
                                _connectionState.value = ConnState.FAILED
                            }
                        }, MediaConstraints())
                    }
                    override fun onSetFailure(error: String?) {
                        _lastError.value = error
                        _connectionState.value = ConnState.FAILED
                    }
                }, remote)
            } catch (e: Exception) {
                _lastError.value = e.message
                _connectionState.value = ConnState.FAILED
            }
        }
    }

    /** Host: apply guest answer */
    fun acceptAnswer(answerJson: String, onDone: (Boolean) -> Unit) {
        executor.execute {
            try {
                val bundle = json.decodeFromString<SignalBundle>(answerJson)
                val remote = SessionDescription(
                    SessionDescription.Type.ANSWER,
                    bundle.sdp
                )
                peer!!.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        remoteDescriptionSet = true
                        flushRemoteIce(bundle.ice)
                        _connectionState.value = ConnState.CONNECTING
                        onDone(true)
                    }
                    override fun onSetFailure(error: String?) {
                        _lastError.value = error
                        _connectionState.value = ConnState.FAILED
                        onDone(false)
                    }
                }, remote)
            } catch (e: Exception) {
                _lastError.value = e.message
                _connectionState.value = ConnState.FAILED
                onDone(false)
            }
        }
    }

    private fun flushRemoteIce(ice: List<IceDto>) {
        ice.forEach { dto ->
            val c = IceCandidate(dto.sdpMid, dto.sdpMLineIndex, dto.candidate)
            if (remoteDescriptionSet) {
                peer?.addIceCandidate(c)
            } else {
                pendingRemoteCandidates.add(c)
            }
        }
        if (remoteDescriptionSet) {
            pendingRemoteCandidates.forEach { peer?.addIceCandidate(it) }
            pendingRemoteCandidates.clear()
        }
    }

    fun send(msg: PeerMessage): Boolean {
        val dc = dataChannel
        if (dc == null || dc.state() != DataChannel.State.OPEN) {
            _lastError.value = "DataChannel not open yet"
            return false
        }
        return try {
            val bytes = json.encodeToString(msg).toByteArray(StandardCharsets.UTF_8)
            val buffer = DataChannel.Buffer(ByteBuffer.wrap(bytes), false)
            dc.send(buffer)
        } catch (e: Exception) {
            _lastError.value = e.message
            false
        }
    }

    fun close() {
        executor.execute { closeInternal() }
    }

    private fun closeInternal() {
        try {
            dataChannel?.unregisterObserver()
            dataChannel?.close()
        } catch (_: Exception) {}
        dataChannel = null
        try {
            peer?.close()
        } catch (_: Exception) {}
        peer = null
        remoteDescriptionSet = false
        pendingRemoteCandidates.clear()
        gatheredIce.clear()
        _localSdp.value = null
        _connectionState.value = ConnState.CLOSED
    }

    private open class SimpleSdpObserver : org.webrtc.SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String?) {}
        override fun onSetFailure(error: String?) {}
    }

    companion object {
        private const val TAG = "WebRtcEngine"
    }
}
