package com.personal.sonora.data.product

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/** Public Music Card layer. Cards contain metadata and links only; no audio is hosted by Sonora. */
@Singleton
class PublicCardRepository @Inject constructor() {
    private fun db(): FirebaseDatabase = run {
        val url = com.personal.sonora.BuildConfig.FIREBASE_DB_URL
        if (url.isBlank()) FirebaseDatabase.getInstance() else FirebaseDatabase.getInstance(url)
    }
    private suspend fun authUid(): String {
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser == null) withTimeout(6_000) { auth.signInAnonymously().await() }
        return auth.currentUser?.uid ?: error("Authentication unavailable")
    }

    suspend fun publish(card: MusicCard): String {
        val videoId = card.track.externalId?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
            ?: error("Music Card แบบสาธารณะรองรับเฉพาะเพลง YouTube ที่มี video ID")
        val uid = authUid()
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        val value = mapOf(
            "ownerUid" to uid,
            "title" to card.track.title,
            "artist" to card.track.artist,
            "album" to card.track.album,
            "coverUrl" to card.track.coverUrl,
            "source" to card.track.source,
            "externalId" to card.track.externalId,
            "youtubeVideoId" to videoId,
            "externalUrl" to "https://www.youtube.com/watch?v=$videoId",
            "message" to card.message,
            "mood" to card.mood,
            "createdAt" to ServerValue.TIMESTAMP
        )
        withTimeout(8_000) { db().getReference("publicCards").child(id).setValue(value).await() }
        return id
    }

    suspend fun get(id: String): DataSnapshot = withTimeout(8_000) {
        db().getReference("publicCards").child(id).get().await()
    }


}
