package com.personal.sonora.data.social

import android.content.Context
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import com.personal.sonora.data.settings.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reads friends' chat messages aloud. Lives for the whole app (not inside a screen), so it keeps
 * working while you browse other tabs, and can be switched on/off from the Social screen.
 */
@Singleton
class RoomTts @Inject constructor(
    @ApplicationContext private val context: Context,
    private val rooms: FirebaseRoomRepository,
    private val settings: SettingsRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false
    private var tts: TextToSpeech? = null
    private var ready = false
    private val backlog = ArrayDeque<Pair<String, String>>()
    private val handled = HashSet<String>()

    @Volatile
    private var enabled = true
    private var roomCode: String? = null
    private var quietUntil = 0L

    fun start() {
        if (started) return
        started = true
        scope.launch {
            settings.roomTtsEnabled.collect { on ->
                enabled = on
                if (!on) {
                    backlog.clear()
                    tts?.stop()
                }
            }
        }
        scope.launch {
            rooms.room.collect { r ->
                if (r.code != roomCode) {
                    roomCode = r.code
                    handled.clear()
                    // chat history arrives in a burst right after joining: never read that aloud
                    quietUntil = SystemClock.elapsedRealtime() + 2500L
                    tts?.stop()
                    backlog.clear()
                }
            }
        }
        scope.launch {
            rooms.messages.collect { list ->
                for (m in list) {
                    if (!handled.add(m.id)) continue
                    if (!enabled || !m.tts) continue
                    if (m.uid.isNotEmpty() && m.uid == rooms.myId) continue // my own message
                    if (SystemClock.elapsedRealtime() < quietUntil) continue // history burst after joining
                    speak("${m.sender} ว่า ${m.text}", m.id)
                }
            }
        }
    }

    private fun speak(text: String, id: String) {
        if (tts == null) {
            var engine: TextToSpeech? = null
            engine = TextToSpeech(context) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val e = engine
                    if (e != null) {
                        val r = e.setLanguage(Locale("th", "TH"))
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            e.setLanguage(Locale.US)
                        }
                    }
                    ready = true
                    while (backlog.isNotEmpty()) {
                        val (t, i) = backlog.removeFirst()
                        if (enabled) e?.speak(t, TextToSpeech.QUEUE_ADD, null, i)
                    }
                }
            }
            tts = engine
        }
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id) else backlog.addLast(text to id)
    }
}
