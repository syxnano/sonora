package com.personal.sonora.data.social

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.player.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Bridges WebRTC PeerMessages ↔ PlayerController + local chat.
 * When a remote command arrives, applies it locally.
 * When local user plays/pauses, can broadcast (call from UI).
 */
@Singleton
class PlaybackSyncBridge @Inject constructor(
    private val engine: WebRtcEngine,
    private val player: PlayerController,
    private val roomManager: SocialRoomManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false

    /** Ignore echo of our own commands briefly */
    @Volatile
    private var suppressBroadcast = false

    fun start() {
        if (started) return
        started = true
        scope.launch {
            engine.incoming.collectLatest { msg ->
                handleIncoming(msg)
            }
        }
    }

    private fun handleIncoming(msg: WebRtcEngine.PeerMessage) {
        suppressBroadcast = true
        try {
            when (msg.type) {
                "chat" -> {
                    val sender = msg.sender ?: "Peer"
                    val text = msg.text ?: return
                    roomManager.sendChat(sender, text, tts = true)
                }
                "play" -> {
                    if (!player.state.value.isPlaying) player.togglePlayPause()
                }
                "pause" -> {
                    if (player.state.value.isPlaying) player.togglePlayPause()
                }
                "seek" -> {
                    player.seekTo(msg.positionMs)
                }
                "track" -> {
                    val id = msg.trackId ?: return
                    val title = msg.trackTitle ?: "Track"
                    val artist = msg.trackArtist ?: ""
                    val track = Track(
                        id = id,
                        title = title,
                        artist = artist,
                        coverUrl = msg.coverUrl
                    )
                    player.play(track)
                    if (msg.positionMs > 0) {
                        // slight delay so prepare can start
                        scope.launch {
                            kotlinx.coroutines.delay(800)
                            player.seekTo(msg.positionMs)
                        }
                    }
                }
                "ping" -> {
                    // keepalive / latency probe
                }
            }
        } finally {
            scope.launch {
                kotlinx.coroutines.delay(300)
                suppressBroadcast = false
            }
        }
    }

    fun broadcastChat(sender: String, text: String) {
        engine.send(
            WebRtcEngine.PeerMessage(type = "chat", text = text, sender = sender)
        )
    }

    fun broadcastPlay() {
        if (suppressBroadcast) return
        engine.send(WebRtcEngine.PeerMessage(type = "play"))
    }

    fun broadcastPause() {
        if (suppressBroadcast) return
        engine.send(WebRtcEngine.PeerMessage(type = "pause"))
    }

    fun broadcastSeek(positionMs: Long) {
        if (suppressBroadcast) return
        engine.send(WebRtcEngine.PeerMessage(type = "seek", positionMs = positionMs))
    }

    fun broadcastTrack(track: Track, positionMs: Long = 0) {
        if (suppressBroadcast) return
        engine.send(
            WebRtcEngine.PeerMessage(
                type = "track",
                trackId = track.id,
                trackTitle = track.title,
                trackArtist = track.artist,
                coverUrl = track.coverUrl,
                positionMs = positionMs
            )
        )
    }
}
