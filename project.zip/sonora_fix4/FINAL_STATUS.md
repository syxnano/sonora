# Sonora — final handoff status (2026-10-05)

## Completed in this handoff

### Phase 1 — Music Card
- [x] YouTube search via YouTube Data API v3
- [x] Exact selected YouTube video ID stored
- [x] Public Card URL
- [x] Public Card title / artist / message
- [x] Official YouTube embed on web
- [x] Official YouTube embed in Android Card screen
- [x] Android Card deep link: `sonora://card/<id>`
- [x] Android WebView lifecycle pause/resume handling
- [x] No sender field
- [x] No web reply UI
- [x] No web room UI in final bundle

### Phase 2 — Listening Room
- [x] Firebase Anonymous Auth
- [x] Create/join by 6-digit code
- [x] Presence
- [x] Member-scoped chat
- [x] Host/DJ control
- [x] Guest song proposal + Host approval/rejection
- [x] Server-time offset
- [x] Scheduled start anchor
- [x] 1-second reconciliation loop
- [x] Drift correction
- [x] Late-join state/queue sync
- [x] Manual Resync
- [x] Host-only queue/timeline mutation

### Phase 3 — Morning / Taste / AI / Profile
- [x] Morning Song opt-in alarm
- [x] Re-schedule after delivery
- [x] Re-schedule after reboot/app replacement
- [x] Notification opens Sonora
- [x] Editable Taste Memory
- [x] Clear Taste Memory
- [x] Learning toggle
- [x] Track 👍/👎 feedback
- [x] Catalog-first deterministic Taste Agent
- [x] Guest Profile username

### Phase 4 — Hardening
- [x] Firebase room rules tightened
- [x] Public Card create-once / owner-only / YouTube-only validation
- [x] Message and public Card length limits
- [x] HTML escaping on web rendering
- [x] Android Firebase DB URL from BuildConfig
- [x] Stale web room/reply files removed
- [x] Legacy docs replaced with current architecture notes

## Not claimed as verified
- [ ] Full Android Gradle build / APK / AAB: unavailable in this workspace because no usable Gradle distribution/executable was available.
- [ ] Firebase deployment from this exact final archive.
- [ ] Physical-device testing across Android versions.
- [ ] Production App Check / abuse-rate limiting / moderation configuration.
- [ ] Final release App Link `assetlinks.json` certificate fingerprint, because the final signing key is external to this workspace.

## Compliance boundary
The Music Card path uses official YouTube embedding and does not extract YouTube streams. Legacy unofficial stream extraction code remains for older prototype/download features elsewhere in the repository and must not be treated as the public/commercial playback architecture.
