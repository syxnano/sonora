# Sonora release checklist

## Included
- Music Card local creation/history/deletion.
- Public YouTube Music Card IDs in Firebase Realtime Database.
- Shareable `https://sonora-9d7f4.web.app/card/<id>` URLs.
- Android Card deep links.
- Official YouTube embedded playback in Android Card screen and web Card page.
- Send-only web Card flow; no sender input and no web reply UI.
- Listening Room with Host/DJ control, proposal/approval, server-clock timeline, 1-second reconciliation, drift correction, and Resync.
- Room chat with authenticated member-scoped rules and field limits.
- Morning Song opt-in scheduling with reboot/app-update rescheduling.
- Taste Memory edit/clear/learning toggle and track feedback.
- Catalog-verified deterministic Taste Agent.
- Guest Profile username.

## Must happen in a real Android/Firebase environment before public launch
1. `firebase deploy --only hosting,database` with the final `web/` and `firebase-rules.json`.
2. Enable Firebase App Check for Web and Android and monitor rejected requests.
3. Verify Anonymous Auth + Realtime Database rules with at least two separate test accounts/devices.
4. Restrict the YouTube Data API browser key to Sonora production referrers and YouTube Data API v3.
5. Add the final release signing certificate SHA-256 to Firebase Hosting `/.well-known/assetlinks.json` if verified Android App Links are required.
6. Build a signed release AAB/APK in Android Studio; this workspace cannot run the Android Gradle build.
7. Device-test: Card deep link, YouTube playback, lifecycle pause/resume, room create/join/late-join/resync, request approve/reject, chat, notification permission, reboot reschedule.
8. Before a broad social launch, add production privacy policy, data deletion, report/block/moderation, abuse monitoring, and provider/legal review.
9. Disable/remove unofficial external-stream extraction before any commercial/public release unless each provider explicitly authorizes the use.
