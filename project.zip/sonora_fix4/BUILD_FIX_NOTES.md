# Build fix — 2026-10-05

Fixed the Kotlin compile errors shown by GitHub Actions:

1. `TasteAgent.kt`: ranking now keeps each `Track` paired with its score (`t to score`) before sorting.
2. `SocialScreen.kt`: added the missing `Arrangement` import used by `Arrangement.spacedBy(...)`.
3. `PublicCardScreen.kt`: removed the invalid `WebView.isLoading` reference from the Compose update block. The WebView is loaded in its factory and the update block only keeps the current reference.

No Firebase credentials were changed or added.
