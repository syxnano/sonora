# Sonora FIX5 — Duration Filter

Recommendation/search duration policy:
- 00:59 and below: blocked
- 01:00 through 15:00: allowed
- 15:01 and above: blocked

The filter is centralized in `TrackDurationPolicy` and applied to YouTube catalog results, Last.fm catalog results, Discover candidates, and autoplay candidates.

Unknown/zero duration is excluded because it is below the 1-minute minimum; this prevents unknown/invalid-duration items from entering recommendations.
