# Sonora implementation — final handoff

This build follows the current Sonora product direction: Music Card as the public growth loop, official YouTube playback for Cards, a Firebase Listening Room with server-clock synchronization, Morning Song, user-controlled Taste Memory, and a deterministic catalog-verified Taste Agent.

## Phase 1 — Music Card
- Local Music Cards: create, persist, delete, share.
- Public Card: Firebase Realtime Database + `https://sonora-9d7f4.web.app/card/<id>`.
- Public Card has no sender field and no web reply UI.
- Web search uses YouTube Data API v3 and stores the selected YouTube video ID.
- Card playback uses the official YouTube embed; Sonora does not extract or proxy YouTube streams for the Card path.
- Android Card deep links work with `sonora://card/<id>` and the Firebase Hosting URL.
- Android WebView pauses/destroys the embedded player when the Card leaves the visible lifecycle.

## Phase 2 — Listening Room
- Firebase Anonymous Auth + room membership/presence.
- Host/DJ role: only the host mutates the shared playback timeline and queue.
- Guests can propose a song; Host accepts/rejects.
- Shared timeline uses Firebase server-time offset and a `startAt`/anchor timestamp.
- Automatic reconciliation runs every second.
- Small drift is corrected with playback-speed nudging; large drift uses one seek.
- Late joiners receive current track, queue, and current position.
- Manual `Resync` is available.
- Queue changes and request approval are atomic where required.
- Chat is member-scoped and length-limited.
- The old WebRTC stack remains available in the repository, but the Firebase room is the active room surface.

## Phase 3 — Morning Song / Taste / AI / Profile
- Morning Song is opt-in, reschedules after delivery, and survives reboot/app replacement.
- Notification opens Sonora directly.
- Taste Memory is explicit and user-editable, with learning on/off and a clear-memory action.
- Track-level 👍/👎 feedback is stored only when learning is enabled and affects local ranking.
- Taste Agent searches the real catalog first, then ranks returned tracks; it does not invent tracks.
- Guest Profile username is configurable from Settings.

## Phase 4 — Production hardening
- Firebase rules are authenticated/member-scoped for rooms.
- Public Card writes are owner-only, create-once, YouTube-only, and field-length constrained.
- Web input is HTML-escaped before rendering.
- Firebase database URL is read from `BuildConfig` on Android.
- Web Card is send-only; the abandoned web room/reply surfaces were removed from the final web bundle.
- The repository still contains legacy NewPipe/stream-resolver code used by older non-Card features. It is **not** used by the official Music Card playback path. A public/commercial launch should disable/remove unofficial external-stream extraction and use L0/L1 provider playback only.

## Verification status
- Web JavaScript syntax checked with Node.
- Firebase/Android JSON configuration files checked as valid JSON.
- Full Android Gradle/APK build was **not executable in this workspace** because a usable Gradle distribution/executable is unavailable. Final APK/AAB compilation and device testing must therefore be performed in Android Studio or another real Android/Gradle environment before release.
