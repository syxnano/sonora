# Sonora

Sonora is a social layer around music: **Music Card → share → official provider playback → conversation**, plus Morning Song, Taste Memory, AI-assisted discovery, and Listen with Friends.

## Current final handoff

### Music Card
- Search real YouTube videos with YouTube Data API v3.
- Create a public `https://sonora-9d7f4.web.app/card/<id>` Card.
- Card contains title, artist, message, and the official YouTube embedded player.
- No sender field on the public Card.
- Web Card is intentionally send-only; no web reply form.
- Android accepts `sonora://card/<id>` and the Firebase Hosting App Link.
- Android Card playback does **not** use NewPipe stream extraction.

### Listen with Friends
- Firebase Anonymous Auth + Realtime Database.
- Six-digit room code, presence, chat, Host/DJ role.
- Host controls shared playback state and queue.
- Guests can propose a different song; Host approves/rejects.
- Shared timeline uses Firebase server time and an anchor/start timestamp.
- Reconciliation runs every second with drift correction and a manual Resync action.

### Morning Song
- Opt-in daily notification at the user's chosen time.
- Notification opens Sonora.
- Alarm is restored after device reboot/app replacement.

### Taste + AI
- Explicit Taste Memory is editable and can be cleared or disabled.
- Optional track 👍/👎 feedback is stored only while learning is enabled.
- Taste Agent searches the real catalog first, then ranks returned tracks; it does not invent tracks.
- Guest Profile username is available in Settings.

## Important playback boundary
Sonora's public Music Card path uses **official YouTube playback**. The repository still contains legacy NewPipe/stream-resolver code used by older prototype/download features. It is not used by Music Cards. Before a commercial/public launch, remove or disable unofficial external-stream extraction unless the relevant provider explicitly authorizes it.

## Build

Requirements:
- JDK 17
- Android SDK / compileSdk 35
- Android Studio with a compatible Gradle environment

Open the project in Android Studio and sync Gradle, or use a real Gradle installation:

```bash
gradle assembleDebug
gradle bundleRelease
```

This handoff workspace does **not** contain a usable Gradle distribution, so an APK/AAB build was not claimed as verified here.

## Local configuration
Copy `local.properties.example` to `local.properties` and fill only the credentials you actually use. **Do not commit `local.properties`**.

Relevant values include:

```properties
sdk.dir=/path/to/Android/sdk
LASTFM_API_KEY=
FIREBASE_DB_URL=https://sonora-9d7f4-default-rtdb.asia-southeast1.firebasedatabase.app/
TURN_URLS=
TURN_USERNAME=
TURN_CREDENTIAL=
METERED_API_KEY=
```

## Web deploy

From the project root:

```bash
npm install -g firebase-tools
firebase login
firebase use sonora-9d7f4
firebase deploy --only hosting,database
```

See `DEPLOY_PRODUCTION.md` and `RELEASE_CHECKLIST.md` for the production gate.

## Project structure

```text
sonora/
├── app/                         Android app
│   └── src/main/java/com/personal/sonora/
│       ├── data/catalog/        discovery/catalogs
│       ├── data/product/        Cards, Taste, AI
│       ├── data/social/         Listening Room
│       ├── data/profile/        Guest Profile
│       ├── morning/              Morning Song
│       ├── player/               player + MediaSession
│       └── ui/                   Compose UI
├── web/                          public Music Card web app
├── firebase-rules.json           Realtime Database rules
├── firebase.json                  Firebase Hosting config
└── RELEASE_CHECKLIST.md
```
