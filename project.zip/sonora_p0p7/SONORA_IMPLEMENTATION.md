# Sonora implementation

This build follows `SONORA_STRATEGY_PROMPT_v2.1.md` at the product layer.

Implemented:
- Music Card creation, local persistence, sharing, and deletion.
- Morning Song opt-in scheduler with quiet-time-friendly single daily alarm and notification.
- Taste Memory with explicit preferences and user-controlled learning toggle.
- AI Taste Agent prototype using tool-style catalog search first; it only ranks returned tracks and never invents a track.
- Sonora product hub integrated into the main navigation.
- Existing room system retained as a separate social surface.
- Firebase room rules changed from public read/write to authenticated/member-scoped access, with host-only shared playback/queue mutation.
- Joining a non-existent room no longer silently creates it.

Known boundary:
- Official third-party playback/licensing still depends on each provider's current terms and credentials. The product layer therefore treats external services as playback destinations rather than claiming Sonora owns their catalog.
- A public web backend for Music Card URLs is not included in this Android-only repository; sharing currently uses Android share sheets and provider links/metadata.
- The environment used to modify this archive does not have a Gradle executable, so a full APK build could not be executed here.
