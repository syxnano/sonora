# Sonora Video-first build

This build changes Sonora's primary experience from music playback to an in-app short-video experience.

### Main screens
- ดู — provider selection / video hub
- ค้นหา — YouTube (<60s only) or TikTok in-app search
- กับเพื่อน — Rave-style shared video + chat + automatic sync
- การ์ด — existing Sonora Music Card system

### Architecture
- `video/VideoPlaybackManager.kt` — global playback state and persistent WebView control
- `video/VideoPlayerWebView.kt` — official YouTube IFrame + TikTok Embed Player surfaces
- `video/VideoPlayerLayer.kt` — full player + bottom-right mini player
- `video/YouTubeSearchRepository.kt` — official YouTube Data API v3 search/duration filtering
- `video/VideoRoomController.kt` — shared Firebase timeline/sync
- `ui/video/VideoSearchScreen.kt` — provider picker + search
- `ui/video/VideoRoomScreen.kt` — shared video + chat

### Old audio stack
Legacy music/download files remain in the repository for compatibility with older screens/data. They are no longer part of the new video discovery/playback path. The old WebRTC Listen-with-Friends path and its UI were removed from the active build.
