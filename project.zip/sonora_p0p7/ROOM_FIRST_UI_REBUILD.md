# Sonora Room-First UI Rebuild

## Core behavior
- A room is NOT created when merely entering YouTube, TikTok, Search, Music, or the Room page.
- The first time the user actually opens playable content (YouTube video, TikTok video, Music track, or Music Card video), Sonora creates the current room automatically.
- The same current room is reused for subsequent content. No second room is created just because the user changes song/video.
- The active room code is always visible as a compact ROOM 6-digit pill and can be copied/shared.
- Friends can join using the 6-digit code or the generated Sonora room link.
- Entering a room from a link joins that room; it does not create another room.

## UI reset
- Home is redesigned around a strong first impression: search + three large destinations (YouTube, TikTok, Music).
- Mini-player is anchored bottom-right and visually separated from the main page.
- Room page no longer asks the host to manually create a room.
- Chat head remains the single chat surface for the currently active room.
