# Sonora v4 — All-in-one Social

This rebuild establishes the new product baseline requested by the owner.

## Product
- Home is a social feed mixing Sonora posts, YouTube, TikTok and Music.
- Top-level services: Sonora Music / Sonora YouTube / Sonora TikTok.
- Opening playable content creates or reuses one active room; 6-digit code + share link.
- Room content changes reuse the same active room.
- Room has synced player + text chat + optional live WebRTC voice.
- Chat head belongs to the active room; private DM is separate and uses Firestore.
- Friend requests and profiles use Firebase Auth + Firestore.
- Email/password and Google Sign-In are supported in the auth layer.
- Card, Morning Song, Taste Memory and Taste AI remain under Sonora Music.

## Provider compliance
Sonora does not download or extract YouTube/TikTok streams. Provider content is played through official API/player/embed surfaces. API keys belong in local.properties/secrets, not source control.

## Important
The project source is prepared as a release candidate architecture, but an Android APK was NOT claimed as build-verified in this environment. Run Gradle/Android Studio with Android SDK installed and supply the Firebase Google web OAuth client ID + YouTube key before release.
