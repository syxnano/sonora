# Build Fix 02

Fixed `app/src/main/res/values/strings.xml`.

The `default_web_client_id` resource was accidentally placed after the closing `</resources>` element, causing Android resource merger error:
`The markup in the document following the root element must be well-formed.`

The resource is now inside `<resources>` and the XML validates successfully.
