# Sonora Video-first Final Spec — v3.0

## Product shape
หน้าแรกของแอปเป็น Video-first และมี 3 ทางเลือกหลัก:
1. Sonora Music — Cards / Morning / Taste Memory / Taste AI / เพลง
2. Sonora YouTube — YouTube ภายใน Sonora
3. Sonora TikTok — TikTok ภายใน Sonora

หน้าแรกมีช่องค้นหาทันที และส่ง query ไปยัง YouTube/TikTok surface ที่เลือก

## Room model
- การเปิด Sonora Music / YouTube / TikTok จะเรียก `ensureRoom()`
- ถ้ามีห้องอยู่แล้ว ใช้ห้องเดิม ไม่สร้างใหม่
- ถ้ายังไม่มี จะสร้างห้อง 6 หลักอัตโนมัติ
- แชร์ได้ทั้ง URL และรหัส 6 หลัก
- เพื่อนกรอกรหัสหรือเปิดลิงก์แล้วเข้า room เดิม
- Room state / queue / messages ใช้ Firebase Realtime Database

## Video model
- VideoPlaybackManager เป็น singleton ของแอป
- เปลี่ยนหน้าแล้ว video ไม่ถูกทำลาย
- Search route ย่อ player ไปมุมขวาล่าง
- ขยายกลับเป็น player เต็มได้
- YouTube ใช้ official IFrame Player
- TikTok ใช้ official Embed Player
- ไม่ใช้ NewPipe stream extraction ใน video-first path
- เมื่อแอปออกจาก foreground ตัว embedded player ถูก pause

## YouTube filter
- Search repository ต้องคืนเฉพาะรายการที่ duration < 60 seconds
- ไม่ใช้เงื่อนไขเดิม 15 นาที

## Room playback sync
- state มี sequence / position / anchor server timestamp
- client คำนวณ expected position จาก Firebase server clock
- sync loop ประมาณทุก 1 วินาที
- drift ระดับสูง seek กลับให้ตรง
- play/pause/seek ถูกส่งผ่าน room state

## Chat
- ห้องมี chat เดียว ไม่สร้าง chat แยกตาม provider
- ใช้ได้แม้อยู่คนเดียว
- มีช่องพิมพ์ถาวรใน Chat Head
- Chat Head แสดงเป็น floating bubble เมื่อปิด panel
- เปิดแล้วเห็นข้อความ + input + share + TTS toggle + microphone/voice input
- Notification ของข้อความใหม่มี inline reply
- TTS อ่านข้อความใหม่เมื่อเปิดการตั้งค่า
- Mic ใน UI ใช้ Android Speech Recognizer เพื่อแปลงเสียงเป็นข้อความก่อนส่ง

## Existing Sonora Music systems retained
- Music Cards
- Morning Song
- Taste Memory
- AI Taste Agent
- Inbox / Profile
- Library / Playlist / existing music systems

## Known build limitation
ชุดนี้จัด source และโครงสร้างให้พร้อม build แต่ environment นี้ไม่มี Android SDK/Gradle executable ที่ใช้งานได้ จึงไม่ได้อ้างว่า APK runtime/build ผ่านจาก environment นี้
