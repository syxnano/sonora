# Sonora Android — Official YouTube Card Playback

This build changes the Music Card playback path to the official YouTube Embedded Player inside Android WebView (Chromium/WebView engine).

- No YouTube audio extraction.
- No NewPipe stream URL is used by Music Card playback.
- The Card screen shows title, artist, message, embedded YouTube video, and an "เปิดบน YouTube" button.
- The player can be minimized to a small in-app player while remaining on the Sonora Card screen.
- This build does not intentionally implement background playback after Sonora is no longer visible.
- The custom deep link `sonora://card/<id>?action=reply` is accepted so the existing web Card button can open the Android Card screen. Reply UI is intentionally not implemented yet.

Note: The rest of the legacy app may still contain NewPipe/Media3 code for other playback features. That code is not used by the Music Card screen.
