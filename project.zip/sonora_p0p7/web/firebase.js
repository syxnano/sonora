// Sonora Web Firebase configuration
// Project: sonora-9d7f4
const SONORA_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBiWFfQphM4gXbVw5lxuPZRW1lvKBkwzPk",
  authDomain: "sonora-9d7f4.firebaseapp.com",
  databaseURL: "https://sonora-9d7f4-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "sonora-9d7f4",
  storageBucket: "sonora-9d7f4.firebasestorage.app",
  messagingSenderId: "597097691986",
  appId: "1:597097691986:web:4d85eebb214400034a988b",
  measurementId: "G-GJVBXTST3P"
};

if (!firebase.apps.length) {
  firebase.initializeApp(SONORA_FIREBASE_CONFIG);
}

const sonoraAuth = firebase.auth();
const sonoraDb = firebase.database();

async function sonoraSignIn() {
  if (sonoraAuth.currentUser) return sonoraAuth.currentUser;
  const result = await sonoraAuth.signInAnonymously();
  return result.user;
}

// Expose the public Firebase web config to Sonora's browser-side YouTube search.
// This is a public browser API key; protect it with Google Cloud API + HTTP referrer restrictions.
window.SONORA_FIREBASE_CONFIG = SONORA_FIREBASE_CONFIG;
