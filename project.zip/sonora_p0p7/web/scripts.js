(function(){
'use strict';

const path = location.pathname;
const YT_API = 'https://www.googleapis.com/youtube/v3/search';
const SEARCH_CACHE_TTL = 12 * 60 * 60 * 1000;

function cardShareUrl(id){ return `${location.origin}/card/${encodeURIComponent(id)}`; }
function getCardId(){ const m = location.pathname.match(/^\/card\/([^/]+)/); return m ? decodeURIComponent(m[1]) : ''; }
function esc(v){ return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function decodeHtml(v){ const t = document.createElement('textarea'); t.innerHTML = String(v ?? ''); return t.value; }
function appReplyUrl(id){ return `sonora://card/${encodeURIComponent(id)}?action=reply`; }
function youtubeWatchUrl(videoId){ return `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`; }
function youtubeEmbedUrl(videoId){
  const origin = encodeURIComponent(location.origin);
  return `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?playsinline=1&rel=0&origin=${origin}`;
}
function youtubeIframe(videoId, title){
  return `<div class="yt-wrap"><iframe class="yt-player" src="${esc(youtubeEmbedUrl(videoId))}" title="${esc(title || 'YouTube player')}" frameborder="0" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>`;
}
function getYouTubeApiKey(){
  // The Firebase Web API key belongs to the same Google Cloud project. Once
  // YouTube Data API v3 is enabled for the project and the key restrictions
  // allow youtube.googleapis.com, no web-code edit is required.
  return 'AIzaSyBFoGsBzgw_a4ypppdAZ-0mraR8hYCG-go';
}
function searchCacheKey(term){ return `sonora:ytsearch:v1:${term.trim().toLowerCase().replace(/\s+/g,' ')}`; }
function readSearchCache(term){
  try {
    const raw = localStorage.getItem(searchCacheKey(term));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || Date.now() - parsed.ts > SEARCH_CACHE_TTL) { localStorage.removeItem(searchCacheKey(term)); return null; }
    return parsed.items || null;
  } catch (_) { return null; }
}
function writeSearchCache(term, items){
  try { localStorage.setItem(searchCacheKey(term), JSON.stringify({ts:Date.now(), items})); } catch (_) {}
}

async function youtubeSearch(term){
  const cached = readSearchCache(term);
  if (cached) return {items: cached, cached: true};

  const key = getYouTubeApiKey();
  if (!key) throw new Error('ไม่พบ YouTube API key');

  const params = new URLSearchParams({
    part: 'snippet',
    q: term,
    type: 'video',
    maxResults: '10',
    videoEmbeddable: 'true',
    videoSyndicated: 'true',
    safeSearch: 'moderate',
    videoCategoryId: '10',
    key
  });

  const res = await fetch(`${YT_API}?${params.toString()}`, {headers:{'Accept':'application/json'}});
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const reason = data?.error?.errors?.[0]?.reason || '';
    if (reason === 'quotaExceeded' || reason === 'dailyLimitExceeded') throw new Error('โควตาค้นหา YouTube วันนี้เต็มแล้ว');
    if (reason === 'accessNotConfigured') throw new Error('ต้องเปิด YouTube Data API v3 ใน Google Cloud ของโปรเจกต์ sonora-9d7f4');
    if (reason === 'forbidden' || reason === 'ipRefererBlocked') throw new Error('YouTube API key ถูกจำกัดสิทธิ์ไม่ให้ใช้จากโดเมนนี้');
    throw new Error(data?.error?.message || 'ค้นหา YouTube ไม่สำเร็จ');
  }

  const items = (data.items || []).map(x => ({
    videoId: x?.id?.videoId || '',
    title: decodeHtml(x?.snippet?.title || 'Unknown'),
    channelTitle: decodeHtml(x?.snippet?.channelTitle || 'Unknown'),
    description: decodeHtml(x?.snippet?.description || ''),
    thumbnail: x?.snippet?.thumbnails?.high?.url || x?.snippet?.thumbnails?.medium?.url || x?.snippet?.thumbnails?.default?.url || '',
    publishedAt: x?.snippet?.publishedAt || ''
  })).filter(x => x.videoId);

  writeSearchCache(term, items);
  return {items, cached:false};
}

async function initHome(){
  const create = document.querySelector('#create');
  if (!create) return;
  let selected = null;

  const searchInput = document.querySelector('#search');
  const searchBtn = document.querySelector('#searchBtn');
  const searchStatus = document.querySelector('#searchStatus');
  const resultsBox = document.querySelector('#results');
  const selectedBox = document.querySelector('#selected');


  async function runSearch(){
    const q = searchInput.value.trim();
    if (!q) return;
    searchBtn.disabled = true;
    searchStatus.textContent = 'กำลังค้นหา YouTube…';
    resultsBox.innerHTML = '';
    try {
      const {items, cached} = await youtubeSearch(q);
      searchStatus.textContent = items.length ? `พบ ${items.length} รายการ${cached ? ' • จากแคช' : ''}` : 'ไม่พบเพลง';
      items.forEach(item => {
        const row = document.createElement('div');
        row.className = 'result';
        row.innerHTML = `<img src="${esc(item.thumbnail)}" alt=""><div><h3>${esc(item.title)}</h3><p>${esc(item.channelTitle)}</p></div><button class="btn pick">เลือก</button>`;
        row.querySelector('button').onclick = () => {
          selected = item;
          selectedBox.style.display = 'block';
          selectedBox.innerHTML = `<div class="selected-head"><img src="${esc(item.thumbnail)}" alt=""><div><b>${esc(item.title)}</b><div class="muted">${esc(item.channelTitle)}</div></div></div>${youtubeIframe(item.videoId, item.title)}`;
          create.disabled = false;
          window.scrollTo({top:selectedBox.getBoundingClientRect().top + scrollY - 20, behavior:'smooth'});
        };
        resultsBox.appendChild(row);
      });
    } catch (e) {
      searchStatus.textContent = e.message || 'ค้นหาไม่สำเร็จ';
    } finally {
      searchBtn.disabled = false;
    }
  }

  searchBtn.onclick = runSearch;
  searchInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); runSearch(); } });

  create.onclick = async () => {
    if (!selected) return;
    const status = document.querySelector('#status');
    create.disabled = true;
    status.textContent = 'กำลังสร้าง Music Card…';
    try {
      const user = await sonoraSignIn();
      const id = crypto.randomUUID().replaceAll('-','').slice(0,12);
      const message = document.querySelector('#message').value.trim();
      const data = {
        ownerUid: user.uid,
        title: selected.title,
        artist: selected.channelTitle,
        album: '',
        coverUrl: selected.thumbnail,
        source: 'youtube',
        youtubeVideoId: selected.videoId,
        externalId: selected.videoId,
        externalUrl: youtubeWatchUrl(selected.videoId),
        message,
        mood: '',
        publishedAt: selected.publishedAt || '',
        createdAt: firebase.database.ServerValue.TIMESTAMP
      };
      await sonoraDb.ref(`publicCards/${id}`).set(data);
      const url = cardShareUrl(id);
      status.innerHTML = `สร้างแล้ว: <a class="link" href="${esc(url)}">${esc(url)}</a>`;
      if (navigator.share) {
        try { await navigator.share({title:`${selected.title} — Sonora`, text:'มีเพลงส่งถึงคุณบน Sonora', url}); } catch (_) {}
      }
    } catch (e) {
      status.textContent = e.message || 'สร้าง Card ไม่สำเร็จ';
    } finally {
      create.disabled = false;
    }
  };
}

async function initCard(){
  const app = document.querySelector('#app');
  if (!app) return;
  const id = getCardId();
  if (!id) { app.innerHTML = '<div class="error">ไม่พบ Card ID</div>'; return; }

  try {
    await sonoraSignIn();
    const snap = await sonoraDb.ref(`publicCards/${id}`).get();
    if (!snap.exists()) throw new Error('ไม่พบ Music Card นี้');
    const c = snap.val();
    const videoId = c.youtubeVideoId || (c.source === 'youtube' ? c.externalId : '');
    const player = videoId ? youtubeIframe(videoId, c.title) : `<div class="legacy"><b>Card รุ่นเก่า</b><br>การ์ดนี้ยังไม่มี YouTube video ID สำหรับเล่นใน Sonora</div>`;
    const youtubeLink = videoId ? youtubeWatchUrl(videoId) : (c.externalUrl || c.youtubeUrl || `https://www.youtube.com/results?search_query=${encodeURIComponent(`${c.title || ''} ${c.artist || ''}`)}`);

    app.innerHTML = `<div class="eyebrow">SONORA • MUSIC CARD</div><h1 class="title">${esc(c.title || 'ไม่ระบุเพลง')}</h1><div class="artist">${esc(c.artist || 'Unknown artist')}</div>${c.message ? `<div class="msg">“${esc(c.message)}”</div>` : ''}${player}<a class="btn dark" href="${esc(youtubeLink)}" target="_blank" rel="noopener">เปิดบน YouTube</a><a class="btn green" href="${esc(appReplyUrl(id))}">📱 เปิดแอป Sonora</a>`;
  } catch (e) {
    app.innerHTML = `<div class="error">${esc(e.message || 'เปิด Music Card ไม่สำเร็จ')}</div>`;
  }
}

if (path.startsWith('/card/')) initCard();
else if (!path.startsWith('/room')) initHome();
})();
