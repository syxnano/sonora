# Sonora Web — FINAL YouTube build

This build replaces the old 30-second iTunes preview flow.

## Playback architecture
- Search: YouTube Data API v3 (`search.list`)
- Playback: official YouTube embedded player
- Sonora does NOT download, cache, extract, proxy, or convert YouTube audio/video.
- Music Card stores the YouTube `videoId` and opens the full embedded YouTube player inside Sonora.

## One-time Google Cloud setup (NO web code edit)
Use the existing Google Cloud/Firebase project `sonora-9d7f4`:
1. Enable **YouTube Data API v3**.
2. In Google Cloud Console > APIs & Services > Credentials, make sure the browser API key used by this Firebase web app is allowed to call YouTube Data API v3.
3. Restrict website/referrer access to the Sonora domains, especially:
   - `https://sonora-9d7f4.web.app/*`
   - `https://sonora-9d7f4.firebaseapp.com/*`
   Add preview-channel domains only while testing.

The code uses the existing Firebase Web API key by default, so there is no API key placeholder to edit in the website.

## Deploy
From the folder containing `firebase.json`:

```bat
firebase use sonora-9d7f4
firebase deploy --only hosting,database
```

## Quota note
YouTube's current default quota model includes a dedicated limit for `search.list`. The app caches identical searches in each browser for 12 hours to reduce repeated API searches. For a real larger launch, request higher YouTube API quota in Google Cloud; raising quota does not require changing this web build.
