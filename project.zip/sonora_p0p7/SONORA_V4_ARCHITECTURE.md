# Sonora v4 — All-in-one social architecture

Home is a mixed social feed: Sonora posts + YouTube + TikTok + Music Cards. Main destinations: Sonora Music, Sonora YouTube, Sonora TikTok.

Opening playable content creates/reuses ONE active room. Room code is six digits and remains stable while the active session continues. Changing content does not create another room. Friends join by link or six-digit code.

Every room has synchronized media, room text chat, optional live voice chat and a chat-head surface. Voice is real WebRTC audio, not speech-to-text.

Friends/DMs use Firebase Auth + Firestore. Passwords are never stored by Sonora itself; Firebase Authentication owns credentials.

Provider content remains hosted by the provider. Sonora uses official API/player/embed surfaces and does not download or extract provider streams.

Music-only legacy features (Cards, Morning Song, Taste Memory, Taste AI) remain under Sonora Music.
