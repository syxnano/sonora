# Sonora — Video-first rebuild (final handoff)

## Product direction
Sonora is now treated as a **video-first app**. The primary loop is:

1. Choose **YouTube** or **TikTok** inside Sonora.
2. Search without leaving Sonora.
3. Play the video inside an official embedded player.
4. Minimize to a floating player at the bottom-right while browsing/searching.
5. Open **ดูด้วยกัน** to watch the same video with friends and chat in one screen.

The old Listen-with-Friends/WebRTC audio room path was removed from the active product path. The new room uses Firebase Realtime Database as the shared timeline and chat transport.

## YouTube rule
Search uses YouTube Data API v3. Discovery requests use the official `videoDuration=short` filter and then inspect `contentDetails.duration`; Sonora keeps only videos **strictly shorter than 60 seconds**.

Playback uses the official YouTube IFrame Player API in Android WebView. Sonora does not download or extract YouTube media streams for this video path.

## TikTok rule
TikTok playback uses TikTok's official Embed Player (`/player/v1/{post_id}`) inside the app.

TikTok's official developer docs do not expose a general public global-video search endpoint for arbitrary TikTok search terms. Therefore the TikTok search screen is an **in-app TikTok web search surface**; tapping a detected `/video/{id}` opens that post in the official TikTok Embed Player. No external app window is required for playback.

## Floating player
The floating player is mounted at the root navigation level so changing screens does not destroy the player WebView. Entering Search automatically minimizes an active video to the bottom-right.

YouTube player controls are kept inside the official embedded player; Sonora does not place custom overlays over YouTube controls.

## Watch Together
The room stores:

- provider (`youtube` / `tiktok`)
- external video id
- shared position
- playing/paused state
- server-clock anchor
- sequence number
- chat messages

Each client re-checks the shared timeline about once per second. When drift becomes large, the client seeks to the shared position. Play/pause/seek actions update Firebase and propagate to the room.

## Configuration
Add this to `local.properties`:

```properties
YOUTUBE_API_KEY=YOUR_RESTRICTED_YOUTUBE_DATA_API_V3_KEY
```

Recommended restriction:
- API restriction: YouTube Data API v3 only.
- Application restrictions should be appropriate for the way the key is used; do not ship an unrestricted key.

Firebase configuration remains the existing Sonora project configuration.

## Important platform limitations
- Embedded YouTube/TikTok playback can still be blocked by provider/browser autoplay policy. A user tap may be required.
- The floating player is an **in-app mini player**, not background playback after Sonora is hidden.
- TikTok search is web-surface based because the official TikTok Display/Embed APIs do not provide a general global search API.
- The project was statically updated here; this environment does not contain an Android SDK/Gradle installation capable of performing the final Android build, so a successful APK build is **not claimed**.
