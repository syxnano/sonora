# Sonora latest merged package

Base: sonora_v4_all_in_one_social
Merged: Sonora_Connector_Rebuild_v0.2

This is the latest combined source package available from the current Sonora work. It is intended for continued Android/Firebase integration by another coding AI or developer.

See SONORA_MERGED_LATEST.md for scope and provider safety boundaries.


## v0.3 continuation — Unified DM Web Hub

Added in this continuation:
- Unified Chat Hub screen for provider conversations.
- Provider Web DM screen using Android WebView for user-controlled provider login/session.
- Explicit external-browser fallback when a provider blocks WebView.
- ConversationTarget + ConversationRouter capability-aware routing foundation.
- Provider DM entry URLs for Instagram, Facebook, TikTok, X, Threads, and Telegram Web.
- No cookie extraction, password collection, scraping, private endpoints, or fake message delivery.

Important: provider pages may refuse WebView rendering or require their own supported client. Sonora must use the external fallback in that case.

This source package has not been compiled in this environment because the Gradle wrapper/Gradle executable is not available here.
