# Integration checklist

Before calling a provider "connected":
- OAuth callback succeeds
- token refresh succeeds
- provider API request succeeds
- disconnect/revoke path succeeds
- expired-token path shows reconnect UI
- rate-limit path queues/retries safely
- unsupported action becomes MANUAL_REQUIRED instead of fake success

Required real configuration:
- Firebase Auth / Firestore / RTDB / Storage / FCM / App Check
- YouTube API key + official player
- TikTok developer app + approved scopes
- X developer app + OAuth configuration
- Meta app(s) + approved permissions
- Telegram TDLib/API configuration

Never put client secrets in the APK.
Never store provider passwords or scraped cookies.
