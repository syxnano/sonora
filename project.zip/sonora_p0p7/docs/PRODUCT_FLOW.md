# Product flow

Home feed mixes Sonora posts and provider media references.

Opening media:
Home -> MediaItem -> create/reuse one ActiveRoom -> 6 digit code + share link

Changing media:
same ActiveRoom -> update currentMediaId -> sync playback

Chat/voice:
same ActiveRoom -> RTDB chat/presence/WebRTC signaling

Mini player:
continues while navigating where the provider permits.

Account center:
Connect / Disconnect / Reconnect each provider.

Capability engine:
UI exposes only actions that are actually supported for the current provider/account.
