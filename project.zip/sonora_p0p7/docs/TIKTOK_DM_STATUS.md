# TikTok DM status

Current official TikTok documentation exposes Data Portability scopes:
- portability.directmessages.single
- portability.directmessages.ongoing

Those scopes are for exporting copies of the user's direct-message data.

They are NOT a documented general API for:
- choosing another TikTok user
- composing a new DM
- sending that DM from Sonora

Therefore Sonora must NOT claim that it can automatically send TikTok DMs.

Implementation rule:
- READ_MESSAGES = permission-gated portability/export
- SEND_MESSAGE = unsupported until TikTok provides an official send endpoint/permission
- Flame increments only after an actually confirmed provider action
- If automatic sending is unavailable, show a manual action such as "เปิด TikTok เพื่อส่งข้อความ"
- Never fake SENT
