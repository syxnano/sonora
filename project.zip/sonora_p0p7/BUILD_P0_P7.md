# Build Sonora P0-P7

## Android

1. Open this directory in Android Studio.
2. Install Android SDK 35 and JDK 17.
3. Sync Gradle.
4. Put the real YouTube API key and Firebase RTDB URL in `local.properties`.
5. Confirm the Firebase Android app has a real OAuth web client ID for Google Sign-In; replace the placeholder in `app/src/main/res/values/strings.xml` if `google-services.json` does not generate it.
6. Run `assembleDebug`.
7. Install `app/build/outputs/apk/debug/app-debug.apk` on an Android device.

## Firebase

Deploy:

- `firebase deploy --only firestore:rules,firestore:indexes,database,storage`

Then enable App Check enforcement after device testing.

## Provider integrations

The app intentionally does not fake provider permissions. X/Meta/TikTok/Telegram OAuth and production API permissions must be configured with each provider's official developer console. TikTok generic DM send remains unsupported unless an official permitted endpoint exists.
