# Sonora release checklist

## Included in this release candidate
- Music Card local creation/history
- Public Music Card IDs in Firebase Realtime Database
- Shareable `https://sonora-9d7f4.web.app/card/<id>` URLs
- Android App Link intent for public cards
- Public web card page with provider hand-off and reply
- Taste Memory + deterministic catalog-verified Taste Agent prototype
- Morning Song local alarm/notification
- Hardened Firebase room rules and no auto-create-on-join

## Required before public launch
1. Deploy `web/` with Firebase Hosting and enable Anonymous Authentication + Realtime Database.
2. Publish `firebase-rules.json` to Realtime Database.
3. Add Firebase App Check and rate limiting/abuse monitoring before a 10,000-member community launch.
4. Verify the current Terms/Developer policies of every music provider used for discovery/hand-off.
5. The legacy in-app unofficial stream resolver remains in the codebase and must not be treated as the public/legal playback path. For a public launch, make L0 hand-off the default and remove/disable unofficial extraction before release.
6. Configure Android App Links/assetlinks for the final Firebase Hosting domain.
7. Build and test a signed release APK/AAB in a real Android/Gradle environment; this workspace does not have a usable Gradle executable.
8. Add production privacy policy, account/data deletion flow, reporting/blocking, and moderation before opening social features broadly.
