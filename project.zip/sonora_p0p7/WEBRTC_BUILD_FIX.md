# WebRTC build fix

The old dependency `org.webrtc:google-webrtc:1.0.32006` was published in the BT WebRTC/Bintray repository and is not available from the repositories used by the GitHub Actions build.

Sonora now uses:

```kotlin
implementation("com.dafruits:webrtc:123.0.0")
```

This artifact is available from Maven Central and exposes the `org.webrtc.*` API used by `VoiceChatEngine`.

The WebRTC classes are also kept by R8/ProGuard.

This change targets the reported `:app:checkDebugAarMetadata` dependency-resolution failure.
