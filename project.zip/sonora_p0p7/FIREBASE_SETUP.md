# Firebase setup (Listen with Friends)

1. สร้างโปรเจกต์ที่ https://console.firebase.google.com/
2. เพิ่ม Android app ใช้ applicationId: `com.personal.sonora`
3. ดาวน์โหลด `google-services.json` วางที่ `app/google-services.json`
4. เปิด **Authentication → Sign-in method → Anonymous → Enable**
5. เปิด **Realtime Database** (สร้างในโหมด test ได้ชั่วคราว)
6. วาง Rules จากไฟล์ `firebase-rules.json`  
   ⚠️ Rules แบบ `.read/.write: true` ใช้เทสเท่านั้น อย่าใช้ production จริงระยะยาว
7. Sync Gradle → Run

ไม่ต้อง login ด้วยอีเมล — แอปใช้ Anonymous Auth เบื้องหลังอัตโนมัติ
