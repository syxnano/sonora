# Sonora API configuration wired into this source ZIP

This package contains the current **public/client-safe configuration values** for the three providers already set up for Sonora:

- YouTube Data API v3: `YOUTUBE_API_KEY`
- TikTok Login Kit: `TIKTOK_CLIENT_KEY`
- X OAuth 2.0 Native App: `X_CLIENT_ID`
- Firebase: `google-services.json` + RTDB URL

## Intentionally NOT embedded

Provider client secrets are deliberately left blank. A client secret inside an Android APK is not secret and should not be shipped in the app. Use a backend/Cloud Function/secure server for confidential OAuth exchanges.

## Important

The values are wired into Gradle BuildConfig, but this does **not** mean every provider feature is already production-integrated. TikTok/X still require their official OAuth flows, scopes and provider approval where applicable.

Do not commit `local.properties` to Git.
