# Sonora P0-P7 Integration Status

This package is an implementation pass over the current v0.3 source. It is **not an APK-certified release** because this environment does not contain the Android SDK/Gradle executable.

## Implemented in this pass
- P0: Firebase Auth remains real Email/Password + Google; Firebase config is already present in the project. FCM dependency/service added. App Check client initialization retained.
- P1: Social Home remains the single entry point; provider services remain YouTube/TikTok/Music. Feed repository added for real Sonora posts.
- P2: Existing room implementation retained; room is created when a media item is opened. Existing server-time/RTDB room state remains the sync boundary.
- P3: Real Firestore-backed Sonora 1:1 DM repository, live conversation listener, unread counters, send/mark-read flow, and in-app Messenger-style DM Chat Head added.
- P4: Existing capability-based provider connectors retained; X/TikTok boundaries are explicit. Provider connection state repository added.
- P5: Provider Web DM screen and fallback architecture retained; no cookie/session extraction or private endpoint use.
- P6: Existing TikTok Flame policy/outbox retained with provider-confirmed requirement; no generic TikTok DM send was fabricated.
- P7: FCM message service added and notification deep-link extras supported by MainActivity; provider connection state is persisted per user.

## Must still be verified outside this environment
- Android Gradle compile/build and APK install on a real machine/CI.
- Google OAuth client ID must be the real Firebase Android/Web OAuth client, not a placeholder.
- Firestore composite index may be required for `dm` conversation query ordering.
- FCM server-side delivery requires trusted backend/Cloud Functions or another authorized sender; client service only handles received messages.
- X/Telegram/Meta/TikTok production OAuth and provider API permissions require provider-side app approval/configuration.
- WebView embedding is provider-dependent; Custom Tabs/official app fallback must be tested per provider.
- WebRTC microphone/network traversal requires real device testing and STUN/TURN configuration.
- Firebase App Check enforcement must be enabled in Firebase Console after testing.
