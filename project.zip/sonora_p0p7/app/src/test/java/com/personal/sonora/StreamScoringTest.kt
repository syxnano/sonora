package com.personal.sonora

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.resolver.StreamScoring
import org.junit.Assert.assertTrue
import org.junit.Test

class StreamScoringTest {

    private val track = Track(
        id = "1",
        title = "Blinding Lights",
        artist = "The Weeknd",
        durationMs = 200_000L
    )

    @Test
    fun officialTopicScoresHigherThanCover() {
        val official = StreamScoring.score(
            "Blinding Lights",
            "The Weeknd - Topic",
            200,
            track
        )
        val cover = StreamScoring.score(
            "Blinding Lights (cover)",
            "Random Cover Channel",
            210,
            track
        )
        assertTrue("Official should score higher: $official vs $cover", official > cover)
    }

    @Test
    fun durationMismatchPenalized() {
        val good = StreamScoring.score("Blinding Lights", "The Weeknd - Topic", 200, track)
        val bad = StreamScoring.score("Blinding Lights", "The Weeknd - Topic", 400, track)
        assertTrue(good > bad)
    }

    @Test
    fun normalizeStripsFeatAndPunctuation() {
        val n = StreamScoring.normalize("Song Title (feat. Artist) [Official Video]!")
        assertTrue(!n.contains("feat"))
        assertTrue(!n.contains("("))
    }

    @Test
    fun fuzzyScoreExactMatch() {
        assertTrue(StreamScoring.fuzzyScore("hello world", "hello world") == 1.0)
    }
}
