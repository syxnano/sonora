package com.personal.sonora

import com.personal.sonora.data.social.RoomPlayState
import com.personal.sonora.data.social.SyncMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyncMathTest {
    @Test fun noDriftKeepsNormalSpeed() {
        assertEquals(1f, SyncMath.speedFor(0, false), 0f)
        assertEquals(1f, SyncMath.speedFor(50, false), 0f) // below the enter threshold
    }

    @Test fun aheadSlowsDownBehindSpeedsUp() {
        assertTrue(SyncMath.speedFor(500, false) < 1f)
        assertTrue(SyncMath.speedFor(-500, false) > 1f)
    }

    @Test fun nudgeIsCappedAtFivePercent() {
        assertEquals(0.95f, SyncMath.speedFor(900, false), 0.0001f)
        assertEquals(1.05f, SyncMath.speedFor(-900, false), 0.0001f)
    }

    @Test fun hysteresisKeepsNudgingUntilDeadZone() {
        assertTrue(SyncMath.speedFor(50, true) < 1f)
        assertEquals(1f, SyncMath.speedFor(10, true), 0f)
    }

    @Test fun expectedPositionFollowsClock() {
        val playing = RoomPlayState(isPlaying = true, positionMs = 10_000, anchorTs = 1_000)
        assertEquals(13_000L, playing.expectedPositionMs(4_000))
        val paused = playing.copy(isPlaying = false)
        assertEquals(10_000L, paused.expectedPositionMs(99_000))
    }
}
