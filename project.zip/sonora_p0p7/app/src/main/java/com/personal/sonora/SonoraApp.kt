package com.personal.sonora

import android.app.Application
import com.personal.sonora.data.download.OfflineRecovery
import com.personal.sonora.util.CrashLog
import com.personal.sonora.ui.video.RoomChatNotification
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory

@HiltAndroidApp
class SonoraApp : Application() {
    @Inject lateinit var offlineRecovery: OfflineRecovery

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        // Install before anything else so even start-up crashes are captured.
        CrashLog.install(this)
        super.onCreate()
        RoomChatNotification.init(this)
        // App Check is installed in the client. Enforcement still has to be enabled in Firebase Console.
        runCatching {
            val appCheck = FirebaseAppCheck.getInstance()
            if (BuildConfig.DEBUG) {
                appCheck.installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance())
            } else {
                appCheck.installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance())
            }
        }
        // Recover playlists + offline files after reinstall (best-effort)
        appScope.launch {
            offlineRecovery.runIfNeeded()
        }
    }
}
