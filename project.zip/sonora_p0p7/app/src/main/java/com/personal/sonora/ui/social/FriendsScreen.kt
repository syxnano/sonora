package com.personal.sonora.ui.social

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personal.sonora.data.socialnet.SocialRepository
import kotlinx.coroutines.launch

@Composable
fun FriendsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope(); val repo = remember { SocialRepository() }
    var uid by remember { mutableStateOf("") }; var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("เพื่อน", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(uid, { uid = it }, Modifier.fillMaxWidth(), label = { Text("UID ของเพื่อน") })
        Spacer(Modifier.height(8.dp))
        Button(onClick = { scope.launch { runCatching { repo.sendFriendRequest(uid) }.onSuccess { message = "ส่งคำขอแล้ว" }.onFailure { message = it.message ?: "ส่งไม่สำเร็จ" } } }, Modifier.fillMaxWidth()) { Text("Add Friend") }
        Spacer(Modifier.height(16.dp))
        Text("เมื่อรับเพื่อนแล้ว ให้ใช้ UID คู่กันเป็นห้อง DM เดียวกันได้")
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = onBack, Modifier.fillMaxWidth()) { Text("กลับ") }
    }
}
