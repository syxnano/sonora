package com.personal.sonora.firebase

object FirebasePaths {
    const val USERS = "users"
    const val CONNECTIONS = "connections"
    const val OUTBOX = "outbox"
    const val FLAMES = "flames"
    const val ROOMS = "rooms"
    const val ROOM_CHAT = "roomChat"
    const val PRESENCE = "presence"
    const val WEBRTC = "webrtc"
}
