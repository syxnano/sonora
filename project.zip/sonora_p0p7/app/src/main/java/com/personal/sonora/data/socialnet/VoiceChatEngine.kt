package com.personal.sonora.data.socialnet

import android.content.Context
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.PeerConnectionFactory
import org.webrtc.MediaConstraints

/** Local microphone engine. Room signaling/ICE is intentionally kept in the room backend.
 * This class owns real microphone capture and the WebRTC audio track; it does not transcribe audio. */
class VoiceChatEngine(context: Context) {
    private val factory: PeerConnectionFactory
    private var source: AudioSource? = null
    var audioTrack: AudioTrack? = null
        private set
    var muted: Boolean = true
        private set

    init {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(context.applicationContext).createInitializationOptions())
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    fun startMic() {
        if (audioTrack != null) return
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
        }
        source = factory.createAudioSource(constraints)
        audioTrack = factory.createAudioTrack("sonora-mic", source).also { it.setEnabled(true) }
        muted = false
    }

    fun setMuted(value: Boolean) {
        muted = value
        audioTrack?.setEnabled(!value)
    }

    fun release() {
        audioTrack?.dispose(); audioTrack = null
        source?.dispose(); source = null
        factory.dispose()
    }
}
