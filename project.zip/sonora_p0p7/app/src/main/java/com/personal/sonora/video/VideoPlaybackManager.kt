package com.personal.sonora.video

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import android.webkit.WebView
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VideoPlaybackManager @Inject constructor() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(VideoPlaybackState())
    val state: StateFlow<VideoPlaybackState> = _state.asStateFlow()

    private var lastRemoteCommandAt = 0L
    private var webView: WebView? = null
    private var localPosition = 0L
    private var localDuration = 0L

    fun attachWebView(view: WebView) { webView = view }
    fun detachWebView(view: WebView) { if (webView === view) webView = null }
    fun control(action: String, positionMs: Long = 0L) {
        val sec = positionMs.coerceAtLeast(0L) / 1000.0
        webView?.evaluateJavascript(when (action) {
            "play" -> "play();"
            "pause" -> "pause();";
            "seek" -> "seek($sec);"
            else -> ""
        }, null)
    }

    fun play(item: VideoItem, startMs: Long = 0L) {
        _state.value = _state.value.copy(
            current = item,
            isPlaying = true,
            positionMs = startMs.coerceAtLeast(0L),
            durationMs = item.durationMs,
            minimized = true,
            expanded = true
        )
    }

    fun select(item: VideoItem) {
        _state.value = _state.value.copy(current = item, isPlaying = false, positionMs = 0L, durationMs = item.durationMs, minimized = true, expanded = true)
    }

    fun setPlaying(playing: Boolean, positionMs: Long = currentPosition()) {
        _state.value = _state.value.copy(isPlaying = playing, positionMs = positionMs.coerceAtLeast(0L))
    }

    fun setPosition(positionMs: Long, durationMs: Long = localDuration) {
        localPosition = positionMs.coerceAtLeast(0L)
        localDuration = durationMs.coerceAtLeast(0L)
        _state.value = _state.value.copy(positionMs = localPosition, durationMs = if (localDuration > 0) localDuration else _state.value.durationMs)
    }

    fun onSnapshot(snapshot: VideoSnapshot) {
        if (_state.value.current?.id != snapshot.id || _state.value.current?.provider != snapshot.provider) return
        localPosition = snapshot.positionMs
        localDuration = snapshot.durationMs
        _state.value = _state.value.copy(
            isPlaying = snapshot.state == 1,
            positionMs = snapshot.positionMs,
            durationMs = if (snapshot.durationMs > 0) snapshot.durationMs else _state.value.durationMs
        )
    }

    fun minimize() { _state.value = _state.value.copy(minimized = true, expanded = false) }
    fun expand() { if (_state.value.current != null) _state.value = _state.value.copy(minimized = false, expanded = true) }
    fun close() { _state.value = VideoPlaybackState() }
    fun markRemoteCommand() { lastRemoteCommandAt = SystemClock.elapsedRealtime() }
    fun shouldIgnoreLocalEvent(windowMs: Long = 1_200L): Boolean = SystemClock.elapsedRealtime() - lastRemoteCommandAt < windowMs
    fun currentPosition(): Long = localPosition.takeIf { it > 0L } ?: _state.value.positionMs
}
