package com.personal.sonora.ui.video

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

@Composable
fun RoomChatHead(vm: RoomSessionViewModel) {
    val room by vm.room.collectAsState()
    val messages by vm.messages.collectAsState()
    val open by vm.chatOpen.collectAsState()
    val mic by vm.micEnabled.collectAsState()
    val tts by vm.ttsEnabled.collectAsState(true)
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }

    if (room.code == null) return

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) text = listOf(text, spoken).filter { it.isNotBlank() }.joinToString(" ").take(500)
    }

    Box(Modifier.fillMaxWidth()) {
        if (!open) {
            FilledIconButton(
                onClick = vm::openChat,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 78.dp).size(58.dp),
                shape = CircleShape
            ) { Icon(Icons.Default.KeyboardVoice, contentDescription = "แชท") }
        }

        if (open) {
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 74.dp).fillMaxWidth(0.94f)
                    .background(Color(20,20,22), RoundedCornerShape(22.dp)).padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ห้อง ${room.code}", color = Color.White, fontSize = 17.sp)
                        Text("${room.peerCount} คน • แชทเดียวกับห้องที่กำลังดู", color = Color.Gray, fontSize = 11.sp)
                    }
                    IconButton(onClick = {
                        val body = vm.shareText() ?: return@IconButton
                        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) }, "ส่งห้อง Sonora"))
                    }) { Icon(Icons.Default.Share, null, tint = Color.White) }
                    IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
                    IconButton(onClick = vm::closeChat) { Icon(Icons.Default.Close, null, tint = Color.White) }
                }

                LazyColumn(Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 300.dp)) {
                    items(messages.takeLast(80), key = { it.id }) { msg ->
                        Column(Modifier.padding(vertical = 4.dp)) {
                            Text(msg.sender.ifBlank { "Guest" }, color = Color(150,210,255), fontSize = 11.sp)
                            Text(msg.text, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = {
                        vm.toggleMic()
                        if (!mic) {
                            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดข้อความที่จะส่ง")
                            }
                            runCatching { speechLauncher.launch(i) }.onFailure { Toast.makeText(context, "เครื่องนี้ไม่รองรับการพิมพ์ด้วยเสียง", Toast.LENGTH_SHORT).show() }
                        }
                    }) { Icon(if (mic) Icons.Default.Mic else Icons.Default.KeyboardVoice, null, tint = if (mic) Color(80,220,130) else Color.White) }
                    OutlinedTextField(value = text, onValueChange = { text = it.take(500) }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("พิมพ์ข้อความ…") })
                    FilledIconButton(onClick = { if (text.isNotBlank()) { vm.send(text); text = "" } }, enabled = text.isNotBlank()) { Icon(Icons.Default.Send, null) }
                }
            }
        }
    }

    if (settingsOpen) {
        AlertDialog(
            onDismissRequest = { settingsOpen = false },
            title = { Text("ตั้งค่าห้อง") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("อ่านแชทด้วย TTS")
                        Text("ข้อความใหม่จะอ่านออกเสียงและแจ้งเตือน", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = tts, onCheckedChange = vm::toggleTts)
                }
            },
            confirmButton = { TextButton(onClick = { settingsOpen = false }) { Text("เสร็จ") } }
        )
    }
}
