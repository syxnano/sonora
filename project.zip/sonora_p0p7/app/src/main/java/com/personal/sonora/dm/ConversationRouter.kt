package com.personal.sonora.dm

import com.personal.sonora.connectors.core.Capability
import com.personal.sonora.connectors.core.CapabilityState
import com.personal.sonora.connectors.core.SonoraConnector

class ConversationRouter(private val connectors: List<SonoraConnector>) {
    suspend fun route(target: ConversationTarget): Route {
        val connector = connectors.firstOrNull { it.platform == target.platform }
        val send = connector?.capabilities()?.firstOrNull { it.capability == Capability.SEND_MESSAGE }
        return when (send?.state) {
            CapabilityState.SUPPORTED -> Route.NativeApi
            CapabilityState.NEEDS_PERMISSION -> Route.ProviderWeb
            else -> Route.ProviderWeb
        }
    }
    enum class Route { NativeApi, ProviderWeb, ExternalFallback }
}
