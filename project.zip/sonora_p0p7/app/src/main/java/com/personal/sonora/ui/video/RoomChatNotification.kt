package com.personal.sonora.ui.video

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import com.personal.sonora.MainActivity

object RoomChatNotification {
    private const val CHANNEL = "sonora_room_chat"
    private const val REPLY_KEY = "sonora_room_reply"
    private const val NOTIFICATION_ID = 64001
    @Volatile var appContext: Context? = null
    private var tts: TextToSpeech? = null

    fun init(context: Context) {
        appContext = context.applicationContext
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sonora Room Chat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "ข้อความจากห้อง Sonora ที่กำลังอยู่"
            enableVibration(true)
        })
    }

    fun showMessage(context: Context, roomCode: String, sender: String, text: String, speak: Boolean = true) {
        if (roomCode.isBlank()) return
        init(context)
        if (speak) speak(context, "$sender: $text")
        val openIntent = PendingIntent.getActivity(
            context, roomCode.hashCode(), Intent(context, MainActivity::class.java).apply {
                data = android.net.Uri.parse("sonora://room/$roomCode")
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val replyIntent = PendingIntent.getBroadcast(
            context, (roomCode + sender).hashCode(), Intent(context, RoomReplyReceiver::class.java).apply {
                putExtra("room_code", roomCode)
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        val remoteInput = RemoteInput.Builder(REPLY_KEY).setLabel("ตอบห้องนี้…").build()
        val reply = NotificationCompat.Action.Builder(android.R.drawable.ic_menu_send, "ตอบ", replyIntent).addRemoteInput(remoteInput).build()
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(com.personal.sonora.R.drawable.ic_launcher_foreground)
            .setContentTitle("$sender • ห้อง $roomCode")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openIntent)
            .addAction(reply)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification)
    }

    private fun speak(context: Context, text: String) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("th", "TH")
                    tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "sonora-chat-${System.currentTimeMillis()}")
                }
            }
        } else {
            tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "sonora-chat-${System.currentTimeMillis()}")
        }
    }

    fun replyKey(): String = REPLY_KEY
}
