package com.personal.sonora

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.personal.sonora.player.PlayerController
import com.personal.sonora.video.VideoPlaybackManager
import com.personal.sonora.ui.components.CrashDialog
import com.personal.sonora.ui.navigation.SonoraNavGraph
import com.personal.sonora.ui.theme.SonoraTheme
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.util.CrashLog
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var playerController: PlayerController
    @Inject lateinit var videoPlaybackManager: VideoPlaybackManager

    private val pendingCardId = MutableStateFlow<String?>(null)
    private val pendingRoomCode = MutableStateFlow<String?>(null)

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val microphonePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        playerController.connect()
        pendingCardId.value = cardIdFromIntent(intent)
        pendingRoomCode.value = roomCodeFromIntent(intent)

        setContent {
            val cardId by pendingCardId.collectAsState()
            val roomCode by pendingRoomCode.collectAsState()
            SonoraTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = SpotifyBlack) {
                    SonoraNavGraph(
                        playerController = playerController,
                        videoManager = videoPlaybackManager,
                        pendingCardId = cardId,
                        onCardConsumed = { pendingCardId.value = null },
                        pendingRoomCode = roomCode,
                        onRoomConsumed = { pendingRoomCode.value = null }
                    )
                    var crash by remember { mutableStateOf(CrashLog.read(applicationContext)) }
                    crash?.let { report ->
                        CrashDialog(
                            report = report,
                            onDismiss = {
                                CrashLog.clear(applicationContext)
                                crash = null
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingCardId.value = cardIdFromIntent(intent)
        pendingRoomCode.value = roomCodeFromIntent(intent)
    }

    private fun cardIdFromIntent(intent: Intent?): String? {
        val data = intent?.data ?: return null
        return when (data.scheme) {
            "sonora" -> if (data.host == "card") data.pathSegments.firstOrNull() else null
            "https" -> if (data.host in setOf("sonora-9d7f4.web.app", "sonora-9d7f4.firebaseapp.com")) {
                data.pathSegments.let { if (it.firstOrNull() == "card") it.getOrNull(1) else null }
            } else null
            else -> null
        }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{1,64}")) }
    }

    private fun roomCodeFromIntent(intent: Intent?): String? {
        val data = intent?.data ?: return null
        return when (data.scheme) {
            "sonora" -> if (data.host == "room") data.pathSegments.firstOrNull() else null
            "https" -> if (data.host in setOf("sonora-9d7f4.web.app", "sonora-9d7f4.firebaseapp.com")) {
                data.pathSegments.let { if (it.firstOrNull() == "room") it.getOrNull(1) else null }
            } else null
            else -> null
        }?.takeIf { it.matches(Regex("\\d{6}")) }
    }
}
