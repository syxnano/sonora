package com.personal.sonora.outbox

object OutboxPolicy {
    fun mayMarkSent(providerConfirmed: Boolean): Boolean = providerConfirmed

    fun nextState(
        providerSupportsAction: Boolean,
        providerConfirmed: Boolean
    ): OutboxState = when {
        providerConfirmed -> OutboxState.SENT
        !providerSupportsAction -> OutboxState.MANUAL_REQUIRED
        else -> OutboxState.RETRYING
    }
}
