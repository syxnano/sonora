package com.personal.sonora.data.feed

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FeedRepository @Inject constructor(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class SonoraPost(
        val id: String,
        val ownerUid: String,
        val displayName: String,
        val text: String,
        val createdAt: Long
    )

    fun observePosts(): Flow<List<SonoraPost>> = callbackFlow {
        if (auth.currentUser == null) { trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, err ->
                if (err != null) { close(err); return@addSnapshotListener }
                trySend(snap?.documents.orEmpty().map {
                    SonoraPost(
                        id = it.id,
                        ownerUid = it.getString("ownerUid").orEmpty(),
                        displayName = it.getString("displayName") ?: it.getString("ownerUid").orEmpty().take(8),
                        text = it.getString("text").orEmpty(),
                        createdAt = it.getTimestamp("createdAt")?.toDate()?.time ?: 0L
                    )
                })
            }
        awaitClose { reg.remove() }
    }

    suspend fun createPost(text: String) {
        val user = auth.currentUser ?: error("Not signed in")
        require(text.trim().isNotEmpty())
        db.collection("posts").add(mapOf(
            "ownerUid" to user.uid,
            "displayName" to (user.displayName ?: user.email?.substringBefore("@") ?: "Sonora User"),
            "text" to text.trim(),
            "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )).get()
    }
}
