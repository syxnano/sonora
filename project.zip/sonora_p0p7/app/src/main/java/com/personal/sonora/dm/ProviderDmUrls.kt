package com.personal.sonora.dm

import com.personal.sonora.connectors.core.Platform

object ProviderDmUrls {
    fun inbox(platform: Platform): String? = when (platform) {
        Platform.INSTAGRAM -> "https://www.instagram.com/direct/inbox/"
        Platform.FACEBOOK -> "https://www.facebook.com/messages/"
        Platform.TIKTOK -> "https://www.tiktok.com/messages/"
        Platform.X -> "https://x.com/messages"
        Platform.THREADS -> "https://www.threads.net/"
        Platform.TELEGRAM -> "https://web.telegram.org/"
        else -> null
    }
}
