package com.personal.sonora.ui.video

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifyGreen

@Composable
fun VideoLandingScreen(
    onMusic: () -> Unit,
    onYouTube: (String) -> Unit,
    onTikTok: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val submit = {
        val q = query.trim()
        if (q.isNotBlank()) onYouTube(q)
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(20,18,24), SpotifyBlack, Color(5,5,6))))
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 24.dp)) {
            Text("SONORA", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Spacer(Modifier.height(5.dp))
            Text("ดู ฟัง และคุย — อยู่ในห้องเดียวกัน", color = Color(175,175,182), fontSize = 14.sp)
            Spacer(Modifier.height(20.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.White.copy(alpha = .07f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .08f))
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = Color.Gray)
                    androidx.compose.material3.TextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("ค้นหาเพลงหรือวิดีโอ…", color = Color.Gray) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = SpotifyGreen,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    TextButton(onClick = submit, enabled = query.isNotBlank()) { Text("ค้น", color = SpotifyGreen) }
                }
            }
        }

        Text("เลือกโลกของคุณ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            WorldCard("Sonora YouTube", "Shorts และวิดีโอสั้น < 1 นาที", "YOUTUBE", Icons.Default.Headphones, listOf(Color(255,45,55), Color(120,20,35))) { onYouTube(query) }
            WorldCard("Sonora TikTok", "เปิด TikTok ใน Sonora • เลื่อนดูได้ในห้อง", "TIKTOK", null, listOf(Color(25,25,30), Color(8,8,10))) { onTikTok(query) }
            WorldCard("Sonora Music", "Cards • Morning • Taste Memory • AI", "MUSIC", Icons.Default.MusicNote, listOf(Color(30,215,96), Color(10,70,48)), onMusic)
        }
        Spacer(Modifier.height(18.dp))
        Text("เปิดเพลงหรือวิดีโอเมื่อไร ห้องจะถูกสร้างให้อัตโนมัติ", color = Color(105,105,112), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Text("มีรหัส 6 หลักพร้อมแชร์ให้เพื่อนทันที", color = Color(105,105,112), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 3.dp))
    }
}

@Composable
private fun WorldCard(title: String, subtitle: String, badge: String, icon: ImageVector?, colors: List<Color>, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(118.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(colors)).clickable(onClick = onClick).padding(18.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Text(badge, color = Color.White.copy(alpha = .55f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(5.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Color.White.copy(alpha = .72f), fontSize = 12.sp)
        }
        if (icon != null) Icon(icon, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size(42.dp).align(Alignment.CenterEnd))
        else Text("♪", color = Color.White.copy(alpha = .9f), fontSize = 40.sp, modifier = Modifier.align(Alignment.CenterEnd))
    }
}
