package com.personal.sonora.video

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun VideoPlayerLayer(manager: VideoPlaybackManager) {
    val state by manager.state.collectAsState()
    val item = state.current ?: return

    LaunchedEffect(item.provider, item.id) { delay(900); if (manager.state.value.current?.id == item.id) manager.control("play") }

    Box(Modifier.fillMaxSize().padding(if (state.expanded) 0.dp else 12.dp), contentAlignment = if (state.expanded) Alignment.TopCenter else Alignment.BottomEnd) {
        if (state.expanded) {
            Column(
                Modifier.fillMaxSize().background(Color.Black).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.title.ifBlank { item.provider.shortName() }, color = Color.White, maxLines = 1)
                        Text(item.creator, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = { manager.minimize() }) { Icon(Icons.Default.KeyboardArrowDown, "ย่อ", tint = Color.White) }
                    IconButton(onClick = { manager.close() }) { Icon(Icons.Default.Close, "ปิด", tint = Color.White) }
                }
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    EmbeddedVideoPlayer(
                        item = item,
                        manager = manager,
                                modifier = if (item.provider == VideoProvider.TIKTOK) Modifier.width(320.dp).height(570.dp).clip(RoundedCornerShape(14.dp)) else Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)),
                        onSnapshot = manager::onSnapshot,
                        onUserAction = { snap -> manager.onSnapshot(snap) }
                    )
                }
                VideoTransport(manager, state.isPlaying, expanded = true)
            }
        } else {
            Column(
                Modifier.width(if (item.provider == VideoProvider.TIKTOK) 210.dp else 248.dp).clip(RoundedCornerShape(20.dp)).background(Color(18,18,20)).padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(item.provider.shortName(), color = Color(30,215,96), fontSize = 11.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { manager.expand() }) { Icon(Icons.Default.OpenInFull, "ขยาย", tint = Color.White) }
                    IconButton(onClick = { manager.close() }) { Icon(Icons.Default.Close, "ปิด", tint = Color.White) }
                }
                EmbeddedVideoPlayer(
                    item = item,
                    manager = manager,
                    modifier = if (item.provider == VideoProvider.TIKTOK) Modifier.fillMaxWidth().height(290.dp).clip(RoundedCornerShape(14.dp)) else Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)),
                    onSnapshot = manager::onSnapshot,
                    onUserAction = { snap -> manager.onSnapshot(snap) }
                )
                VideoTransport(manager, state.isPlaying, expanded = false)
            }
        }
    }
}

@Composable
private fun VideoTransport(manager: VideoPlaybackManager, playing: Boolean, expanded: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { manager.control(if (playing) "pause" else "play") }) {
            Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "พัก" else "เล่น", tint = Color.White)
        }
        Text(
            "${manager.state.value.positionMs / 1000}s / ${manager.state.value.durationMs / 1000}s",
            color = Color.Gray,
            fontSize = 11.sp,
            modifier = Modifier.weight(1f)
        )
        if (expanded) Text(itemProviderLabel(manager), color = Color.Gray, fontSize = 11.sp)
    }
}

private fun itemProviderLabel(manager: VideoPlaybackManager): String = manager.state.value.current?.provider?.shortName().orEmpty()
