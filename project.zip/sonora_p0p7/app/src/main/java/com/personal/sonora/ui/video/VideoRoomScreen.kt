package com.personal.sonora.ui.video

import com.personal.sonora.video.*

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.data.social.FirebaseRoomRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import javax.inject.Inject

@HiltViewModel
class VideoRoomViewModel @Inject constructor(
    val rooms: FirebaseRoomRepository,
    val controller: VideoRoomController,
    profileRepository: ProfileRepository,
    private val videoManager: VideoPlaybackManager
) : ViewModel() {
    val profile = profileRepository.profile
    val currentVideo: kotlinx.coroutines.flow.StateFlow<VideoPlaybackState> = videoManager.state
    init { controller.start() }
    fun create(name: String) = controller.create(name)
    fun join(code: String, name: String) = controller.join(code, name)
    fun leave() = controller.leave()
    fun chat(sender: String, text: String) = controller.chat(sender, text)
    fun shareCurrent() { videoManager.state.value.current?.let { controller.openVideo(it) } }
}

@Composable
fun VideoRoomScreen(
    initialRoomCode: String? = null,
    vm: VideoRoomViewModel = hiltViewModel()
) {
    val room by vm.rooms.room.collectAsState()
    val messages by vm.rooms.messages.collectAsState()
    val state by vm.rooms.state.collectAsState()
    val profile by vm.profile.collectAsState(initial = com.personal.sonora.data.profile.GuestProfile())
    val syncText by vm.controller.syncText.collectAsState()
    val currentVideo by vm.currentVideo.collectAsState()
    var joinCode by remember(initialRoomCode) { mutableStateOf(initialRoomCode.orEmpty()) }
    var chat by remember { mutableStateOf("") }
    var joined by remember(initialRoomCode) { mutableStateOf(false) }
    val chatListState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) chatListState.animateScrollToItem(messages.takeLast(80).lastIndex) }

    LaunchedEffect(initialRoomCode, profile.username, room.code) {
        val code = initialRoomCode?.takeIf { it.matches(Regex("\\d{6}")) }
        if (!joined && code != null && room.code == null && profile.username.isNotBlank()) {
            joined = true
            vm.join(code, profile.username)
        }
    }

    Column(Modifier.fillMaxSize().background(Color(7,7,7)).padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ดูด้วยกัน", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
            if (room.code != null) Text("${room.peerCount} คน", color = Color.Gray)
        }
        room.error?.let { Text(it, color = Color(1f, .4f, .4f), fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))

        if (room.code == null) {
            Text("ยังไม่มีห้องที่กำลังใช้งาน", color = Color.White, fontSize = 20.sp)
            Text("ไม่ต้องกดสร้างห้องเอง — แค่เปิดเพลงหรือวิดีโอ Sonora จะสร้างห้องและให้รหัส 6 หลักทันที", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = joinCode, onValueChange = { joinCode = it.filter(Char::isDigit).take(6) }, modifier = Modifier.weight(1f), label = { Text("เข้าห้องด้วยรหัส 6 หลัก") })
                Button(onClick = { vm.join(joinCode, profile.username) }, enabled = joinCode.length == 6) { Text("เข้า") }
            }
            Spacer(Modifier.height(16.dp))
            Text("หรือกลับไปหน้าแรกแล้วแตะวิดีโอ/เพลงที่ต้องการเปิด", color = Color.Gray, fontSize = 12.sp)
            return@Column
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ห้อง ${room.code}", color = Color(30,215,96), fontSize = 15.sp, modifier = Modifier.weight(1f))
            if (currentVideo.current != null) Button(onClick = vm::shareCurrent) { Text("แชร์วิดีโอนี้") }
        }
        Text(syncText, color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))

        val track = state?.track
        if (track != null && track.externalId != null && (track.source.equals("youtube", true) || track.source.equals("tiktok", true))) {
            val item = VideoItem(
                provider = if (track.source.equals("youtube", true)) VideoProvider.YOUTUBE else VideoProvider.TIKTOK,
                id = track.externalId!!,
                title = track.title,
                creator = track.artist,
                thumbnailUrl = track.coverUrl,
                durationMs = track.durationMs,
                url = if (track.source.equals("youtube", true)) "https://www.youtube.com/watch?v=${track.externalId}" else "https://www.tiktok.com/@_/video/${track.externalId}"
            )
            val controller = remember(track.externalId) { EmbeddedVideoController() }
            var localSnapshot by remember(track.externalId) { mutableStateOf<VideoSnapshot?>(null) }
            val latestLocalSnapshot = rememberUpdatedState(localSnapshot)
            LaunchedEffect(state?.seq, item.id) {
                state?.let { vm.controller.applyRemote(it, controller, latestLocalSnapshot.value) }
            }
            LaunchedEffect(item.id) {
                while (true) {
                    delay(1000)
                    val latest = vm.rooms.state.value
                    if (latest?.track?.externalId == item.id) {
                        vm.controller.applyRemote(latest, controller, latestLocalSnapshot.value)
                    }
                }
            }
            DisposableEffect(Unit) { onDispose { controller.webView = null } }
            EmbeddedVideoPlayer(
                item = item,
                controller = controller,
                modifier = Modifier.fillMaxWidth().height(if (item.provider == VideoProvider.TIKTOK) 420.dp else 220.dp),
                onSnapshot = { localSnapshot = it },
                onUserAction = { vm.controller.localSnapshot(it) }
            )
            Spacer(Modifier.height(6.dp))
            Text(item.title, color = Color.White, maxLines = 1)
            Text("${item.creator} • ${item.provider.shortName()}", color = Color.Gray, fontSize = 12.sp)
        } else {
            Text("ยังไม่มีวิดีโอในห้อง", color = Color.Gray)
        }

        Spacer(Modifier.height(8.dp))
        Text("ข้อความ", color = Color.White, fontSize = 17.sp)
        LazyColumn(state = chatListState, modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(messages.takeLast(80), key = { it.id }) { msg ->
                Text("${msg.sender}: ${msg.text}", color = Color.White, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = chat, onValueChange = { chat = it.take(500) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("พิมพ์ข้อความ") })
            Button(onClick = { if (chat.isNotBlank()) { vm.chat(profile.username, chat); chat = "" } }, enabled = chat.isNotBlank()) { Text("ส่ง") }
        }
        Spacer(Modifier.height(6.dp))
        Button(onClick = vm::leave, modifier = Modifier.fillMaxWidth()) { Text("ออกจากห้อง") }
    }
}
