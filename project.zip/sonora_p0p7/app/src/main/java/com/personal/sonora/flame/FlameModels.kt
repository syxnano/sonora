package com.personal.sonora.flame

data class FlameStreak(
    val friendId: String,
    val days: Int,
    val lastSuccessfulProviderMessageAtMs: Long?,
    val sentToday: Boolean
)
