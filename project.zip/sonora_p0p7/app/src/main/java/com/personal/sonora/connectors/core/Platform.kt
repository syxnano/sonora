package com.personal.sonora.connectors.core

enum class Platform {
    SONORA, YOUTUBE, TIKTOK, X, FACEBOOK, INSTAGRAM, THREADS, TELEGRAM
}
