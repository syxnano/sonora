package com.personal.sonora.data.dm

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DirectMessageRepository @Inject constructor(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class Conversation(
        val id: String,
        val otherUid: String,
        val otherName: String,
        val otherAvatar: String = "",
        val lastText: String = "",
        val lastAt: Long = 0L,
        val unread: Int = 0
    )

    data class Message(
        val id: String,
        val from: String,
        val to: String,
        val text: String,
        val createdAt: Long
    )

    private fun uid(): String = auth.currentUser?.uid ?: error("Not signed in")
    fun chatId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    fun observeMessages(otherUid: String): Flow<List<Message>> = callbackFlow {
        val me = uid()
        val id = chatId(me, otherUid)
        val registration = db.collection("dm").document(id).collection("messages")
            .orderBy("createdAt")
            .limitToLast(200)
            .addSnapshotListener { snap, error ->
                if (error != null) { close(error); return@addSnapshotListener }
                trySend(snap?.documents.orEmpty().map(::mapMessage))
            }
        awaitClose { registration.remove() }
    }

    suspend fun send(otherUid: String, text: String) {
        val me = uid()
        val clean = text.trim()
        require(clean.isNotEmpty())
        val id = chatId(me, otherUid)
        val other = db.collection("users").document(otherUid).get().await()
        val meProfile = db.collection("users").document(me).get().await()
        val otherName = other.getString("displayName") ?: otherUid.take(8)
        val myName = meProfile.getString("displayName") ?: "Sonora User"
        val batch = db.batch()
        val messageRef = db.collection("dm").document(id).collection("messages").document()
        batch.set(messageRef, mapOf(
            "from" to me, "to" to otherUid, "text" to clean,
            "createdAt" to FieldValue.serverTimestamp()
        ))
        batch.set(db.collection("dm").document(id), mapOf(
            "participants" to listOf(me, otherUid),
            "otherName_$otherUid" to otherName,
            "otherName_$me" to myName,
            "lastText" to clean,
            "lastSender" to me,
            "lastAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
            "unread_$otherUid" to FieldValue.increment(1),
            "unread_$me" to 0L
        ), com.google.firebase.firestore.SetOptions.merge())
        batch.commit().await()
    }

    fun observeConversations(): Flow<List<Conversation>> = callbackFlow {
        val me = uid()
        val registration = db.collection("dm")
            .whereArrayContains("participants", me)
            .orderBy("updatedAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snap, error ->
                if (error != null) { close(error); return@addSnapshotListener }
                val docs = snap?.documents.orEmpty()
                val result = mutableListOf<Conversation>()
                // Profile lookups are deliberately not performed in this listener. The UI can
                // render uid immediately and resolve display data separately.
                for (d in docs) {
                    val participants = (d.get("participants") as? List<*>)?.filterIsInstance<String>().orEmpty()
                    val other = participants.firstOrNull { it != me } ?: continue
                    result += Conversation(
                        id = d.id,
                        otherUid = other,
                        otherName = d.getString("otherName_$other") ?: other.take(8),
                        otherAvatar = d.getString("otherAvatar_$other") ?: "",
                        lastText = d.getString("lastText") ?: "",
                        lastAt = d.getTimestamp("lastAt")?.toDate()?.time ?: 0L,
                        unread = (d.getLong("unread_$me") ?: 0L).toInt()
                    )
                }
                trySend(result)
            }
        awaitClose { registration.remove() }
    }

    suspend fun markRead(otherUid: String) {
        val me = uid()
        db.collection("dm").document(chatId(me, otherUid)).set(
            mapOf("unread_$me" to 0L), com.google.firebase.firestore.SetOptions.merge()
        ).await()
    }

    private fun mapMessage(d: DocumentSnapshot): Message = Message(
        id = d.id,
        from = d.getString("from").orEmpty(),
        to = d.getString("to").orEmpty(),
        text = d.getString("text").orEmpty(),
        createdAt = d.getTimestamp("createdAt")?.toDate()?.time ?: 0L
    )
}
