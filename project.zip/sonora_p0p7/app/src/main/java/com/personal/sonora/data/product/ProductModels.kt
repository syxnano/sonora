package com.personal.sonora.data.product

import com.personal.sonora.data.catalog.Track
import kotlinx.serialization.Serializable

@Serializable
data class MusicCard(
    val id: String,
    val track: Track,
    val message: String = "",
    val mood: String = "",
    /** Firebase public card id after the first successful share. */
    val publicId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class TasteMemory(
    val likedArtists: List<String> = emptyList(),
    val dislikedArtists: List<String> = emptyList(),
    val likedLanguages: List<String> = emptyList(),
    val moodTags: List<String> = emptyList(),
    val explicitNotes: List<String> = emptyList(),
    /** Direct 👍/👎 feedback. Kept local and editable; never inferred as a sensitive trait. */
    val likedTrackIds: List<String> = emptyList(),
    val dislikedTrackIds: List<String> = emptyList(),
    val learningEnabled: Boolean = true
)

@Serializable
data class MorningSong(
    val enabled: Boolean = false,
    val hour: Int = 7,
    val minute: Int = 0,
    val source: String = "card",
    val message: String = "เพลงเช้าของคุณวันนี้",
    /** Optional public Music Card opened when the notification is tapped. */
    val cardId: String? = null,
    val title: String = "",
    val artist: String = ""
)

@Serializable
data class AgentRequest(
    val text: String,
    val tracks: List<Track> = emptyList()
)

@Serializable
data class AgentResult(
    val trackIds: List<String>,
    val explanation: String,
    val followUp: String? = null
)
