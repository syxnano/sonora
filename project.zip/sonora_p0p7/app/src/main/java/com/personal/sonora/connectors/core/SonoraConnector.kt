package com.personal.sonora.connectors.core

interface SonoraConnector {
    val platform: Platform
    suspend fun capabilities(): List<CapabilityStatus>
    suspend fun connect(): Result<Unit>
    suspend fun disconnect(): Result<Unit>
    suspend fun refresh(): Result<Unit>
}
