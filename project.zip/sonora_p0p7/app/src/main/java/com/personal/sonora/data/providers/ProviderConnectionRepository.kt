package com.personal.sonora.data.providers

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.awaitClose
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProviderConnectionRepository @Inject constructor(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class Connection(val provider: String, val handle: String, val connected: Boolean)

    fun observe(): Flow<List<Connection>> = callbackFlow {
        val uid = auth.currentUser?.uid ?: run { trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("users").document(uid).collection("providerConnections")
            .addSnapshotListener { snap, err ->
                if (err != null) { close(err); return@addSnapshotListener }
                trySend(snap?.documents.orEmpty().map {
                    Connection(it.id, it.getString("handle").orEmpty(), it.getBoolean("connected") == true)
                })
            }
        awaitClose { reg.remove() }
    }

    suspend fun setConnection(provider: String, handle: String, connected: Boolean) {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        db.collection("users").document(uid).collection("providerConnections").document(provider.lowercase())
            .set(mapOf("provider" to provider, "handle" to handle, "connected" to connected, "updatedAt" to FieldValue.serverTimestamp()))
    }
}
