package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

class CapabilityEngine(private val connectors: List<SonoraConnector>) {
    suspend fun snapshot(): Map<Platform, List<CapabilityStatus>> =
        connectors.associate { it.platform to it.capabilities() }

    fun can(status: CapabilityStatus): Boolean =
        status.state == CapabilityState.SUPPORTED
}
