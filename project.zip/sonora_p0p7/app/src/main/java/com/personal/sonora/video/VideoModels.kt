package com.personal.sonora.video

import kotlinx.serialization.Serializable

@Serializable
enum class VideoProvider { YOUTUBE, TIKTOK }

@Serializable
data class VideoItem(
    val provider: VideoProvider,
    val id: String,
    val title: String = "",
    val creator: String = "",
    val thumbnailUrl: String? = null,
    val durationMs: Long = 0L,
    val url: String = ""
)

data class VideoSnapshot(
    val provider: VideoProvider,
    val id: String,
    val state: Int = -1,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val receivedAtMs: Long = 0L
)

data class VideoPlaybackState(
    val current: VideoItem? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val minimized: Boolean = true,
    val expanded: Boolean = false
)

fun VideoProvider.shortName(): String = when (this) {
    VideoProvider.YOUTUBE -> "YouTube"
    VideoProvider.TIKTOK -> "TikTok"
}
