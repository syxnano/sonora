package com.personal.sonora.security

object TokenPolicy {
    const val RULES = """
        1. Never store provider passwords.
        2. Never store scraped browser cookies/session tokens.
        3. Prefer short-lived access tokens and secure refresh-token references.
        4. Keep client secrets off the Android client.
        5. Provider permissions must be explicit and revocable.
    """
}
