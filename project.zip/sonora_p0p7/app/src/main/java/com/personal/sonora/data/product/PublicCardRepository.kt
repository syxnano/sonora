package com.personal.sonora.data.product

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/** Public Music Card layer. Sonora stores metadata/messages only; playback remains on YouTube. */
@Singleton
class PublicCardRepository @Inject constructor() {
    data class InboxMessage(
        val id: String,
        val cardId: String,
        val message: String,
        val createdAt: Long,
        val fromUid: String,
        val cardTitle: String
    )

    private fun db(): FirebaseDatabase = FirebaseDatabase.getInstance()

    suspend fun authUid(): String {
        val auth = FirebaseAuth.getInstance()
        if (auth.currentUser == null) withTimeout(6_000) { auth.signInAnonymously().await() }
        return auth.currentUser?.uid ?: error("Authentication unavailable")
    }

    suspend fun publish(card: MusicCard): String {
        val uid = authUid()
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        val videoId = card.track.externalId?.takeIf { it.length == 11 }
        require(!videoId.isNullOrBlank()) { "เพลงนี้ยังไม่มี YouTube videoId" }
        val value = mapOf(
            "ownerUid" to uid,
            "title" to card.track.title.take(300),
            "artist" to card.track.artist.take(200),
            "album" to (card.track.album ?: "").take(200),
            "coverUrl" to (card.track.coverUrl ?: ""),
            "source" to "youtube",
            "youtubeVideoId" to videoId,
            "externalId" to videoId,
            "externalUrl" to "https://www.youtube.com/watch?v=$videoId",
            "message" to card.message.take(500),
            "mood" to card.mood.take(80),
            "createdAt" to ServerValue.TIMESTAMP
        )
        withTimeout(8_000) { db().getReference("publicCards").child(id).setValue(value).await() }
        return id
    }

    suspend fun get(id: String): DataSnapshot = withTimeout(8_000) {
        db().getReference("publicCards").child(id).get().await()
    }

    /** Reply is only available inside the Android app; the public web card stays read-only. */
    suspend fun reply(cardId: String, message: String) {
        val clean = message.trim().take(500)
        require(clean.isNotEmpty())
        val uid = authUid()
        val card = get(cardId)
        val ownerUid = card.child("ownerUid").getValue(String::class.java)
            ?: error("Card owner unavailable")
        val title = card.child("title").getValue(String::class.java).orEmpty()
        val id = UUID.randomUUID().toString().replace("-", "").take(16)
        val created = System.currentTimeMillis()
        val reply = mapOf(
            "uid" to uid,
            "message" to clean,
            "createdAt" to created
        )
        val inbox = mapOf(
            "cardId" to cardId,
            "message" to clean,
            "createdAt" to created,
            "fromUid" to uid,
            "cardTitle" to title.take(300)
        )
        val updates = mapOf<String, Any?>(
            "/publicCardReplies/$cardId/$id" to reply,
            "/userInbox/$ownerUid/$id" to inbox
        )
        withTimeout(8_000) { db().reference.updateChildren(updates).await() }
    }

    suspend fun inbox(): List<InboxMessage> {
        val uid = authUid()
        val snap = withTimeout(8_000) {
            db().getReference("userInbox").child(uid).orderByChild("createdAt").limitToLast(100).get().await()
        }
        return snap.children.mapNotNull { child ->
            val id = child.key ?: return@mapNotNull null
            InboxMessage(
                id = id,
                cardId = child.child("cardId").getValue(String::class.java).orEmpty(),
                message = child.child("message").getValue(String::class.java).orEmpty(),
                createdAt = child.child("createdAt").getValue(Long::class.java) ?: 0L,
                fromUid = child.child("fromUid").getValue(String::class.java).orEmpty(),
                cardTitle = child.child("cardTitle").getValue(String::class.java).orEmpty()
            )
        }.sortedByDescending { it.createdAt }
    }
    suspend fun deleteInboxMessage(id: String) {
        val uid = authUid()
        require(id.matches(Regex("[A-Za-z0-9_-]{1,64}")))
        withTimeout(8_000) {
            db().getReference("userInbox").child(uid).child(id).removeValue().await()
        }
    }

}
