package com.personal.sonora.ui.social

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.personal.sonora.data.auth.AuthRepository
import com.personal.sonora.data.socialnet.SocialRepository
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onSignedIn: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { AuthRepository(context) }
    val socialRepo = remember { SocialRepository() }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val googleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(data)
        try { repo.signInWithGoogle(task.result) { r -> if (r.isSuccess) { scope.launch { socialRepo.ensureProfile() }; onSignedIn() } else error = r.exception?.message } }
        catch (e: Exception) { error = e.message }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Sonora", style = MaterialTheme.typography.displaySmall)
        Text("เข้าสู่โลกเพลง วิดีโอ และเพื่อนของคุณ")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { repo.signIn(email, password) { r -> if (r.isSuccess) { scope.launch { socialRepo.ensureProfile() }; onSignedIn() } else error = r.exception?.message } }, modifier = Modifier.weight(1f)) { Text("เข้าสู่ระบบ") }
            OutlinedButton(onClick = { repo.signUp(email, password) { r -> if (r.isSuccess) { scope.launch { socialRepo.ensureProfile() }; onSignedIn() } else error = r.exception?.message } }, modifier = Modifier.weight(1f)) { Text("สมัคร") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { googleLauncher.launch(repo.googleClient().signInIntent) }, Modifier.fillMaxWidth()) { Text("Continue with Google") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
    }
}
