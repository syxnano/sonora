package com.personal.sonora.flame

object FlamePolicy {
    fun incrementOnlyAfterProviderConfirmation(
        providerConfirmedMessage: Boolean,
        currentDays: Int
    ): Int = if (providerConfirmedMessage) currentDays + 1 else currentDays
}
