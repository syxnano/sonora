package com.personal.sonora.accounts

import com.personal.sonora.connectors.core.Platform

class AccountCenter {
    private val accounts = mutableMapOf<Platform, ConnectedAccount>()
    fun put(account: ConnectedAccount) { accounts[account.provider] = account }
    fun get(platform: Platform): ConnectedAccount? = accounts[platform]
    fun all(): List<ConnectedAccount> = accounts.values.toList()
}
