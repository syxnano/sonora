package com.personal.sonora.ui.video

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.data.settings.SettingsRepository
import com.personal.sonora.data.social.FirebaseRoomRepository
import com.personal.sonora.video.VideoRoomController
import com.personal.sonora.video.VideoItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@HiltViewModel
class RoomSessionViewModel @Inject constructor(
    val rooms: FirebaseRoomRepository,
    private val profileRepository: ProfileRepository,
    private val settings: SettingsRepository,
    private val controller: VideoRoomController
) : ViewModel() {
    val room = rooms.room
    val messages = rooms.messages
    val ttsEnabled = settings.roomTtsEnabled
    val profile = profileRepository.profile

    private val _chatOpen = MutableStateFlow(false)
    val chatOpen: StateFlow<Boolean> = _chatOpen.asStateFlow()

    private val _micEnabled = MutableStateFlow(false)
    val micEnabled: StateFlow<Boolean> = _micEnabled.asStateFlow()

    private val seenMessages = HashSet<String>()

    init {
        controller.start()
        viewModelScope.launch {
            rooms.messages.collectLatest { list ->
                list.takeLast(80).forEach { msg ->
                    if (msg.uid != rooms.myId && seenMessages.add(msg.id)) {
                        val ctx = RoomChatNotification.appContext ?: return@forEach
                        val speak = settings.roomTtsEnabled.first()
                        RoomChatNotification.showMessage(
                            context = ctx,
                            roomCode = rooms.room.value.code ?: return@forEach,
                            sender = msg.sender,
                            text = msg.text,
                            speak = speak
                        )
                    }
                }
            }
        }
    }

    fun ensureRoom() = viewModelScope.launch {
        if (rooms.room.value.code == null) {
            val name = profileRepository.profile.first().username
            rooms.createRoom(name)
        }
    }

    fun join(code: String) = viewModelScope.launch {
        val name = profileRepository.profile.first().username
        rooms.joinRoom(code.filter(Char::isDigit).take(6), name)
    }

    fun openVideo(item: VideoItem, onReady: (() -> Unit)? = null) = viewModelScope.launch {
        ensureRoomNow()
        if (rooms.room.value.code != null) {
            controller.openVideo(item)
            onReady?.invoke()
        }
    }

    fun openMusic(track: com.personal.sonora.data.catalog.Track, onReady: (() -> Unit)? = null) = viewModelScope.launch {
        ensureRoomNow()
        if (rooms.room.value.code != null) {
            controller.openTrack(track)
            onReady?.invoke()
        }
    }

    private suspend fun ensureRoomNow(): Boolean {
        if (rooms.room.value.code != null) return true
        val name = profileRepository.profile.first().username.ifBlank { "Guest" }
        return rooms.createRoom(name) != null && rooms.room.value.code != null
    }

    fun send(text: String) {
        val name = rooms.myName
        controller.chat(name, text)
    }

    fun openChat() { _chatOpen.value = true }
    fun closeChat() { _chatOpen.value = false }
    fun toggleMic() { _micEnabled.value = !_micEnabled.value }

    fun toggleTts(enabled: Boolean) = viewModelScope.launch {
        settings.setRoomTtsEnabled(enabled)
    }

    fun shareText(): String? {
        val code = rooms.room.value.code ?: return null
        return "เข้าห้อง Sonora ของฉัน\nรหัส 6 หลัก: $code\nhttps://sonora-9d7f4.web.app/room/$code"
    }
}
