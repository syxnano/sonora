package com.personal.sonora.accounts

import com.personal.sonora.connectors.core.Platform

data class ConnectedAccount(
    val provider: Platform,
    val providerUserId: String?,
    val displayName: String?,
    val avatarUrl: String?,
    val connected: Boolean,
    val accessTokenRef: String? = null,
    val refreshTokenRef: String? = null,
    val expiresAtMs: Long? = null,
    val lastError: String? = null
)
