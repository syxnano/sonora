package com.personal.sonora.data.youtube

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.spotify.ImportedPlaylist
import com.personal.sonora.data.spotify.PlaylistImportException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Imports a PUBLIC (or unlisted) YouTube / YouTube Music playlist by link using NewPipe Extractor.
 * Videos keep their real video id, so playback does not need to search again.
 */
@Singleton
class YouTubePlaylistImporter @Inject constructor() {

    private val service get() = ServiceList.YouTube
    private val listRegex = Regex("[?&]list=([A-Za-z0-9_\\-]+)")
    private val videoRegex = Regex("(?:v=|/embed/|/shorts/|youtu\\.be/)([A-Za-z0-9_\\-]{11})")
    private val maxTracks = 300

    fun looksLikeYouTube(link: String): Boolean {
        val t = link.lowercase()
        return t.contains("youtube.com") || t.contains("youtu.be") || t.contains("music.youtube")
    }

    suspend fun fetch(link: String): ImportedPlaylist = withContext(Dispatchers.IO) {
        val listId = listRegex.find(link)?.groupValues?.get(1)
            ?: throw PlaylistImportException(
                "That link has no playlist in it. Open the playlist page and copy its link (it contains list=...)."
            )
        if (listId.startsWith("RD")) {
            throw PlaylistImportException(
                "YouTube Mix / Radio playlists cannot be imported. Use a normal saved playlist."
            )
        }
        if (listId == "WL" || listId == "LL") {
            throw PlaylistImportException(
                "Watch Later and Liked videos are private. Copy them into a public playlist first."
            )
        }
        val url = "https://www.youtube.com/playlist?list=$listId"

        val items = ArrayList<StreamInfoItem>()
        val name: String
        val cover: String?
        try {
            val info = PlaylistInfo.getInfo(service, url)
            name = info.name?.trim().orEmpty()
            cover = info.thumbnails?.maxByOrNull { it.height }?.url
            items += info.relatedItems.filterIsInstance<StreamInfoItem>()
            var page = info.nextPage
            while (page != null && items.size < maxTracks) {
                val more = PlaylistInfo.getMoreItems(service, url, page)
                items += more.items.filterIsInstance<StreamInfoItem>()
                page = more.nextPage
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: PlaylistImportException) {
            throw e
        } catch (e: Throwable) {
            throw PlaylistImportException(
                "Could not read the playlist (${e.javaClass.simpleName}). Is it public?"
            )
        }

        val found = LinkedHashMap<String, Track>()
        for (item in items) {
            val track = toTrack(item) ?: continue
            if (!found.containsKey(track.id)) found[track.id] = track
            if (found.size >= maxTracks) break
        }
        if (found.isEmpty()) {
            throw PlaylistImportException("No playable videos found in that playlist.")
        }
        ImportedPlaylist(
            name = name.ifEmpty { "YouTube playlist" },
            coverUrl = cover ?: found.values.firstNotNullOfOrNull { it.coverUrl },
            tracks = found.values.toList()
        )
    }

    private fun toTrack(item: StreamInfoItem): Track? {
        val itemUrl = item.url ?: return null
        val videoId = videoRegex.find(itemUrl)?.groupValues?.get(1) ?: return null
        val title = item.name?.trim().orEmpty()
        if (title.isEmpty() || title == "[Deleted video]" || title == "[Private video]") return null
        val artist = (item.uploaderName ?: "")
            .removeSuffix(" - Topic")
            .trim()
        return Track(
            id = "yt_$videoId",
            title = title,
            artist = artist,
            durationMs = if (item.duration > 0) item.duration * 1000L else 0L,
            coverUrl = item.thumbnails?.maxByOrNull { it.height }?.url,
            source = "youtube",
            externalId = videoId
        )
    }
}
