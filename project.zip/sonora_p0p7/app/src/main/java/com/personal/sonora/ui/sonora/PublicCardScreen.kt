package com.personal.sonora.ui.sonora

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.product.PublicCardRepository
import com.personal.sonora.video.VideoItem
import com.personal.sonora.video.VideoPlaybackManager
import com.personal.sonora.video.VideoProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PublicCardViewModel @Inject constructor(private val repo: PublicCardRepository) : ViewModel() {
    var state by mutableStateOf<State>(State.Loading); private set

    sealed interface State {
        data object Loading : State
        data class Ready(val title: String, val artist: String, val message: String, val videoId: String?) : State
        data class Error(val message: String) : State
    }

    fun load(id: String) = viewModelScope.launch {
        state = State.Loading
        runCatching { repo.get(id) }
            .onSuccess { s ->
                if (!s.exists()) state = State.Error("ไม่พบ Music Card นี้")
                else {
                    val yt = s.child("youtubeVideoId").getValue(String::class.java)
                        ?: s.child("externalId").getValue(String::class.java)
                    state = State.Ready(
                        s.child("title").getValue(String::class.java).orEmpty(),
                        s.child("artist").getValue(String::class.java).orEmpty(),
                        s.child("message").getValue(String::class.java).orEmpty(),
                        yt?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
                    )
                }
            }
            .onFailure { state = State.Error("เปิด Music Card ไม่สำเร็จ ลองใหม่อีกครั้ง") }
    }
}

@Composable
fun PublicCardScreen(
    id: String,
    onBack: () -> Unit,
    videoManager: VideoPlaybackManager,
    onOpenVideo: (VideoItem) -> Unit,
    vm: PublicCardViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    LaunchedEffect(id) { vm.load(id) }

    Column(Modifier.fillMaxSize().background(Color(8,8,8)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Sonora", color = Color.White, fontSize = 26.sp)
            Text("Music Card", color = Color(30,215,96), fontSize = 14.sp)
        }
        Spacer(Modifier.height(14.dp))
        when (val s = vm.state) {
            PublicCardViewModel.State.Loading -> Text("กำลังเปิด Music Card…", color = Color.White)
            is PublicCardViewModel.State.Error -> {
                Text(s.message, color = Color.White)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onBack) { Text("กลับ") }
            }
            is PublicCardViewModel.State.Ready -> {
                Text(s.title, color = Color.White, fontSize = 24.sp)
                Text(s.artist, color = Color.LightGray, fontSize = 16.sp)
                if (s.message.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Text("“${s.message}”", color = Color.White, fontSize = 18.sp)
                }
                Spacer(Modifier.height(20.dp))
                if (s.videoId != null) {
                    Button(
                        onClick = {
                            onOpenVideo(VideoItem(VideoProvider.YOUTUBE, s.videoId, s.title, s.artist, durationMs = 0L, url = "https://www.youtube.com/watch?v=${s.videoId}"))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(30,215,96))
                    ) { Text("▶ ดูใน Sonora", color = Color.Black) }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${s.videoId}"))) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(40,40,40))
                    ) { Text("เปิดบน YouTube", color = Color.White) }
                }
                Spacer(Modifier.height(10.dp))
                Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("กลับ") }
            }
        }
    }
}
