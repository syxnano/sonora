package com.personal.sonora.data.social

import com.personal.sonora.data.catalog.Track
import kotlin.math.abs

/* ---------- (de)serialisation helpers: plain Maps, no reflection-based POJO mapping ---------- */

internal fun Map<*, *>.str(key: String): String? = this[key] as? String
internal fun Map<*, *>.lng(key: String): Long? = (this[key] as? Number)?.toLong()

internal fun Track.toRoomMap(): Map<String, Any?> = mapOf(
    "id" to id,
    "title" to title,
    "artist" to artist,
    "album" to album,
    "durationMs" to durationMs,
    "coverUrl" to coverUrl,
    "source" to source,
    "externalId" to externalId
)

internal fun parseTrack(v: Any?): Track? {
    val m = v as? Map<*, *> ?: return null
    val id = m.str("id")
    if (id.isNullOrBlank()) return null
    return Track(
        id = id,
        title = m.str("title") ?: "",
        artist = m.str("artist") ?: "",
        album = m.str("album"),
        durationMs = m.lng("durationMs") ?: 0L,
        coverUrl = m.str("coverUrl"),
        source = m.str("source") ?: "youtube",
        externalId = m.str("externalId")
    )
}

/**
 * The single shared "timeline" of a room.
 *
 * Every device derives where the song should be *right now* from
 * (positionMs, anchorTs, isPlaying) and the shared server clock:
 *     expected = positionMs + (serverNow - anchorTs)   while playing
 *     expected = positionMs                            while paused
 * so nobody needs to send "sync" messages; each device just chases this line.
 */
data class RoomPlayState(
    val seq: Long = 0L,
    val index: Int = 0,
    val track: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val anchorTs: Long = 0L,
    val by: String = "",
    val byName: String = ""
) {
    fun expectedPositionMs(serverNow: Long): Long =
        if (isPlaying) positionMs + (serverNow - anchorTs).coerceAtLeast(0L) else positionMs

    fun toMap(): Map<String, Any?> = mapOf(
        "seq" to seq,
        "index" to index,
        "track" to track?.toRoomMap(),
        "isPlaying" to isPlaying,
        "positionMs" to positionMs,
        "anchorTs" to anchorTs,
        "by" to by,
        "byName" to byName
    )

    companion object {
        fun fromAny(v: Any?): RoomPlayState? {
            val m = v as? Map<*, *> ?: return null
            return RoomPlayState(
                seq = m.lng("seq") ?: 0L,
                index = (m.lng("index") ?: 0L).toInt(),
                track = parseTrack(m["track"]),
                isPlaying = m["isPlaying"] == true,
                positionMs = m.lng("positionMs") ?: 0L,
                anchorTs = m.lng("anchorTs") ?: 0L,
                by = m.str("by") ?: "",
                byName = m.str("byName") ?: ""
            )
        }
    }
}

/** The shared playlist / queue. [autoIds] = tracks added by the auto-continue feature. */
data class RoomQueue(
    val rev: Long = 0L,
    val items: List<Track> = emptyList(),
    val autoIds: Set<String> = emptySet()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "rev" to rev,
        "items" to items.map { t ->
            val base = t.toRoomMap().toMutableMap()
            base["auto"] = t.id in autoIds
            base
        }
    )

    companion object {
        fun fromAny(v: Any?): RoomQueue {
            val m = v as? Map<*, *> ?: return RoomQueue()
            val raw = m["items"]
            val list: List<Any?> = when (raw) {
                is List<*> -> raw
                is Map<*, *> -> raw.entries
                    .sortedBy { (it.key as? String)?.toIntOrNull() ?: Int.MAX_VALUE }
                    .map { it.value }
                else -> emptyList()
            }
            val items = ArrayList<Track>()
            val autos = HashSet<String>()
            for (e in list) {
                val t = parseTrack(e) ?: continue
                items.add(t)
                if ((e as? Map<*, *>)?.get("auto") == true) autos.add(t.id)
            }
            return RoomQueue(rev = m.lng("rev") ?: 0L, items = items, autoIds = autos)
        }
    }
}

/** "I want to play a song that is not part of the current playlist — do you agree?" */
data class RoomRequest(
    val id: String = "",
    val by: String = "",
    val byName: String = "",
    val status: String = STATUS_PENDING,
    val ts: Long = 0L,
    val track: Track? = null,
    val queue: List<Track> = emptyList(),
    val autoIds: Set<String> = emptySet(),
    val startIndex: Int = 0
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "by" to by,
        "byName" to byName,
        "status" to status,
        "ts" to ts,
        "track" to track?.toRoomMap(),
        "startIndex" to startIndex,
        "queue" to RoomQueue(0L, queue, autoIds).toMap()
    )

    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_ACCEPTED = "accepted"
        const val STATUS_REJECTED = "rejected"
        const val STATUS_EXPIRED = "expired"

        fun fromAny(v: Any?): RoomRequest? {
            val m = v as? Map<*, *> ?: return null
            val id = m.str("id") ?: return null
            val q = RoomQueue.fromAny(m["queue"])
            return RoomRequest(
                id = id,
                by = m.str("by") ?: "",
                byName = m.str("byName") ?: "",
                status = m.str("status") ?: STATUS_PENDING,
                ts = m.lng("ts") ?: 0L,
                track = parseTrack(m["track"]),
                queue = q.items,
                autoIds = q.autoIds,
                startIndex = (m.lng("startIndex") ?: 0L).toInt()
            )
        }
    }
}

/** Pure sync maths (kept free of Android types so it is unit-testable). */
object SyncMath {
    /** Beyond this drift we seek (one tiny hiccup) instead of nudging the speed. */
    const val HARD_SEEK_MS = 1000L
    /** Below this drift the speed is reset to exactly 1.0x. */
    const val DEAD_ZONE_MS = 30L
    /** A drift must exceed this before we start nudging (hysteresis, avoids flapping). */
    const val ENTER_MS = 80L
    /** Max tempo change: ±5 % is inaudible with pitch-preserving time stretching. */
    const val MAX_NUDGE = 0.05f
    /** We aim to close the gap in roughly this many milliseconds. */
    private const val HORIZON_MS = 6000f

    /**
     * @param driftMs  actual - expected. Positive = this device is AHEAD.
     * @return playback speed to use (1.0 = normal)
     */
    fun speedFor(driftMs: Long, currentlyNudging: Boolean): Float {
        val a = abs(driftMs)
        if (a < DEAD_ZONE_MS) return 1f
        if (!currentlyNudging && a < ENTER_MS) return 1f
        val correction = (driftMs / HORIZON_MS).coerceIn(-MAX_NUDGE, MAX_NUDGE)
        return 1f - correction
    }
}
