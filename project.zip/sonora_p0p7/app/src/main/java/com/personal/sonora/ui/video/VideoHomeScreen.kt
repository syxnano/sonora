package com.personal.sonora.ui.video

import com.personal.sonora.video.*

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun VideoHomeScreen(
    manager: VideoPlaybackManager,
    onSearch: () -> Unit,
    onFriends: () -> Unit
) {
    val state by manager.state.collectAsState()
    Column(Modifier.fillMaxSize().background(Color(8,8,8)).padding(16.dp)) {
        Text("Sonora", color = Color.White, fontSize = 30.sp)
        Text("ดูวิดีโอแบบไม่ต้องสลับแอพ", color = Color.LightGray)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = state.current?.provider == VideoProvider.YOUTUBE, onClick = onSearch, label = { Text("YouTube") })
            FilterChip(selected = state.current?.provider == VideoProvider.TIKTOK, onClick = onSearch, label = { Text("TikTok") })
            FilterChip(selected = false, onClick = onFriends, label = { Text("ดูด้วยกัน") })
        }
        Spacer(Modifier.height(24.dp))
        Text("เลือกแอพ แล้วค้นหาได้เลย", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(8.dp))
        Text("YouTube: เฉพาะวิดีโอสั้นต่ำกว่า 1 นาที • TikTok: เปิดผ่าน TikTok Embed Player", color = Color.Gray)
    }
}
