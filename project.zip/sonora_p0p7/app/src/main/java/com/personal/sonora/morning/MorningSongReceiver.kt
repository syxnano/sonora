package com.personal.sonora.morning

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.personal.sonora.MainActivity
import com.personal.sonora.R

class MorningSongReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("sonora_morning", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Morning Song", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val cardId = prefs.getString("cardId", null)?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{1,64}")) }
        val openIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (cardId != null) data = Uri.parse("sonora://card/$cardId")
        }
        val openApp = PendingIntent.getActivity(
            context,
            7002,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val message = prefs.getString("message", "เพลงเช้าของคุณวันนี้").orEmpty()
        val title = prefs.getString("title", "").orEmpty()
        val artist = prefs.getString("artist", "").orEmpty()
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(if (title.isBlank()) "Sonora ☀️" else "☀️ $title")
            .setContentText(
                buildString {
                    if (artist.isNotBlank()) append(artist).append(" • ")
                    append(message)
                }.take(180)
            )
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .build()
        nm.notify(7001, notification)

        MorningSongScheduler(context).schedule(
            prefs.getInt("hour", 7),
            prefs.getInt("minute", 0),
            message,
            cardId,
            title,
            artist
        )
    }

    companion object { private const val CHANNEL = "morning_song" }
}
