package com.personal.sonora.data.catalog

import kotlinx.serialization.Serializable

@Serializable
data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val durationMs: Long = 0L,
    val coverUrl: String? = null,
    val source: String = "youtube",
    val externalId: String? = null
)

@Serializable
data class Artist(
    val id: String,
    val name: String,
    val imageUrl: String? = null
)

@Serializable
data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val coverUrl: String? = null,
    val trackCount: Int = 0
)

enum class SearchType {
    ALL, SONGS, ARTISTS, ALBUMS, PLAYLISTS
}

data class SearchResult(
    val tracks: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList()
)
