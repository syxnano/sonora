package com.personal.sonora.ui.navigation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.sonora.PublicCardScreen
import com.personal.sonora.ui.sonora.SonoraScreen
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.video.RoomChatHead
import com.personal.sonora.ui.video.RoomSessionViewModel
import com.personal.sonora.ui.video.VideoLandingScreen
import com.personal.sonora.ui.video.VideoRoomScreen
import com.personal.sonora.ui.video.VideoSearchScreen
import com.personal.sonora.ui.social.AuthScreen
import com.personal.sonora.ui.social.SocialHomeScreen
import com.personal.sonora.ui.social.FriendsScreen
import com.personal.sonora.ui.dm.ChatHubScreen
import com.personal.sonora.ui.dm.ProviderWebDmScreen
import com.personal.sonora.ui.dm.DirectConversationScreen
import com.personal.sonora.ui.dm.DmChatHeadOverlay
import com.personal.sonora.dm.ConversationTarget
import com.google.firebase.auth.FirebaseAuth
import com.personal.sonora.video.VideoPlaybackManager
import com.personal.sonora.video.VideoProvider
import com.personal.sonora.ui.theme.SpotifyElevated
import com.personal.sonora.ui.theme.SpotifyGreen
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Search : Screen("search/{provider}?q={q}") { fun create(provider: VideoProvider, q: String = "") = "search/${provider.name.lowercase()}?q=${android.net.Uri.encode(q)}" }
    data object Music : Screen("music")
    data object YouTube : Screen("youtube") { const val routeName = "youtube" }
    data object TikTok : Screen("tiktok") { const val routeName = "tiktok" }
    data object Social : Screen("social?code={code}") { fun create(code: String? = null) = if (code.isNullOrBlank()) "social" else "social?code=$code" }
    data object Card : Screen("card/{id}") { fun create(id: String) = "card/$id" }
    data object Library : Screen("library")
    data object Settings : Screen("settings")
    data object Friends : Screen("friends")
    data object Chats : Screen("chats")
    data object SonoraDm : Screen("sonora_dm/{uid}/{name}") {
        fun create(uid: String, name: String) = "sonora_dm/${android.net.Uri.encode(uid)}/${android.net.Uri.encode(name)}"
    }
    data object ProviderDm : Screen("provider_dm/{platform}/{name}/{url}") {
        fun create(platform: String, name: String, url: String) = "provider_dm/$platform/${android.net.Uri.encode(name)}/${android.net.Uri.encode(url)}"
    }
}

@Composable
fun SonoraNavGraph(
    playerController: PlayerController,
    videoManager: VideoPlaybackManager,
    pendingCardId: String? = null,
    onCardConsumed: () -> Unit = {},
    pendingRoomCode: String? = null,
    onRoomConsumed: () -> Unit = {}
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val entry by navController.currentBackStackEntryAsState()
    val current = entry?.destination
    val currentRoute = current?.route.orEmpty()
    val roomVm: RoomSessionViewModel = hiltViewModel()
    val videoState by videoManager.state.collectAsState()
    val roomState by roomVm.room.collectAsState()
    val showBottom = currentRoute == Screen.Home.route || currentRoute.startsWith("search/") || currentRoute == Screen.Music.route || currentRoute == Screen.Social.route

    LaunchedEffect(currentRoute) { if (currentRoute.startsWith("search/") && videoState.current != null) videoManager.minimize() }

    LaunchedEffect(pendingCardId) {
        pendingCardId?.let { navController.navigate(Screen.Card.create(it)) { launchSingleTop = true }; onCardConsumed() }
    }
    LaunchedEffect(pendingRoomCode) {
        pendingRoomCode?.let { roomVm.join(it); navController.navigate(Screen.Social.create(it)) { launchSingleTop = true }; onRoomConsumed() }
    }

    Box {
        Scaffold(
            containerColor = SpotifyBlack,
            bottomBar = {
                if (showBottom && !videoState.expanded) {
                    NavigationBar(containerColor = SpotifyBlack) {
                        val items = listOf(
                            Triple(Screen.Home, Icons.Default.Home, "ดู"),
                            Triple(Screen.Search, Icons.Default.Search, "ค้นหา"),
                            Triple(Screen.Social, Icons.Default.Group, "ห้อง")
                        )
                        items.forEach { (screen, icon, label) ->
                            NavigationBarItem(
                                selected = current?.hierarchy?.any { it.route == screen.route || (screen == Screen.Search && it.route?.startsWith("search/") == true) || (screen == Screen.Social && it.route?.startsWith("social") == true) } == true,
                                onClick = {
                                    val destination = when (screen) {
                                        Screen.Search -> Screen.Search.create(VideoProvider.YOUTUBE)
                                        else -> screen.route
                                    }
                                    navController.navigate(destination) {
                                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(icon, null) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, selectedTextColor = Color.White, unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray, indicatorColor = Color.Transparent)
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(navController, startDestination = Screen.Home.route, modifier = Modifier.padding(padding)) {
                composable(Screen.Home.route) {
                    if (FirebaseAuth.getInstance().currentUser == null) {
                        AuthScreen { navController.navigate(Screen.Home.route) { popUpTo(Screen.Home.route) { inclusive = true } } }
                    } else {
                        SocialHomeScreen(
                            onSearch = { q -> navController.navigate(Screen.Search.create(VideoProvider.YOUTUBE, q)) },
                            onMusic = { navController.navigate(Screen.Music.route) },
                            onYouTube = { q -> navController.navigate(Screen.Search.create(VideoProvider.YOUTUBE, q)) },
                            onTikTok = { q -> navController.navigate(Screen.Search.create(VideoProvider.TIKTOK, q)) },
                            onX = { navController.navigate(Screen.ProviderDm.create("x", "Sonora X", "https://x.com/explore")) },
                            onFriends = { navController.navigate(Screen.Friends.route) },
                            onChats = { navController.navigate(Screen.Chats.route) }
                        )
                    }
                }
                composable(
                    route = Screen.Search.route,
                    arguments = listOf(
                        navArgument("provider") { type = NavType.StringType },
                        navArgument("q") { type = NavType.StringType; nullable = true; defaultValue = "" }
                    )
                ) { backStack ->
                    val provider = if (backStack.arguments?.getString("provider") == "tiktok") VideoProvider.TIKTOK else VideoProvider.YOUTUBE
                    val q = backStack.arguments?.getString("q").orEmpty()
                    VideoSearchScreen(videoManager, provider, q, roomVm)
                }
                composable(Screen.Music.route) {
                    SonoraScreen(
                        playerController = playerController,
                        onOpenRoom = { navController.navigate(Screen.Social.create()) },
                        onOpenCard = { id -> navController.navigate(Screen.Card.create(id)) },
                        onOpenMusic = { track ->
                            roomVm.openMusic(track) { playerController.play(track) }
                        }
                    )
                }
                composable(Screen.Social.route, arguments = listOf(navArgument("code") { type = NavType.StringType; nullable = true; defaultValue = null })) { backStack ->
                    VideoRoomScreen(initialRoomCode = backStack.arguments?.getString("code"))
                }
                composable(Screen.Card.route) { backStack ->
                    PublicCardScreen(
                        id = backStack.arguments?.getString("id").orEmpty(),
                        onBack = { navController.popBackStack() },
                        videoManager = videoManager,
                        onOpenVideo = { item -> roomVm.openVideo(item) { videoManager.play(item) } }
                    )
                }
                composable(Screen.Library.route) { com.personal.sonora.ui.library.LibraryScreen(playerController = playerController, onOpenSettings = { }, onOpenPlaylist = { }, onOpenDownloads = { }, onOpenSocial = { navController.navigate(Screen.Social.create()) }) }
                composable(Screen.Settings.route) { com.personal.sonora.ui.settings.SettingsScreen(onBack = { navController.popBackStack() }) }
                composable(Screen.Friends.route) { FriendsScreen(onBack = { navController.popBackStack() }) }
                composable(Screen.Chats.route) {
                    ChatHubScreen(
                        onBack = { navController.popBackStack() },
                        onOpenSonora = { uid, name -> navController.navigate(Screen.SonoraDm.create(uid, name)) },
                        onOpenProvider = { head ->
                            val url = head.conversationUrl ?: return@ChatHubScreen
                            navController.navigate(Screen.ProviderDm.create(head.platform.name.lowercase(), head.displayName, url))
                        }
                    )
                }
                composable(Screen.SonoraDm.route, arguments = listOf(
                    navArgument("uid") { type = NavType.StringType },
                    navArgument("name") { type = NavType.StringType }
                )) { backStack ->
                    DirectConversationScreen(
                        otherUid = backStack.arguments?.getString("uid").orEmpty(),
                        displayName = backStack.arguments?.getString("name").orEmpty(),
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(
                    Screen.ProviderDm.route,
                    arguments = listOf(
                        navArgument("platform") { type = NavType.StringType },
                        navArgument("name") { type = NavType.StringType },
                        navArgument("url") { type = NavType.StringType }
                    )
                ) { backStack ->
                    val name = backStack.arguments?.getString("name").orEmpty()
                    val url = backStack.arguments?.getString("url").orEmpty()
                    ProviderWebDmScreen(
                        target = ConversationTarget(
                            platform = com.personal.sonora.connectors.core.Platform.entries.firstOrNull { it.name.equals(backStack.arguments?.getString("platform"), true) } ?: com.personal.sonora.connectors.core.Platform.SONORA,
                            displayName = name,
                            conversationUrl = url
                        ),
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
        if (videoState.current != null) com.personal.sonora.video.VideoPlayerLayer(videoManager)
        if (currentRoute != Screen.Chats.route && currentRoute != Screen.SonoraDm.route) {
            DmChatHeadOverlay(onOpen = { uid, name -> navController.navigate(Screen.SonoraDm.create(uid, name)) })
        }
        if (!videoState.expanded) RoomChatHead(roomVm)
        if (roomState.code != null) {
            RoomCodePill(
                code = roomState.code!!,
                people = roomState.peerCount,
                onCopy = {
                    val text = roomVm.shareText() ?: return@RoomCodePill
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Sonora room", text))
                    Toast.makeText(context, "คัดลอกลิงก์เข้าห้องแล้ว", Toast.LENGTH_SHORT).show()
                },
                onShare = {
                    val text = roomVm.shareText() ?: return@RoomCodePill
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text) }
                    context.startActivity(android.content.Intent.createChooser(send, "แชร์ห้อง Sonora"))
                }
            )
        }
    }
}

@androidx.compose.runtime.Composable
private fun RoomCodePill(code: String, people: Int, onCopy: () -> Unit, onShare: () -> Unit) {
    androidx.compose.material3.Surface(
        modifier = androidx.compose.ui.Modifier.padding(top = 12.dp).align(Alignment.TopCenter),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp),
        color = SpotifyElevated.copy(alpha = 0.96f),
        tonalElevation = 8.dp
    ) {
        androidx.compose.foundation.layout.Row(
            modifier = androidx.compose.ui.Modifier.padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.material3.Text("ROOM $code", color = Color.White, fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            androidx.compose.material3.Text("  •  $people คน", color = Color.Gray, fontSize = 11.sp)
            IconButton(onClick = onCopy) { Icon(androidx.compose.material.icons.Icons.Default.ContentCopy, "คัดลอก", tint = Color.White) }
            IconButton(onClick = onShare) { Icon(androidx.compose.material.icons.Icons.Default.Share, "แชร์", tint = SpotifyGreen) }
        }
    }
}
