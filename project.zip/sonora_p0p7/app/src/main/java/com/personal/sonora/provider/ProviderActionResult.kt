package com.personal.sonora.provider

sealed class ProviderActionResult {
    data object Success : ProviderActionResult()
    data class NeedsReconnect(val reason: String) : ProviderActionResult()
    data class NeedsPermission(val reason: String) : ProviderActionResult()
    data class ManualRequired(val reason: String) : ProviderActionResult()
    data class Retry(val reason: String) : ProviderActionResult()
}
