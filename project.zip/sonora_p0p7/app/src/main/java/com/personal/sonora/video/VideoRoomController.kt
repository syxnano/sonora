package com.personal.sonora.video

import android.os.SystemClock
import com.personal.sonora.data.social.FirebaseRoomRepository
import com.personal.sonora.data.social.RoomPlayState
import com.personal.sonora.data.social.RoomQueue
import com.personal.sonora.data.catalog.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs

@Singleton
class VideoRoomController @Inject constructor(private val rooms: FirebaseRoomRepository) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _syncText = MutableStateFlow("พร้อม")
    val syncText: StateFlow<String> = _syncText.asStateFlow()
    private var heartbeat: Job? = null
    private var ignoreUntil = 0L

    fun start() {
        if (heartbeat?.isActive == true) return
        heartbeat = scope.launch {
            while (true) {
                syncTextFromState()
                delay(1000)
            }
        }
    }

    fun create(name: String) = scope.launch { rooms.createRoom(name) }
    fun join(code: String, name: String) = scope.launch { rooms.joinRoom(code, name) }
    fun leave() = rooms.leave()
    fun chat(sender: String, text: String) = rooms.sendChat(sender, text)

    fun openVideo(item: VideoItem) {
        val track = Track(
            id = "${item.provider.name.lowercase()}_${item.id}",
            title = item.title,
            artist = item.creator,
            durationMs = item.durationMs,
            coverUrl = item.thumbnailUrl,
            source = item.provider.name.lowercase(),
            externalId = item.id
        )
        openTrack(track)
    }

    /** Publish any opened Sonora content into the current room. */
    fun openTrack(track: Track) {
        val now = rooms.serverNow()
        rooms.publishQueueAndState(
            RoomQueue(rooms.queue.value.rev + 1, listOf(track), emptySet()),
            RoomPlayState(
                seq = (rooms.state.value?.seq ?: 0L) + 1,
                index = 0,
                track = track,
                isPlaying = true,
                positionMs = 0L,
                anchorTs = now,
                by = rooms.myId,
                byName = rooms.myName
            )
        )
    }

    fun localSnapshot(snapshot: VideoSnapshot) {
        if (SystemClock.elapsedRealtime() < ignoreUntil) return
        val state = rooms.state.value ?: return
        val current = state.track ?: return
        if (!matches(current, snapshot)) return
        val playing = snapshot.state == 1
        val now = rooms.serverNow()
        if (playing != state.isPlaying || abs(state.expectedPositionMs(now) - snapshot.positionMs) > 1200L) {
            ignoreUntil = SystemClock.elapsedRealtime() + 1300L
            rooms.publishState(state.copy(seq = state.seq + 1, isPlaying = playing, positionMs = snapshot.positionMs, anchorTs = now, by = rooms.myId, byName = rooms.myName))
        }
    }

    fun userSeek(positionMs: Long) {
        val state = rooms.state.value ?: return
        ignoreUntil = SystemClock.elapsedRealtime() + 1300L
        rooms.publishState(state.copy(seq = state.seq + 1, positionMs = positionMs.coerceAtLeast(0L), anchorTs = rooms.serverNow(), by = rooms.myId, byName = rooms.myName))
    }

    fun applyRemote(snapshot: RoomPlayState, player: EmbeddedVideoController, local: VideoSnapshot?) {
        val expected = snapshot.expectedPositionMs(rooms.serverNow()).coerceAtLeast(0L)
        val same = local != null && local.id == snapshot.track?.externalId
        ignoreUntil = SystemClock.elapsedRealtime() + 1400L
        if (!same) {
            player.seek(snapshot.positionMs)
            if (snapshot.isPlaying) player.play() else player.pause()
            return
        }
        val localPos = local?.positionMs ?: 0L
        if (abs(localPos - expected) > 800L) player.seek(expected)
        if (snapshot.isPlaying && local?.state != 1) player.play()
        if (!snapshot.isPlaying && local?.state == 1) player.pause()
    }

    private fun syncTextFromState() {
        val state = rooms.state.value ?: return
        val expected = state.expectedPositionMs(rooms.serverNow())
        _syncText.value = if (state.isPlaying) "ซิงค์อัตโนมัติ ✓  ${expected / 1000}s" else "หยุดพร้อมกัน ✓"
    }

    private fun matches(track: Track, snapshot: VideoSnapshot): Boolean =
        track.externalId == snapshot.id && track.source.equals(snapshot.provider.name.lowercase(), true)
}
