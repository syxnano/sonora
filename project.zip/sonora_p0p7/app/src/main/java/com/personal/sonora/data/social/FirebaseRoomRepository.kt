package com.personal.sonora.data.social

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.ServerValue
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Social room over Firebase Realtime Database (anonymous auth, no login UI).
 *
 * DB layout:
 *   rooms/{code}/meta
 *   rooms/{code}/presence/{uid}
 *   rooms/{code}/messages/{id}          chat
 *   rooms/{code}/state                  shared playback timeline  (see [RoomPlayState])
 *   rooms/{code}/queue                  shared playlist           (see [RoomQueue])
 *   rooms/{code}/request                pending "change song" request (see [RoomRequest])
 */
@Singleton
class FirebaseRoomRepository @Inject constructor() {

    data class ChatMsg(
        val id: String = "",
        val sender: String = "",
        val text: String = "",
        val ts: Long = 0L,
        val tts: Boolean = true,
        val uid: String = ""
    )

    data class RoomUi(
        val code: String? = null,
        val isHost: Boolean = false,
        val connected: Boolean = false,
        val status: String = "idle",
        val error: String? = null,
        val peerCount: Int = 0
    )

    companion object {
        /** How long a song-change request stays valid. */
        const val REQUEST_TTL_MS = 45_000L
    }

    private val _room = MutableStateFlow(RoomUi())
    val room: StateFlow<RoomUi> = _room.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages.asStateFlow()

    private val _state = MutableStateFlow<RoomPlayState?>(null)
    val state: StateFlow<RoomPlayState?> = _state.asStateFlow()

    /** true once the first snapshot of rooms/{code}/state arrived (even if it was empty). */
    private val _stateLoaded = MutableStateFlow(false)
    val stateLoaded: StateFlow<Boolean> = _stateLoaded.asStateFlow()

    private val _queue = MutableStateFlow(RoomQueue())
    val queue: StateFlow<RoomQueue> = _queue.asStateFlow()

    private val _request = MutableStateFlow<RoomRequest?>(null)
    val request: StateFlow<RoomRequest?> = _request.asStateFlow()

    private val _offset = MutableStateFlow(0L)
    /** serverTime - localTime, from Firebase's .info/serverTimeOffset. */
    val offsetMs: StateFlow<Long> = _offset.asStateFlow()

    private var msgListener: ChildEventListener? = null
    private var presenceListener: ValueEventListener? = null
    private var stateListener: ValueEventListener? = null
    private var queueListener: ValueEventListener? = null
    private var requestListener: ValueEventListener? = null
    private var offsetListener: ValueEventListener? = null
    private var connListener: ValueEventListener? = null
    private var currentCode: String? = null
    private var myUid: String = "guest_${UUID.randomUUID().toString().take(8)}"
    private var displayName: String = "Guest"

    val myId: String get() = myUid
    val myName: String get() = displayName

    /** Best estimate of the shared (server) clock. Used for every timeline calculation. */
    fun serverNow(): Long = System.currentTimeMillis() + _offset.value

    private fun db(): FirebaseDatabase? = try {
        val url = com.personal.sonora.BuildConfig.FIREBASE_DB_URL
        if (url.isNotBlank()) FirebaseDatabase.getInstance(url) else FirebaseDatabase.getInstance()
    } catch (_: Exception) {
        null
    }

    private fun roomRef(): DatabaseReference? {
        val code = currentCode ?: return null
        return db()?.getReference("rooms")?.child(code)
    }

    private val timeoutMsg =
        "เชื่อมต่อ Firebase Realtime Database ไม่ได้ (หมดเวลา) ตรวจว่าเน็ตใช้ได้ และสร้าง Realtime Database ใน Firebase Console แล้ว"

    private fun auth(): FirebaseAuth? = try {
        FirebaseAuth.getInstance()
    } catch (_: Exception) {
        null
    }

    /** Ensure anonymous session (no UI login). Best effort: rules allow access without auth. */
    suspend fun ensureAuth(): Boolean {
        val a = auth() ?: return false
        return try {
            if (a.currentUser == null) {
                withTimeout(6_000) { a.signInAnonymously().await() }
            }
            myUid = a.currentUser?.uid ?: myUid
            true
        } catch (e: TimeoutCancellationException) {
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }
    }

    suspend fun createRoom(name: String): String? {
        if (db() == null) {
            _room.value = RoomUi(error = "ใส่ google-services.json ก่อน (Firebase)")
            return null
        }
        displayName = name
        ensureAuth()
        val code = Random.nextInt(100000, 999999).toString()
        val ref = db()!!.getReference("rooms").child(code)
        val meta = mapOf(
            "createdAt" to ServerValue.TIMESTAMP,
            "host" to myUid,
            "hostName" to name
        )
        return try {
            withTimeout(12_000) { ref.child("meta").setValue(meta).await() }
            joinInternal(code, name, isHost = true)
            code
        } catch (e: TimeoutCancellationException) {
            _room.value = RoomUi(error = timeoutMsg)
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _room.value = RoomUi(error = e.message)
            null
        }
    }

    suspend fun joinRoom(code: String, name: String): Boolean {
        if (code.length != 6 || !code.all { it.isDigit() }) {
            _room.value = RoomUi(error = "รหัสต้องเป็นตัวเลข 6 หลัก")
            return false
        }
        if (db() == null) {
            _room.value = RoomUi(error = "ใส่ google-services.json ก่อน (Firebase)")
            return false
        }
        displayName = name
        ensureAuth()
        return try {
            val snap = withTimeout(12_000) {
                db()!!.getReference("rooms").child(code).child("meta").get().await()
            }
            if (!snap.exists()) {
                _room.value = RoomUi(error = "ไม่พบห้องนี้")
                return false
            }
            joinInternal(code, name, isHost = snap.child("host").getValue(String::class.java) == myUid)
            true
        } catch (e: TimeoutCancellationException) {
            _room.value = RoomUi(error = timeoutMsg)
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _room.value = RoomUi(error = e.message)
            false
        }
    }

    private fun joinInternal(code: String, name: String, isHost: Boolean) {
        leaveListenersOnly()
        currentCode = code
        displayName = name
        _messages.value = emptyList()
        _state.value = null
        _stateLoaded.value = false
        _queue.value = RoomQueue()
        _request.value = null

        val database = db()!!
        val rRef = database.getReference("rooms").child(code)

        // Server clock offset: all devices anchor the timeline to the same clock.
        offsetListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _offset.value = (snapshot.value as? Number)?.toLong() ?: 0L
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        database.getReference(".info/serverTimeOffset").addValueEventListener(offsetListener!!)

        // presence (re-asserted after every reconnect, otherwise a flaky network leaves us "offline")
        val presenceRef = rRef.child("presence").child(myUid)
        presenceRef.onDisconnect().removeValue()
        presenceRef.setValue(mapOf("name" to name, "at" to ServerValue.TIMESTAMP))
        connListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.value == true) {
                    val p = roomRef()?.child("presence")?.child(myUid) ?: return
                    p.onDisconnect().removeValue()
                    p.setValue(mapOf("name" to displayName, "at" to ServerValue.TIMESTAMP))
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        database.getReference(".info/connected").addValueEventListener(connListener!!)

        presenceListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _room.value = _room.value.copy(peerCount = snapshot.childrenCount.toInt())
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        rRef.child("presence").addValueEventListener(presenceListener!!)

        // chat — ordered by timestamp (random ids would otherwise scramble the order)
        msgListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val m = snapshot.getValue(ChatMsg::class.java)?.copy(id = snapshot.key ?: "")
                    ?: return
                _messages.value = (_messages.value + m).takeLast(100)
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                _room.value = _room.value.copy(error = error.message)
            }
        }
        rRef.child("messages").orderByChild("ts").limitToLast(50).addChildEventListener(msgListener!!)

        // shared timeline
        stateListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _state.value = RoomPlayState.fromAny(snapshot.value)
                _stateLoaded.value = true
            }
            override fun onCancelled(error: DatabaseError) {
                _room.value = _room.value.copy(error = error.message)
            }
        }
        rRef.child("state").addValueEventListener(stateListener!!)

        // shared playlist
        queueListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _queue.value = RoomQueue.fromAny(snapshot.value)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        rRef.child("queue").addValueEventListener(queueListener!!)

        // change-song requests
        requestListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _request.value = RoomRequest.fromAny(snapshot.value)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        rRef.child("request").addValueEventListener(requestListener!!)

        _room.value = RoomUi(
            code = code,
            isHost = isHost,
            connected = true,
            status = "connected",
            peerCount = 1
        )
    }

    /* ------------------------------ chat ------------------------------ */

    fun sendChat(sender: String, text: String) {
        val ref = roomRef() ?: return
        val clean = text.trim()
        if (clean.isEmpty()) return
        val id = UUID.randomUUID().toString().take(12)
        val msg = ChatMsg(
            id = id,
            sender = sender,
            text = clean,
            ts = serverNow(),
            tts = true,
            uid = myUid
        )
        ref.child("messages").child(id).setValue(msg)
    }

    /** Used by notification inline-reply when the app process was recreated and the room is not attached. */
    suspend fun sendChatToRoom(code: String, sender: String, text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty() || !code.matches(Regex("\\d{6}"))) return false
        val database = db() ?: return false
        if (!ensureAuth()) return false
        val meta = runCatching { withTimeout(8_000) { database.getReference("rooms").child(code).child("meta").get().await() } }.getOrNull()
            ?: return false
        if (!meta.exists()) return false
        val id = UUID.randomUUID().toString().take(12)
        val msg = mapOf(
            "id" to id,
            "sender" to sender.ifBlank { "Guest" }.take(40),
            "text" to clean.take(500),
            "ts" to ServerValue.TIMESTAMP,
            "tts" to true,
            "uid" to myUid
        )
        return runCatching {
            withTimeout(8_000) { database.getReference("rooms").child(code).child("messages").child(id).setValue(msg).await() }
            true
        }.getOrDefault(false)
    }

    /* ------------------------- timeline / queue ------------------------- */

    fun publishState(s: RoomPlayState) {
        roomRef()?.child("state")?.setValue(s.toMap())
    }

    fun publishQueue(q: RoomQueue) {
        roomRef()?.child("queue")?.setValue(q.toMap())
    }

    /** One atomic write: queue + state can never be seen out of step. */
    fun publishQueueAndState(q: RoomQueue, s: RoomPlayState) {
        val updates: Map<String, Any?> = mapOf("queue" to q.toMap(), "state" to s.toMap())
        roomRef()?.updateChildren(updates)
    }

    /**
     * Append auto-continue tracks, but only if nobody else changed the queue meanwhile
     * (both phones notice "playlist is ending" at the same time; only the first write wins).
     */
    fun appendQueueIfUnchanged(expectedRev: Long, extra: List<com.personal.sonora.data.catalog.Track>, onDone: (Boolean) -> Unit) {
        val ref = roomRef()?.child("queue")
        if (ref == null) {
            onDone(false)
            return
        }
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                if (currentData.value == null) return Transaction.success(currentData) // retry with real data
                val cur = RoomQueue.fromAny(currentData.value)
                if (cur.rev != expectedRev) return Transaction.abort()
                val have = cur.items.map { it.id }.toHashSet()
                val add = extra.filter { have.add(it.id) }
                if (add.isEmpty()) return Transaction.abort()
                val next = RoomQueue(cur.rev + 1, cur.items + add, cur.autoIds + add.map { it.id })
                currentData.value = next.toMap()
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                val ok = committed && error == null &&
                    RoomQueue.fromAny(snapshot?.value).rev > expectedRev
                onDone(ok)
            }
        })
    }

    /* ----------------------------- requests ----------------------------- */

    /** false = somebody else already has a fresh pending request. */
    fun createRequest(req: RoomRequest, onDone: (Boolean) -> Unit) {
        val ref = roomRef()?.child("request")
        if (ref == null) {
            onDone(false)
            return
        }
        val me = myUid
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val cur = currentData.value as? Map<*, *>
                if (cur != null) {
                    val pending = cur.str("status") == RoomRequest.STATUS_PENDING
                    val fresh = serverNow() - (cur.lng("ts") ?: 0L) < REQUEST_TTL_MS
                    if (pending && fresh && cur.str("by") != me) return Transaction.abort()
                }
                currentData.value = req.toMap()
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                onDone(committed && error == null)
            }
        })
    }

    /** pending -> rejected / expired. No-op if the request already moved on. */
    fun setRequestStatus(id: String, status: String) {
        val ref = roomRef()?.child("request") ?: return
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val cur = currentData.value as? Map<*, *> ?: return Transaction.abort()
                if (cur.str("id") != id) return Transaction.abort()
                if (cur.str("status") != RoomRequest.STATUS_PENDING) return Transaction.abort()
                currentData.child("status").value = status
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
        })
    }

    /** Approve: mark the request accepted AND switch the room to the requested song, atomically. */
    fun acceptRequest(q: RoomQueue, s: RoomPlayState) {
        val updates: Map<String, Any?> = mapOf(
            "request/status" to RoomRequest.STATUS_ACCEPTED,
            "queue" to q.toMap(),
            "state" to s.toMap()
        )
        roomRef()?.updateChildren(updates)
    }

    fun clearRequest(id: String) {
        val ref = roomRef()?.child("request") ?: return
        ref.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val cur = currentData.value as? Map<*, *> ?: return Transaction.abort()
                if (cur.str("id") != id) return Transaction.abort()
                currentData.value = null
                return Transaction.success(currentData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
        })
    }

    /* ------------------------------ leave ------------------------------ */

    fun leave() {
        val ref = roomRef()
        if (ref != null) {
            try {
                ref.child("presence").child(myUid).removeValue()
                val mine = _request.value
                if (mine != null && mine.by == myUid) clearRequest(mine.id)
            } catch (_: Exception) {
            }
        }
        leaveListenersOnly()
        currentCode = null
        _room.value = RoomUi()
        _messages.value = emptyList()
        _state.value = null
        _stateLoaded.value = false
        _queue.value = RoomQueue()
        _request.value = null
    }

    private fun leaveListenersOnly() {
        val code = currentCode ?: return
        val database = db()
        val rRef = try { database?.getReference("rooms")?.child(code) } catch (_: Exception) { null }
        msgListener?.let { rRef?.child("messages")?.removeEventListener(it) }
        presenceListener?.let { rRef?.child("presence")?.removeEventListener(it) }
        stateListener?.let { rRef?.child("state")?.removeEventListener(it) }
        queueListener?.let { rRef?.child("queue")?.removeEventListener(it) }
        requestListener?.let { rRef?.child("request")?.removeEventListener(it) }
        offsetListener?.let { database?.getReference(".info/serverTimeOffset")?.removeEventListener(it) }
        connListener?.let { database?.getReference(".info/connected")?.removeEventListener(it) }
        msgListener = null
        presenceListener = null
        stateListener = null
        queueListener = null
        requestListener = null
        offsetListener = null
        connListener = null
    }
}
