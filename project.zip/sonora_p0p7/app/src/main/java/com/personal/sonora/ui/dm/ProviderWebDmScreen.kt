package com.personal.sonora.ui.dm

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import com.personal.sonora.dm.ConversationTarget

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ProviderWebDmScreen(target: ConversationTarget, onBack: () -> Unit) {
    val context = LocalContext.current
    var progress by remember { mutableFloatStateOf(0f) }
    var loading by remember { mutableStateOf(true) }
    var blocked by remember { mutableStateOf(false) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler { if (webViewRef?.canGoBack() == true) webViewRef?.goBack() else onBack() }

    Scaffold(topBar = {
        Column {
            TopAppBar(
                title = { Text(target.displayName) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "ย้อนกลับ") } },
                actions = { IconButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target.fallbackUrl))) }) { Icon(Icons.Default.OpenInNew, "เปิดภายนอก") } }
            )
            if (loading) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }
    }) { padding ->
        Box(Modifier.fillMaxSize()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) { progress = newProgress / 100f; loading = newProgress < 100 }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) { loading = true; blocked = false }
                            override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) { if (request?.isForMainFrame == true) blocked = true; loading = false }
                        }
                        loadUrl(target.conversationUrl)
                        webViewRef = this
                    }
                },
                update = { webViewRef = it }
            )
            if (blocked) Text("ผู้ให้บริการไม่อนุญาตให้เปิดหน้านี้ในตัวแอป — กด ↗ เพื่อเปิดด้วยเบราว์เซอร์")
        }
    }
}
