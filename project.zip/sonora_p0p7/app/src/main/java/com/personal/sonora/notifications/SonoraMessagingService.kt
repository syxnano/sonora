package com.personal.sonora.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.personal.sonora.MainActivity
import com.personal.sonora.R

class SonoraMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "Sonora"
        val body = message.notification?.body ?: message.data["body"] ?: "มีการแจ้งเตือนใหม่"
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            message.data["chatUid"]?.let { putExtra("chatUid", it) }
            message.data["roomCode"]?.let { putExtra("roomCode", it) }
        }
        val pending = PendingIntent.getActivity(this, title.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("sonora", "Sonora", NotificationManager.IMPORTANCE_HIGH))
        manager.notify(System.currentTimeMillis().toInt(), NotificationCompat.Builder(this, "sonora")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build())
    }
}
