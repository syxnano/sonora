package com.personal.sonora.provider

enum class ProviderFailureType {
    EXPIRED_TOKEN, REVOKED_PERMISSION, RATE_LIMIT,
    TEMPORARY_OUTAGE, UNSUPPORTED_CAPABILITY, NETWORK
}

data class ProviderFailure(
    val type: ProviderFailureType,
    val message: String
)
