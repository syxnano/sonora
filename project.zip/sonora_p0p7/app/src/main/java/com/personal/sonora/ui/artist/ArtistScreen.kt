package com.personal.sonora.ui.artist

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.ui.theme.SpotifySecondary

/**
 * Spotify-style artist page (basic).
 * Platforms / follower counts are shown when available from catalog sources.
 */
@Composable
fun ArtistScreen(
    artistName: String,
    imageUrl: String? = null,
    platforms: List<String> = listOf("YouTube"),
    followerText: String? = null,
    topTracks: List<Track> = emptyList(),
    onTrackClick: (Track) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            if (!imageUrl.isNullOrBlank()) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = artistName,
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(12.dp))
            }
            Text(
                artistName,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            if (!followerText.isNullOrBlank()) {
                Text(followerText, color = SpotifySecondary, fontSize = 13.sp)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                platforms.joinToString(" · "),
                color = SpotifySecondary,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(20.dp))
        Text("Popular", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(topTracks) { track ->
                Text(
                    "${track.title} — ${track.artist}",
                    color = Color.White,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
            }
        }
    }
}
