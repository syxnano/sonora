package com.personal.sonora.data.socialnet

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class SocialRepository {
    private val db = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()

    suspend fun ensureProfile(displayName: String = auth.currentUser?.displayName ?: "Sonora User") {
        val uid = auth.currentUser?.uid ?: return
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (!snap.exists()) ref.set(mapOf(
            "uid" to uid, "displayName" to displayName, "email" to (auth.currentUser?.email ?: ""),
            "photoUrl" to (auth.currentUser?.photoUrl?.toString() ?: ""), "createdAt" to FieldValue.serverTimestamp()
        )).await()
    }

    suspend fun sendFriendRequest(toUid: String) {
        val from = auth.currentUser?.uid ?: error("Not signed in")
        db.collection("friendRequests").add(mapOf("from" to from, "to" to toUid, "status" to "pending", "createdAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun acceptFriendRequest(requestId: String, fromUid: String) {
        val me = auth.currentUser?.uid ?: error("Not signed in")
        db.collection("friends").document("$me:$fromUid").set(mapOf("a" to me, "b" to fromUid, "createdAt" to FieldValue.serverTimestamp())).await()
        db.collection("friends").document("$fromUid:$me").set(mapOf("a" to fromUid, "b" to me, "createdAt" to FieldValue.serverTimestamp())).await()
        db.collection("friendRequests").document(requestId).update("status", "accepted").await()
    }

    suspend fun sendDirectMessage(toUid: String, text: String) {
        val from = auth.currentUser?.uid ?: error("Not signed in")
        require(text.isNotBlank())
        val chatId = listOf(from, toUid).sorted().joinToString("_")
        db.collection("dm").document(chatId).collection("messages").add(mapOf(
            "from" to from, "to" to toUid, "text" to text.trim(), "createdAt" to FieldValue.serverTimestamp()
        )).await()
    }
}
