package com.personal.sonora.data.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import android.content.Context

class AuthRepository(private val context: Context) {
    private val auth = FirebaseAuth.getInstance()
    val current get() = auth.currentUser

    fun googleClient(): GoogleSignInClient {
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(com.personal.sonora.R.string.default_web_client_id))
            .requestEmail().build()
        return com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, options)
    }

    fun signInWithGoogle(account: GoogleSignInAccount, onResult: (Result<Unit>) -> Unit) {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential).addOnCompleteListener { t ->
            if (t.isSuccessful) onResult(Result.success(Unit)) else onResult(Result.failure(t.exception ?: Exception("Google sign-in failed")))
        }
    }

    fun signUp(email: String, password: String, onResult: (Result<Unit>) -> Unit) {
        auth.createUserWithEmailAndPassword(email.trim(), password).addOnCompleteListener { t ->
            if (t.isSuccessful) onResult(Result.success(Unit)) else onResult(Result.failure(t.exception ?: Exception("Sign-up failed")))
        }
    }

    fun signIn(email: String, password: String, onResult: (Result<Unit>) -> Unit) {
        auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { t ->
            if (t.isSuccessful) onResult(Result.success(Unit)) else onResult(Result.failure(t.exception ?: Exception("Sign-in failed")))
        }
    }

    fun signOut() = auth.signOut()
}
