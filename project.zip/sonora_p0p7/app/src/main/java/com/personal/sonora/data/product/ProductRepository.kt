package com.personal.sonora.data.product

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.personal.sonora.data.catalog.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

private val Context.productStore: DataStore<Preferences> by preferencesDataStore("sonora_product")

@Singleton
class ProductRepository @Inject constructor(private val context: Context) {
    private val ds = context.productStore
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private object Keys {
        val CARDS = stringPreferencesKey("music_cards")
        val TASTE = stringPreferencesKey("taste_memory")
        val MORNING = stringPreferencesKey("morning_song")
    }

    val cards: Flow<List<MusicCard>> = ds.data.map { p ->
        runCatching { json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]") }
            .getOrDefault(emptyList())
    }
    val taste: Flow<TasteMemory> = ds.data.map { p ->
        runCatching { json.decodeFromString(TasteMemory.serializer(), p[Keys.TASTE] ?: "{}") }
            .getOrDefault(TasteMemory())
    }
    val morning: Flow<MorningSong> = ds.data.map { p ->
        runCatching { json.decodeFromString(MorningSong.serializer(), p[Keys.MORNING] ?: "{}") }
            .getOrDefault(MorningSong())
    }

    suspend fun createCard(track: Track, message: String, mood: String): MusicCard {
        val card = MusicCard(
            id = UUID.randomUUID().toString(),
            track = track,
            message = message.trim().take(500),
            mood = mood.trim().take(80)
        )
        ds.edit { p ->
            val old = runCatching {
                json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]")
            }.getOrDefault(emptyList())
            p[Keys.CARDS] = json.encodeToString(
                ListSerializer(MusicCard.serializer()),
                (listOf(card) + old).take(100)
            )
        }
        return card
    }


    suspend fun markCardPublished(localId: String, publicId: String) = ds.edit { p ->
        val old = runCatching {
            json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]")
        }.getOrDefault(emptyList())
        p[Keys.CARDS] = json.encodeToString(
            ListSerializer(MusicCard.serializer()),
            old.map { if (it.id == localId) it.copy(publicId = publicId) else it }
        )
    }

    suspend fun rateTrack(trackId: String, liked: Boolean) = ds.edit { p ->
        val old = runCatching {
            json.decodeFromString(TasteMemory.serializer(), p[Keys.TASTE] ?: "{}")
        }.getOrDefault(TasteMemory())
        val likedIds = old.likedTrackIds.toMutableList().apply {
            remove(trackId)
            if (liked) add(0, trackId)
        }.distinct().take(300)
        val dislikedIds = old.dislikedTrackIds.toMutableList().apply {
            remove(trackId)
            if (!liked) add(0, trackId)
        }.distinct().take(300)
        p[Keys.TASTE] = json.encodeToString(
            TasteMemory.serializer(),
            old.copy(likedTrackIds = likedIds, dislikedTrackIds = dislikedIds)
        )
    }

    suspend fun clearTaste() = ds.edit { it[Keys.TASTE] = json.encodeToString(TasteMemory.serializer(), TasteMemory()) }

    suspend fun deleteCard(id: String) = ds.edit { p ->
        val old = runCatching {
            json.decodeFromString(ListSerializer(MusicCard.serializer()), p[Keys.CARDS] ?: "[]")
        }.getOrDefault(emptyList())
        p[Keys.CARDS] = json.encodeToString(ListSerializer(MusicCard.serializer()), old.filterNot { it.id == id })
    }

    suspend fun saveTaste(taste: TasteMemory) = ds.edit {
        it[Keys.TASTE] = json.encodeToString(TasteMemory.serializer(), taste)
    }

    suspend fun saveMorning(morning: MorningSong) = ds.edit {
        it[Keys.MORNING] = json.encodeToString(MorningSong.serializer(), morning)
    }
}
