package com.personal.sonora.media

import com.personal.sonora.connectors.core.Platform

data class MediaItem(
    val id: String,
    val platform: Platform,
    val canonicalUrl: String,
    val title: String? = null,
    val creatorName: String? = null,
    val thumbnailUrl: String? = null,
    val embedUrl: String? = null
)
