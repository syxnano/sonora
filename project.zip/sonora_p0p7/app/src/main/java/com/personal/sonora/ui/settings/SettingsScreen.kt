package com.personal.sonora.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.personal.sonora.R
import com.personal.sonora.data.db.ResolvedStreamDao
import com.personal.sonora.data.db.SeenTrackDao
import com.personal.sonora.data.download.DownloadManager
import com.personal.sonora.data.download.DownloadQuality
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.data.settings.SettingsRepository
import com.personal.sonora.data.settings.StreamQuality
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val profileRepo: ProfileRepository,
    private val downloadManager: DownloadManager,
    private val resolvedStreamDao: ResolvedStreamDao,
    private val seenTrackDao: SeenTrackDao
) : ViewModel() {
    val wifiQuality = settings.wifiQuality
    val mobileQuality = settings.mobileQuality
    val discoverCount = settings.discoverCount
    val crossfade = settings.crossfadeSec
    val normalization = settings.normalization
    val downloadQuality = settings.downloadQuality
    val username = settings.username
    val avatarUri = settings.avatarUri
    val sleepTimerMin = settings.sleepTimerMin

    fun setWifi(q: StreamQuality) = viewModelScope.launch { settings.setWifiQuality(q) }
    fun setMobile(q: StreamQuality) = viewModelScope.launch { settings.setMobileQuality(q) }
    fun setDiscover(n: Int) = viewModelScope.launch { settings.setDiscoverCount(n) }
    fun setCrossfade(s: Float) = viewModelScope.launch { settings.setCrossfadeSec(s) }
    fun setNorm(b: Boolean) = viewModelScope.launch { settings.setNormalization(b) }
    fun setDownloadQuality(q: String) = viewModelScope.launch { settings.setDownloadQuality(q) }
    fun setUsername(n: String) = viewModelScope.launch { profileRepo.setUsername(n) }
    fun setAvatar(uri: String) = viewModelScope.launch { profileRepo.setAvatarUri(uri) }
    fun setSleepTimer(min: Int) = viewModelScope.launch { settings.setSleepTimerMin(min) }
    fun clearCache() = viewModelScope.launch { resolvedStreamDao.clearAll() }
    fun clearSeen() = viewModelScope.launch { seenTrackDao.clearAll() }
    fun exportSnapshot() = viewModelScope.launch { downloadManager.exportFullSnapshot() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val discover by viewModel.discoverCount.collectAsState(60)
    val crossfade by viewModel.crossfade.collectAsState(0f)
    val dlQuality by viewModel.downloadQuality.collectAsState("HIGH")
    val username by viewModel.username.collectAsState("Guest")
    val avatar by viewModel.avatarUri.collectAsState("")
    val sleepMin by viewModel.sleepTimerMin.collectAsState(0)
    var nameEdit by remember(username) { mutableStateOf(username) }

    Column(Modifier.fillMaxSize().background(SpotifyBlack)) {
        TopAppBar(
            title = { Text(stringResource(R.string.settings)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = SpotifyBlack,
                titleContentColor = Color.White,
                navigationIconContentColor = Color.White
            )
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // —— Guest Profile ——
            Text("Guest Profile", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (avatar.isNotBlank()) {
                    AsyncImage(
                        model = avatar,
                        contentDescription = null,
                        modifier = Modifier
                            .height(56.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Default.Person, null, tint = SpotifySecondary, modifier = Modifier.height(56.dp))
                }
                Spacer(Modifier.padding(8.dp))
                OutlinedTextField(
                    value = nameEdit,
                    onValueChange = { nameEdit = it },
                    label = { Text("Username") },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1E1E1E),
                        unfocusedContainerColor = Color(0xFF1E1E1E)
                    )
                )
            }
            TextButton(onClick = { viewModel.setUsername(nameEdit) }) {
                Text("Save profile", color = SpotifyGreen)
            }

            Spacer(Modifier.height(20.dp))
            Text("Download quality", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            DownloadQuality.entries.forEach { q ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.setDownloadQuality(q.key) }
                        .padding(vertical = 8.dp)
                ) {
                    Text(
                        q.label,
                        color = if (dlQuality == q.key) SpotifyGreen else Color.White
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.sleep_timer), color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(
                if (sleepMin == 0) "Off" else "$sleepMin min",
                color = SpotifySecondary
            )
            Slider(
                value = sleepMin.toFloat(),
                onValueChange = { viewModel.setSleepTimer(it.toInt()) },
                valueRange = 0f..120f,
                steps = 23
            )

            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.discover_count), color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text("$discover", color = SpotifySecondary)
            Slider(
                value = discover.toFloat(),
                onValueChange = { viewModel.setDiscover(it.toInt()) },
                valueRange = 50f..100f
            )

            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.crossfade), color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text("${crossfade.toInt()} s", color = SpotifySecondary)
            Slider(
                value = crossfade,
                onValueChange = { viewModel.setCrossfade(it) },
                valueRange = 0f..12f
            )

            Spacer(Modifier.height(16.dp))
            TextButton(onClick = { viewModel.clearCache() }) {
                Text(stringResource(R.string.clear_cache), color = SpotifyGreen)
            }
            TextButton(onClick = { viewModel.clearSeen() }) {
                Text(stringResource(R.string.clear_seen), color = SpotifyGreen)
            }
            TextButton(onClick = { viewModel.exportSnapshot() }) {
                Text("Export playlist backup", color = SpotifyGreen)
            }

            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.legal_note), color = SpotifySecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
