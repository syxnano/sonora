package com.personal.sonora.video

import android.annotation.SuppressLint
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlin.math.abs

private const val ORIGIN = "https://sonora-9d7f4.web.app"

private fun youtubeHtml(id: String): String = """
<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>html,body,#player{margin:0;width:100%;height:100%;background:#000;overflow:hidden}</style></head>
<body><div id=player></div><script src='https://www.youtube.com/iframe_api'></script><script>
let p=null,ready=false,current='';
function report(){try{if(!p||!ready)return; SonoraAndroid.report(current||'',Number(p.getPlayerState()||-1),Number(p.getCurrentTime()||0),Number(p.getDuration()||0));}catch(e){}}
function onYouTubeIframeAPIReady(){p=new YT.Player('player',{width:'100%',height:'100%',videoId:'$id',playerVars:{playsinline:1,rel:0,origin:'$ORIGIN'},events:{onReady:function(){ready=true;current='$id';report()},onStateChange:function(){report()}}});setInterval(report,700)}
function play(){try{p.playVideo()}catch(e){}} function pause(){try{p.pauseVideo()}catch(e){}} function seek(s){try{p.seekTo(Number(s||0),true)}catch(e){}}
</script></body></html>
""".trimIndent()

private fun tikTokHtml(id: String): String = """
<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}iframe{border:0;width:100%;height:100%}</style></head>
<body><iframe id='tt' allow='fullscreen' src='https://www.tiktok.com/player/v1/$id?controls=1&progress_bar=1&play_button=1&volume_control=1&fullscreen_button=1&timestamp=1&music_info=1&description=1&autoplay=0'></iframe>
<script>
const f=document.getElementById('tt');let current=0,duration=0,state=-1;
function send(type,value){try{f.contentWindow.postMessage({'type':type,'value':value,'x-tiktok-player':true},'*')}catch(e){}}
function report(){try{SonoraAndroid.report('$id',state,current,duration)}catch(e){}}
window.addEventListener('message',e=>{const d=e.data||{};if(!d['x-tiktok-player'])return;if(d.type==='onStateChange')state=Number(d.value);if(d.type==='onCurrentTime'){current=Number(d.value?.currentTime||0);duration=Number(d.value?.duration||0)}report()});
setInterval(report,700);
function play(){send('play')} function pause(){send('pause')} function seek(s){send('seekTo',Number(s||0))}
</script></body></html>
""".trimIndent()

class EmbeddedVideoController {
    var webView: WebView? = null
    fun play() = webView?.evaluateJavascript("play();", null)
    fun pause() = webView?.evaluateJavascript("pause();", null)
    fun seek(positionMs: Long) = webView?.evaluateJavascript("seek(${positionMs.coerceAtLeast(0L) / 1000.0});", null)
}

private class PlayerBridge(private val onSnapshot: (VideoSnapshot) -> Unit, private val provider: VideoProvider) {
    @JavascriptInterface fun report(id: String, state: Int, positionSeconds: Double, durationSeconds: Double) {
        onSnapshot(VideoSnapshot(provider, id, state, (positionSeconds * 1000).toLong().coerceAtLeast(0), (durationSeconds * 1000).toLong().coerceAtLeast(0), SystemClock.elapsedRealtime()))
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmbeddedVideoPlayer(
    item: VideoItem,
    modifier: Modifier = Modifier,
    onSnapshot: (VideoSnapshot) -> Unit = {},
    onUserAction: (VideoSnapshot) -> Unit = {},
    manager: VideoPlaybackManager? = null,
    controller: EmbeddedVideoController? = null
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var webView by remember(item.provider, item.id) { mutableStateOf<WebView?>(null) }
    val latestSnapshotCallback = rememberUpdatedState(onSnapshot)
    val latestUserAction = rememberUpdatedState(onUserAction)
    val bridge = remember(item.provider, item.id) {
        PlayerBridge({ snap ->
            latestSnapshotCallback.value(snap)
            if (snap.state == 1 || snap.state == 2 || snap.state == 0) latestUserAction.value(snap)
        }, item.provider)
    }

    DisposableEffect(lifecycleOwner, webView) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) webView?.evaluateJavascript("pause();", null)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer); webView?.let { manager?.detachWebView(it); if (controller?.webView === it) controller.webView = null } }
    }

    AndroidView(
        modifier = modifier.background(Color.Black),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.setSupportMultipleWindows(false)
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                setBackgroundColor(android.graphics.Color.BLACK)
                addJavascriptInterface(bridge, "SonoraAndroid")
                val html = if (item.provider == VideoProvider.YOUTUBE) youtubeHtml(item.id) else tikTokHtml(item.id)
                loadDataWithBaseURL(ORIGIN, html, "text/html", "utf-8", null)
                webView = this
                manager?.attachWebView(this)
                controller?.webView = this
            }
        },
        update = { webView = it }
    )
}

fun controlEmbeddedVideo(webView: WebView?, action: String, positionMs: Long = 0L) {
    val seconds = positionMs.coerceAtLeast(0L) / 1000.0
    webView?.evaluateJavascript(
        when (action) {
            "play" -> "play();"
            "pause" -> "pause();"
            "seek" -> "seek($seconds);"
            else -> ""
        }, null
    )
}
