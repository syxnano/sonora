package com.personal.sonora.ui.video

import com.personal.sonora.video.*

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.net.URLEncoder
import javax.inject.Inject

@HiltViewModel
class VideoSearchViewModel @Inject constructor(private val youtube: YouTubeSearchRepository) : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query
    private val _results = MutableStateFlow<List<VideoItem>>(emptyList())
    val results: StateFlow<List<VideoItem>> = _results
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading
    private var job: Job? = null
    fun setQuery(v: String) { _query.value = v }
    fun search() {
        val q = _query.value.trim()
        if (q.isBlank()) return
        job?.cancel()
        job = viewModelScope.launch {
            _loading.value = true
            _results.value = youtube.search(q)
            _loading.value = false
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun TikTokSearchWeb(
    query: String,
    onVideo: (String) -> Unit
) {
    val encoded = remember(query) { URLEncoder.encode(query, "UTF-8") }
    androidx.compose.runtime.key(encoded) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    webChromeClient = WebChromeClient()
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun openVideo(id: String) { onVideo(id) }
                    }, "SonoraTikTok")
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                            val id = Regex("/video/(\\d+)").find(url)?.groupValues?.getOrNull(1)
                            if (id != null) { onVideo(id); return true }
                            return false
                        }
                        override fun onPageFinished(view: WebView, url: String) {
                            view.evaluateJavascript("""
                                (function(){
                                  if(window.__sonoraHook)return;
                                  window.__sonoraHook=1;
                                  setInterval(function(){
                                    document.querySelectorAll('a[href*="/video/"]').forEach(function(a){
                                      if(a.dataset.sonoraHook)return;
                                      a.dataset.sonoraHook=1;
                                      a.addEventListener('click',function(){
                                        var m=(a.href||'').match(/\\/video\\/(\\d+)/);
                                        if(m&&window.SonoraTikTok)SonoraTikTok.openVideo(m[1]);
                                      });
                                    });
                                  },700);
                                })();
                            """.trimIndent(), null)
                        }
                    }
                    loadUrl("https://www.tiktok.com/search?q=$encoded")
                }
            },
            update = { }
        )
    }
}

@Composable
fun VideoSearchScreen(manager: VideoPlaybackManager, initialProvider: VideoProvider = VideoProvider.YOUTUBE, initialQuery: String = "", roomVm: RoomSessionViewModel, vm: VideoSearchViewModel = hiltViewModel()) {
    val q by vm.query.collectAsState()
    val results by vm.results.collectAsState()
    val loading by vm.loading.collectAsState()
    var provider by remember(initialProvider) { mutableStateOf(initialProvider) }
    LaunchedEffect(initialQuery) { if (initialQuery.isNotBlank()) { vm.setQuery(initialQuery); if (provider == VideoProvider.YOUTUBE) vm.search() } }

    Column(Modifier.fillMaxSize().background(Color(8,8,8)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = provider == VideoProvider.YOUTUBE, onClick = { provider = VideoProvider.YOUTUBE }, label = { Text("YouTube") })
            FilterChip(selected = provider == VideoProvider.TIKTOK, onClick = { provider = VideoProvider.TIKTOK }, label = { Text("TikTok") })
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = q, onValueChange = vm::setQuery, modifier = Modifier.weight(1f), singleLine = true, label = { Text("ค้นหา ${provider.shortName()}") })
            Button(onClick = { vm.search() }, enabled = q.isNotBlank() && provider == VideoProvider.YOUTUBE) { Text("ค้น") }
        }
        if (provider == VideoProvider.YOUTUBE) {
            if (loading) Text("กำลังค้นหา…", color = Color.LightGray, modifier = Modifier.padding(12.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(results, key = { it.id }) { item ->
                    Column(Modifier.fillMaxWidth().clickable { roomVm.openVideo(item) { manager.play(item) } }.padding(vertical = 12.dp)) {
                        Text(item.title, color = Color.White, maxLines = 2)
                        Text("${item.creator} • ${item.durationMs / 1000}s", color = Color.Gray)
                    }
                }
            }
        } else {
            if (q.isBlank()) Text("ค้นหา TikTok ในหน้าต่างนี้ แล้วแตะวิดีโอเพื่อเปิดใน Sonora", color = Color.Gray, modifier = Modifier.padding(12.dp))
            else TikTokSearchWeb(query = q, onVideo = { id ->
                val item = VideoItem(VideoProvider.TIKTOK, id, "TikTok", url = "https://www.tiktok.com/@_/video/$id")
                roomVm.openVideo(item) { manager.play(item) }
            })
        }
    }
}
