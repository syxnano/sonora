package com.personal.sonora.morning

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.personal.sonora.data.product.MorningSong
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MorningSongScheduler @Inject constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("sonora_morning", Context.MODE_PRIVATE)

    fun schedule(value: MorningSong) {
        schedule(
            hour = value.hour,
            minute = value.minute,
            message = value.message,
            cardId = value.cardId,
            title = value.title,
            artist = value.artist
        )
    }

    fun schedule(
        hour: Int,
        minute: Int,
        message: String = prefs.getString("message", "เพลงเช้าของคุณวันนี้").orEmpty(),
        cardId: String? = prefs.getString("cardId", null),
        title: String = prefs.getString("title", "").orEmpty(),
        artist: String = prefs.getString("artist", "").orEmpty()
    ) {
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        val h = hour.coerceIn(0, 23)
        val m = minute.coerceIn(0, 59)
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, MorningSongReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        prefs.edit()
            .putBoolean("enabled", true)
            .putInt("hour", h)
            .putInt("minute", m)
            .putString("message", message.trim().take(120).ifBlank { "เพลงเช้าของคุณวันนี้" })
            .putString("cardId", cardId?.take(64))
            .putString("title", title.take(300))
            .putString("artist", artist.take(200))
            .apply()

        // Exact alarms require an extra special permission on recent Android versions. Morning Song
        // is a notification ritual rather than an alarm clock, so a small OS-controlled delay is OK
        // and avoids asking for that permission.
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
    }

    fun restoreIfEnabled() {
        if (!prefs.getBoolean("enabled", false)) return
        schedule(
            prefs.getInt("hour", 7),
            prefs.getInt("minute", 0),
            prefs.getString("message", "เพลงเช้าของคุณวันนี้").orEmpty(),
            prefs.getString("cardId", null),
            prefs.getString("title", "").orEmpty(),
            prefs.getString("artist", "").orEmpty()
        )
    }

    fun cancel() {
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, MorningSongReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pi)
        prefs.edit().putBoolean("enabled", false).apply()
    }

    companion object { private const val REQUEST_CODE = 7001 }
}
