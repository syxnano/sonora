package com.personal.sonora.connectors.core

enum class CapabilityState {
    SUPPORTED, NEEDS_PERMISSION, NEEDS_REVIEW, UNSUPPORTED, DISCONNECTED
}

data class CapabilityStatus(
    val capability: Capability,
    val state: CapabilityState,
    val reason: String? = null
)
