package com.personal.sonora.data.catalog

interface MusicCatalog {
    suspend fun search(query: String, type: SearchType, limit: Int = 20): SearchResult
    suspend fun trending(limit: Int = 50): List<Track>
    suspend fun tracksByTag(tag: String, page: Int = 1, limit: Int = 30): List<Track>
    suspend fun similarTracks(seed: Track, limit: Int = 20): List<Track>
    suspend fun artistTopTracks(artist: String, limit: Int = 20): List<Track>
}
