package com.personal.sonora.ui.downloads

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.db.DownloadEntity
import com.personal.sonora.data.download.DownloadManager
import com.personal.sonora.data.download.DownloadProgress
import com.personal.sonora.data.download.DownloadStatus
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloadManager: DownloadManager
) : ViewModel() {
    val queue = downloadManager.queue
    val current = downloadManager.currentProgress
    val offlineCount = downloadManager.offlineIds

    fun pause(id: String) = viewModelScope.launch { downloadManager.pause(id) }
    fun resume(id: String) = viewModelScope.launch { downloadManager.resume(id) }
    fun cancel(id: String) = viewModelScope.launch { downloadManager.cancel(id) }
    fun clearFinished() = viewModelScope.launch { downloadManager.clearFinished() }
}

@Composable
fun DownloadsScreen(
    viewModel: DownloadsViewModel = hiltViewModel()
) {
    val queue by viewModel.queue.collectAsState(initial = emptyList())
    val current by viewModel.current.collectAsState()
    val offlineIds by viewModel.offlineCount.collectAsState(initial = emptySet())
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp)
    ) {
        Text(
            "Downloads & Offline",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "${offlineIds.size} songs offline",
            color = SpotifySecondary,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(12.dp))

        // Active progress banner
        current?.let { prog ->
            ActiveProgressCard(prog)
            Spacer(Modifier.height(12.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Queue", color = Color.White, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { scope.launch { viewModel.clearFinished() } }) {
                Text("Clear finished", color = SpotifyGreen)
            }
        }

        if (queue.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.CloudDownload,
                        contentDescription = null,
                        tint = SpotifySecondary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("No downloads in queue", color = SpotifySecondary)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(queue, key = { it.id }) { item ->
                    DownloadQueueItem(
                        item = item,
                        onPause = { viewModel.pause(item.id) },
                        onResume = { viewModel.resume(item.id) },
                        onCancel = { viewModel.cancel(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveProgressCard(prog: DownloadProgress) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1E1E1E))
            .padding(14.dp)
    ) {
        Text(
            prog.title,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.Medium
        )
        Text(prog.artist, color = SpotifySecondary, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { prog.progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = SpotifyGreen,
            trackColor = Color(0xFF333333)
        )
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                "${(prog.progress * 100).toInt()}%",
                color = Color.White,
                fontSize = 12.sp
            )
            val speed = when {
                prog.speedBps > 1_000_000 -> "%.1f MB/s".format(prog.speedBps / 1_000_000.0)
                prog.speedBps > 1_000 -> "%.0f KB/s".format(prog.speedBps / 1_000.0)
                else -> ""
            }
            val eta = prog.etaSeconds?.let { " · ${it}s left" } ?: ""
            Text("$speed$eta", color = SpotifySecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DownloadQueueItem(
    item: DownloadEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF1A1A1A))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                item.title,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 14.sp
            )
            Text(
                "${item.artist} · ${item.status} · ${item.quality}",
                color = SpotifySecondary,
                fontSize = 11.sp,
                maxLines = 1
            )
            if (item.status == DownloadStatus.FAILED.name && !item.error.isNullOrBlank()) {
                Text(
                    item.error,
                    color = Color(0xFFE57373),
                    fontSize = 10.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (item.status == DownloadStatus.DOWNLOADING.name && item.progress > 0) {
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { item.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = SpotifyGreen,
                    trackColor = Color(0xFF333333)
                )
            }
        }
        when (item.status) {
            DownloadStatus.DOWNLOADING.name, DownloadStatus.QUEUED.name -> {
                IconButton(onClick = onPause) {
                    Icon(Icons.Default.Pause, null, tint = Color.White)
                }
            }
            DownloadStatus.PAUSED.name, DownloadStatus.FAILED.name -> {
                IconButton(onClick = onResume) {
                    Icon(Icons.Default.PlayArrow, null, tint = SpotifyGreen)
                }
            }
        }
        IconButton(onClick = onCancel) {
            Icon(
                if (item.status == DownloadStatus.COMPLETED.name) Icons.Default.Delete else Icons.Default.Cancel,
                null,
                tint = Color(0xFFB0B0B0)
            )
        }
    }
}
