package com.personal.sonora.data.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Writes audio files into the public Music collection via MediaStore.
 * Files survive app uninstall and appear in the system music library.
 */
@Singleton
class MediaStoreAudioWriter @Inject constructor(
    @ApplicationContext private val context: Context
) {
    data class WriteResult(
        val contentUri: Uri,
        val displayName: String,
        val relativePath: String
    )

    suspend fun writeAudio(
        title: String,
        artist: String,
        album: String? = null,
        durationMs: Long = 0L,
        mimeType: String = "audio/mp4",
        fileExtension: String = "m4a",
        write: suspend (OutputStream) -> Unit
    ): WriteResult = withContext(Dispatchers.IO) {
        val safeTitle = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(80)
        val safeArtist = artist.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60)
        val displayName = "${safeArtist} - ${safeTitle}.$fileExtension"
        val relativePath = "${Environment.DIRECTORY_MUSIC}/Sonora"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Audio.Media.TITLE, title)
            put(MediaStore.Audio.Media.ARTIST, artist)
            if (!album.isNullOrBlank()) put(MediaStore.Audio.Media.ALBUM, album)
            if (durationMs > 0) put(MediaStore.Audio.Media.DURATION, durationMs)
            put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
            put(MediaStore.Audio.Media.IS_MUSIC, 1)
            put(MediaStore.Audio.Media.RELATIVE_PATH, relativePath)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }

        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values)
            ?: throw IllegalStateException("MediaStore insert failed")

        try {
            resolver.openOutputStream(uri)?.use { out ->
                write(out)
            } ?: throw IllegalStateException("Cannot open output stream")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }

        WriteResult(contentUri = uri, displayName = displayName, relativePath = relativePath)
    }
}
