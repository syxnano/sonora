package com.personal.sonora.ui.video

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import com.personal.sonora.data.social.FirebaseRoomRepository
import com.personal.sonora.data.profile.ProfileRepository
import kotlinx.coroutines.flow.first
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class RoomReplyReceiver : BroadcastReceiver() {
    @Inject lateinit var rooms: FirebaseRoomRepository
    @Inject lateinit var profile: ProfileRepository

    override fun onReceive(context: Context, intent: Intent) {
        val code = intent.getStringExtra("room_code")?.takeIf { it.matches(Regex("\\d{6}")) } ?: return
        val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(RoomChatNotification.replyKey())?.toString()?.trim().orEmpty()
        if (text.isBlank()) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                rooms.sendChatToRoom(code, profile.profile.first().username, text)
            } finally {
                pending.finish()
            }
        }
    }
}
