package com.personal.sonora.room

data class ActiveRoom(
    val roomId: String,
    val sixDigitCode: String,
    val hostUid: String,
    val currentMediaId: String?,
    val currentPositionMs: Long = 0,
    val isPlaying: Boolean = false,
    val serverTimestampMs: Long = 0
)
