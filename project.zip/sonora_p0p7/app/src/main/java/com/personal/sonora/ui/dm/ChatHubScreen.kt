package com.personal.sonora.ui.dm

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.dm.DirectMessageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class ChatHubViewModel @Inject constructor(private val repo: DirectMessageRepository) : ViewModel() {
    val conversations = repo.observeConversations().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
}

@Composable
fun ChatHubScreen(
    onOpenSonora: (uid: String, name: String) -> Unit,
    onOpenProvider: (com.personal.sonora.dm.ChatHead) -> Unit,
    onBack: () -> Unit,
    vm: ChatHubViewModel = hiltViewModel()
) {
    val conversations by vm.conversations.collectAsState()
    val providerHeads = remember {
        listOf(
            com.personal.sonora.dm.ChatHead("ig", com.personal.sonora.connectors.core.Platform.INSTAGRAM, "Instagram", preview = "เปิด DM ผ่าน provider", conversationUrl = "https://www.instagram.com/direct/inbox/"),
            com.personal.sonora.dm.ChatHead("tt", com.personal.sonora.connectors.core.Platform.TIKTOK, "TikTok", preview = "ใช้ช่องทางที่ provider รองรับ", conversationUrl = "https://www.tiktok.com/messages/"),
            com.personal.sonora.dm.ChatHead("x", com.personal.sonora.connectors.core.Platform.X, "X", preview = "Native API เมื่อ authorization พร้อม", conversationUrl = "https://x.com/messages"),
            com.personal.sonora.dm.ChatHead("tg", com.personal.sonora.connectors.core.Platform.TELEGRAM, "Telegram", preview = "TDLib / official client flow", conversationUrl = "https://web.telegram.org/")
        )
    }
    Scaffold(topBar = { TopAppBar(title = { Text("ข้อความ") }, navigationIcon = { Button(onClick = onBack) { Text("กลับ") } }) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad)) {
            if (conversations.isNotEmpty()) item { Text("Sonora", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp)) }
            items(conversations, key = { it.id }) { c ->
                ListItem(
                    headlineContent = { Text(c.otherName) },
                    supportingContent = { Text(c.lastText.ifBlank { c.otherUid }) },
                    trailingContent = { if (c.unread > 0) Text(c.unread.toString()) },
                    modifier = Modifier.fillMaxWidth().clickable { onOpenSonora(c.otherUid, c.otherName) }
                )
                HorizontalDivider()
            }
            item { Text("Connected providers", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp)) }
            items(providerHeads, key = { it.id }) { head ->
                ListItem(
                    headlineContent = { Text(head.displayName) },
                    supportingContent = { Text(head.preview) },
                    modifier = Modifier.fillMaxWidth().clickable { onOpenProvider(head) }
                )
                HorizontalDivider()
            }
        }
    }
}
