package com.personal.sonora.ui.sonora

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.catalog.MusicCatalog
import com.personal.sonora.data.catalog.SearchType
import com.personal.sonora.data.catalog.Track
import com.personal.sonora.data.product.MorningSong
import com.personal.sonora.data.product.MusicCard
import com.personal.sonora.data.product.ProductRepository
import com.personal.sonora.data.product.PublicCardRepository
import com.personal.sonora.data.product.TasteAgent
import com.personal.sonora.data.product.TasteMemory
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.morning.MorningSongScheduler
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.theme.SpotifyBlack
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SonoraViewModel @Inject constructor(
    val products: ProductRepository,
    private val catalog: MusicCatalog,
    private val agent: TasteAgent,
    private val profile: ProfileRepository,
    private val scheduler: MorningSongScheduler,
    private val publicCards: PublicCardRepository
) : ViewModel() {
    val cards = products.cards
    val taste = products.taste
    val morning = products.morning
    val username = profile.profile.map { it.username }

    private val _agentTracks = MutableStateFlow<List<Track>>(emptyList())
    val agentTracks = _agentTracks.asStateFlow()
    private val _agentMessage = MutableStateFlow("")
    val agentMessage = _agentMessage.asStateFlow()
    private val _inbox = MutableStateFlow<List<PublicCardRepository.InboxMessage>>(emptyList())
    val inbox = _inbox.asStateFlow()
    private val _inboxStatus = MutableStateFlow("")
    val inboxStatus = _inboxStatus.asStateFlow()

    init { refreshInbox() }

    fun createCard(track: Track, message: String, mood: String) = viewModelScope.launch {
        products.createCard(track, message, mood)
    }

    fun publishCard(card: MusicCard, onDone: (String?) -> Unit) = viewModelScope.launch {
        card.publicId?.let { existing ->
            onDone(existing)
            return@launch
        }
        runCatching { publicCards.publish(card) }
            .onSuccess { publicId ->
                products.markCardPublished(card.id, publicId)
                onDone(publicId)
            }
            .onFailure { onDone(null) }
    }

    fun deleteCard(id: String) = viewModelScope.launch { products.deleteCard(id) }
    fun saveTaste(value: TasteMemory) = viewModelScope.launch { products.saveTaste(value) }
    fun rateTrack(trackId: String, liked: Boolean) = viewModelScope.launch { products.rateTrack(trackId, liked) }
    fun clearTaste() = viewModelScope.launch { products.clearTaste() }

    fun saveMorning(value: MorningSong) = viewModelScope.launch {
        products.saveMorning(value)
        if (value.enabled) scheduler.schedule(value) else scheduler.cancel()
    }

    fun askAgent(text: String) = viewModelScope.launch {
        _agentMessage.value = "กำลังค้นเพลงที่มีอยู่จริง…"
        runCatching {
            val result = catalog.search(text, SearchType.SONGS, 30)
            val candidates = result.tracks
            val ranked = agent.rank(text, taste.first(), candidates)
            _agentTracks.value = ranked.trackIds.mapNotNull { id -> candidates.firstOrNull { it.id == id } }
            _agentMessage.value = ranked.explanation
        }.onFailure {
            _agentTracks.value = emptyList()
            _agentMessage.value = "ค้นเพลงไม่สำเร็จ ลองใหม่อีกครั้ง"
        }
    }

    fun deleteInbox(id: String) = viewModelScope.launch {
        runCatching { publicCards.deleteInboxMessage(id) }
            .onSuccess { refreshInbox() }
    }

    fun refreshInbox() = viewModelScope.launch {
        _inboxStatus.value = "กำลังโหลด…"
        runCatching { publicCards.inbox() }
            .onSuccess { _inbox.value = it; _inboxStatus.value = if (it.isEmpty()) "ยังไม่มีข้อความตอบกลับ" else "" }
            .onFailure { _inboxStatus.value = "โหลด Inbox ไม่สำเร็จ" }
    }

    fun saveProfile(name: String) = viewModelScope.launch {
        profile.setUsername(name.take(40))
    }
}

@Composable
fun SonoraScreen(
    playerController: PlayerController,
    onOpenRoom: () -> Unit,
    onOpenCard: (String) -> Unit,
    onOpenMusic: (Track) -> Unit,
    viewModel: SonoraViewModel = hiltViewModel()
) {
    val cards by viewModel.cards.collectAsState(emptyList())
    val taste by viewModel.taste.collectAsState(TasteMemory())
    val morning by viewModel.morning.collectAsState(MorningSong())
    val username by viewModel.username.collectAsState("Guest")
    val agentTracks by viewModel.agentTracks.collectAsState()
    val agentMessage by viewModel.agentMessage.collectAsState()
    val inbox by viewModel.inbox.collectAsState()
    val inboxStatus by viewModel.inboxStatus.collectAsState()
    val playerState by playerController.state.collectAsState()
    val context = LocalContext.current

    var tab by remember { mutableIntStateOf(0) }
    var agentText by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Track?>(null) }
    var message by remember { mutableStateOf("") }
    var mood by remember { mutableStateOf("") }
    var liked by remember(taste) { mutableStateOf(taste.likedArtists.joinToString(", ")) }
    var disliked by remember(taste) { mutableStateOf(taste.dislikedArtists.joinToString(", ")) }
    var languages by remember(taste) { mutableStateOf(taste.likedLanguages.joinToString(", ")) }

    Column(Modifier.fillMaxSize().background(SpotifyBlack)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Sonora", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenRoom) { Text("ห้องฟังร่วม", color = SpotifyGreen) }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Cards", "Morning", "Taste", "Inbox", "Profile").forEachIndexed { i, label ->
                Text(
                    label,
                    color = if (tab == i) SpotifyGreen else SpotifySecondary,
                    fontSize = 12.sp,
                    fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clickable { tab = i }.padding(horizontal = 7.dp, vertical = 12.dp)
                )
            }
        }

        when (tab) {
            0 -> CardsTab(
                cards = cards,
                player = playerController,
                currentTrack = playerState.currentTrack,
                onPlay = onOpenMusic,
                onCreate = { selected = it },
                onShare = { card ->
                    viewModel.publishCard(card) { publicId ->
                        val cardUrl = publicId?.let { "https://sonora-9d7f4.web.app/card/$it" }
                        val text = buildString {
                            append("🎵 Music Card จาก Sonora\n")
                            append("${card.track.title} — ${card.track.artist}\n")
                            if (card.message.isNotBlank()) append("“${card.message}”\n")
                            append(cardUrl ?: "เปิด Sonora เพื่อดู Music Card นี้")
                        }
                        context.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                },
                                "ส่ง Music Card"
                            )
                        )
                    }
                },
                onDelete = viewModel::deleteCard
            )
            1 -> MorningTab(morning, cards, viewModel::saveMorning)
            2 -> AgentTab(
                text = agentText,
                setText = { agentText = it },
                result = agentMessage,
                tracks = agentTracks,
                player = playerController,
                onPlay = onOpenMusic,
                ask = { viewModel.askAgent(agentText) },
                liked = liked,
                disliked = disliked,
                languages = languages,
                setLiked = { liked = it },
                setDisliked = { disliked = it },
                setLanguages = { languages = it },
                save = {
                    viewModel.saveTaste(
                        TasteMemory(
                            likedArtists = liked.split(",").map(String::trim).filter(String::isNotBlank),
                            dislikedArtists = disliked.split(",").map(String::trim).filter(String::isNotBlank),
                            likedLanguages = languages.split(",").map(String::trim).filter(String::isNotBlank),
                            learningEnabled = taste.learningEnabled
                        )
                    )
                },
                learning = taste.learningEnabled,
                setLearning = { viewModel.saveTaste(taste.copy(learningEnabled = it)) },
                likedTrackIds = taste.likedTrackIds.toSet(),
                dislikedTrackIds = taste.dislikedTrackIds.toSet(),
                rateTrack = viewModel::rateTrack,
                clearTaste = viewModel::clearTaste
            )
            3 -> InboxTab(inbox, inboxStatus, viewModel::refreshInbox, onOpenCard, viewModel::deleteInbox)
            4 -> ProfileTab(username, viewModel::saveProfile)
        }
    }

    if (selected != null) {
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("สร้าง Music Card") },
            text = {
                Column {
                    Text("${selected!!.title} — ${selected!!.artist}")
                    OutlinedTextField(message, { message = it.take(500) }, label = { Text("ข้อความ") })
                    OutlinedTextField(mood, { mood = it.take(80) }, label = { Text("Mood (ถ้ามี)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.createCard(selected!!, message, mood)
                    selected = null
                    message = ""
                    mood = ""
                }) { Text("สร้าง") }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("ยกเลิก") } }
        )
    }
}

@Composable
private fun CardsTab(
    cards: List<MusicCard>,
    player: PlayerController,
    currentTrack: Track?,
    onPlay: (Track) -> Unit,
    onCreate: (Track) -> Unit,
    onShare: (MusicCard) -> Unit,
    onDelete: (String) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Text("เพลงที่มีความหมาย", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(vertical = 12.dp))
            Button(
                onClick = { currentTrack?.let(onCreate) },
                enabled = currentTrack != null,
                colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)
            ) { Text("สร้าง Card จากเพลงที่กำลังฟัง", color = Color.Black) }
        }
        if (cards.isEmpty()) item { Text("สร้าง Card จากเพลงที่คุณเลือก แล้วส่งให้คนที่อยากให้ฟัง", color = SpotifySecondary) }
        items(cards, key = { it.id }) { card ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text(card.track.title, fontWeight = FontWeight.Bold)
                    Text(card.track.artist, color = Color.Gray)
                    if (card.message.isNotBlank()) Text("“${card.message}”", modifier = Modifier.padding(top = 6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { onPlay(card.track) },
                            colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)
                        ) { Text("ฟัง", color = Color.Black) }
                        IconButton(onClick = { onShare(card) }) { Icon(Icons.Default.Share, null) }
                        IconButton(onClick = { onDelete(card.id) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MorningTab(
    value: MorningSong,
    cards: List<MusicCard>,
    onSave: (MorningSong) -> Unit
) {
    var enabled by remember(value) { mutableStateOf(value.enabled) }
    var hour by remember(value) { mutableStateOf(value.hour.toString()) }
    var minute by remember(value) { mutableStateOf(value.minute.toString().padStart(2, '0')) }
    var message by remember(value) { mutableStateOf(value.message) }
    var selectedCardId by remember(value) { mutableStateOf(value.cardId) }
    val published = cards.filter { !it.publicId.isNullOrBlank() }

    LazyColumn(Modifier.fillMaxSize().padding(20.dp)) {
        item {
            Icon(Icons.Default.NotificationsActive, null, tint = SpotifyGreen, modifier = Modifier.size(36.dp))
            Text("Morning Song", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("ตั้งเวลาให้ Sonora ส่ง Music Card ที่เลือกมาเตือนทุกเช้า", color = SpotifySecondary, modifier = Modifier.padding(vertical = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("เปิดใช้งาน", color = Color.White, modifier = Modifier.weight(1f))
                Switch(enabled, { enabled = it })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hour, { hour = it.filter(Char::isDigit).take(2) }, label = { Text("ชั่วโมง") }, modifier = Modifier.weight(1f))
                OutlinedTextField(minute, { minute = it.filter(Char::isDigit).take(2) }, label = { Text("นาที") }, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(message, { message = it.take(120) }, label = { Text("ข้อความแจ้งเตือน") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            Text("เพลงที่จะส่งตอนเช้า", color = Color.White, fontWeight = FontWeight.Bold)
            if (published.isEmpty()) {
                Text("ยังไม่มี Card ที่แชร์แล้ว — ไปหน้า Cards แล้วกดแชร์อย่างน้อย 1 ใบก่อน", color = SpotifySecondary, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
        }
        items(published.take(30), key = { it.id }) { card ->
            val selected = selectedCardId == card.publicId
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedCardId = card.publicId }
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(card.track.title, fontWeight = FontWeight.SemiBold)
                        Text(card.track.artist, color = Color.Gray, fontSize = 12.sp)
                    }
                    Text(if (selected) "✓ เลือกแล้ว" else "เลือก", color = if (selected) SpotifyGreen else Color.Gray)
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    val selected = published.firstOrNull { it.publicId == selectedCardId }
                    onSave(
                        MorningSong(
                            enabled = enabled,
                            hour = hour.toIntOrNull()?.coerceIn(0, 23) ?: 7,
                            minute = minute.toIntOrNull()?.coerceIn(0, 59) ?: 0,
                            message = message.trim().ifBlank { "เพลงเช้าของคุณวันนี้" },
                            cardId = selected?.publicId,
                            title = selected?.track?.title.orEmpty(),
                            artist = selected?.track?.artist.orEmpty()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen),
                enabled = !enabled || selectedCardId != null
            ) { Text("บันทึก", color = Color.Black) }
            if (enabled && selectedCardId == null) {
                Text("เลือก Music Card ก่อนเปิด Morning Song", color = SpotifySecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
private fun AgentTab(
    text: String,
    setText: (String) -> Unit,
    result: String,
    tracks: List<Track>,
    player: PlayerController,
    onPlay: (Track) -> Unit,
    ask: () -> Unit,
    liked: String,
    disliked: String,
    languages: String,
    setLiked: (String) -> Unit,
    setDisliked: (String) -> Unit,
    setLanguages: (String) -> Unit,
    save: () -> Unit,
    learning: Boolean,
    setLearning: (Boolean) -> Unit,
    likedTrackIds: Set<String>,
    dislikedTrackIds: Set<String>,
    rateTrack: (String, Boolean) -> Unit,
    clearTaste: () -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Icon(Icons.Default.AutoAwesome, null, tint = SpotifyGreen, modifier = Modifier.size(34.dp))
            Text("AI Taste Agent", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("บอกสิ่งที่อยากฟัง แล้ว Sonora จะค้นเพลงจริงก่อนจัดอันดับ", color = SpotifySecondary)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(text, setText, modifier = Modifier.fillMaxWidth(), label = { Text("เช่น วันนี้สอบ อยากฟังไทย ๆ แต่ไม่เศร้า") })
            Button(
                onClick = ask,
                enabled = text.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen),
                modifier = Modifier.padding(top = 8.dp)
            ) { Text("ค้นหาให้ฉัน", color = Color.Black) }
            if (result.isNotBlank()) Text(result, color = Color.White, modifier = Modifier.padding(vertical = 10.dp))
            Text("Taste Memory", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            OutlinedTextField(liked, setLiked, modifier = Modifier.fillMaxWidth(), label = { Text("ศิลปินที่ชอบ (คั่นด้วย ,)") })
            OutlinedTextField(disliked, setDisliked, modifier = Modifier.fillMaxWidth(), label = { Text("ศิลปินที่ไม่ชอบ") })
            OutlinedTextField(languages, setLanguages, modifier = Modifier.fillMaxWidth(), label = { Text("ภาษา") })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("อนุญาตให้ Sonora เรียนรู้จากการใช้งาน", color = Color.White, modifier = Modifier.weight(1f))
                Switch(learning, setLearning)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = save) { Text("บันทึก Taste Memory") }
                TextButton(onClick = clearTaste) { Text("ล้าง Taste", color = SpotifySecondary) }
            }
            Text(
                "Feedback เพลง: ชอบ ${likedTrackIds.size} • ไม่ชอบ ${dislikedTrackIds.size}",
                color = SpotifySecondary,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
        }
        items(tracks, key = { it.id }) { t ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    Modifier.weight(1f).clickable { onPlay(t) }.padding(end = 8.dp)
                ) {
                    Text(t.title, color = Color.White)
                    Text(t.artist, color = SpotifySecondary)
                }
                TextButton(onClick = { rateTrack(t.id, true) }) {
                    Text(if (t.id in likedTrackIds) "👍✓" else "👍", color = SpotifyGreen)
                }
                TextButton(onClick = { rateTrack(t.id, false) }) {
                    Text(if (t.id in dislikedTrackIds) "👎✓" else "👎", color = Color.LightGray)
                }
            }
        }
    }
}

@Composable
private fun InboxTab(
    inbox: List<PublicCardRepository.InboxMessage>,
    status: String,
    refresh: () -> Unit,
    openCard: (String) -> Unit,
    delete: (String) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("ข้อความตอบกลับ", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = refresh) { Text("รีเฟรช") }
            }
            if (status.isNotBlank()) Text(status, color = SpotifySecondary)
        }
        items(inbox, key = { it.id }) { msg ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable {
                    if (msg.cardId.isNotBlank()) openCard(msg.cardId)
                }
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(msg.cardTitle.ifBlank { "Music Card" }, fontWeight = FontWeight.Bold)
                        Text(msg.message)
                        Text("แตะเพื่อเปิดการ์ด", color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton(onClick = { delete(msg.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "ลบข้อความ")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileTab(username: String, save: (String) -> Unit) {
    var name by remember(username) { mutableStateOf(username) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Profile", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("ชื่อใช้ในห้องฟังร่วมและหน้าส่วนตัวของเครื่องนี้", color = SpotifySecondary)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(name, { name = it.take(40) }, label = { Text("ชื่อ") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(onClick = { save(name) }, colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)) {
            Text("บันทึก", color = Color.Black)
        }
    }
}
