package com.personal.sonora.data.catalog

import com.personal.sonora.video.YouTubeSearchRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YouTubeMusicCatalog @Inject constructor(
    private val youtube: YouTubeSearchRepository
) : MusicCatalog {
    override suspend fun search(query: String, type: SearchType, limit: Int): SearchResult =
        SearchResult(tracks = youtube.search(query, limit).map { it.toTrack() })

    override suspend fun trending(limit: Int): List<Track> =
        youtube.search("top songs music", limit).map { it.toTrack() }

    override suspend fun tracksByTag(tag: String, page: Int, limit: Int): List<Track> =
        youtube.search("$tag music", limit).map { it.toTrack() }

    override suspend fun similarTracks(seed: Track, limit: Int): List<Track> =
        youtube.search("${seed.artist} ${seed.title} similar", limit).map { it.toTrack() }

    override suspend fun artistTopTracks(artist: String, limit: Int): List<Track> =
        youtube.search("$artist official audio", limit).map { it.toTrack() }

    private fun com.personal.sonora.video.VideoItem.toTrack() = Track(
        id = "yt_$id", title = title, artist = creator, durationMs = durationMs,
        coverUrl = thumbnailUrl, source = "youtube", externalId = id
    )
}
