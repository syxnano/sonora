package com.personal.sonora.dm

import com.personal.sonora.connectors.core.Platform

data class ChatHead(
    val id: String,
    val platform: Platform,
    val displayName: String,
    val avatarUrl: String? = null,
    val preview: String = "",
    val unread: Int = 0,
    val conversationUrl: String? = null
)

data class ConversationTarget(
    val platform: Platform,
    val displayName: String,
    val conversationUrl: String,
    val fallbackUrl: String = conversationUrl
)
