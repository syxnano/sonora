package com.personal.sonora.outbox

enum class OutboxState { QUEUED, RETRYING, SENT, FAILED, MANUAL_REQUIRED }

data class OutboxTask(
    val id: String,
    val provider: String,
    val type: String,
    val payloadJson: String,
    val createdAtMs: Long,
    val attempts: Int = 0,
    val state: OutboxState = OutboxState.QUEUED,
    val lastError: String? = null
)
