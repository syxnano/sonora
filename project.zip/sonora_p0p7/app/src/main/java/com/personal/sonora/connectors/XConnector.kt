package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

class XConnector : SonoraConnector {
    override val platform = Platform.X

    override suspend fun capabilities() = listOf(
        CapabilityStatus(Capability.READ_PROFILE, CapabilityState.NEEDS_PERMISSION, "X user authorization"),
        CapabilityStatus(Capability.READ_FEED, CapabilityState.NEEDS_PERMISSION, "X API access/plan"),
        CapabilityStatus(Capability.READ_MEDIA, CapabilityState.NEEDS_PERMISSION, "Post/media API access"),
        CapabilityStatus(Capability.READ_MESSAGES, CapabilityState.NEEDS_PERMISSION, "Endpoint + account authorization"),
        CapabilityStatus(Capability.SEND_MESSAGE, CapabilityState.NEEDS_PERMISSION, "X API user-context authorization"),
        CapabilityStatus(Capability.FOLLOW, CapabilityState.NEEDS_PERMISSION, "X user-context authorization"),
        CapabilityStatus(Capability.LIKE, CapabilityState.NEEDS_PERMISSION, "X user-context authorization"),
        CapabilityStatus(Capability.EMBED_PLAYBACK, CapabilityState.NEEDS_PERMISSION, "Use X-supported rendering")
    )

    override suspend fun connect() = Result.success(Unit)
    override suspend fun disconnect() = Result.success(Unit)
    override suspend fun refresh() = Result.success(Unit)
}
