package com.personal.sonora.video

import com.personal.sonora.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YouTubeSearchRepository @Inject constructor(private val client: OkHttpClient) {
    suspend fun search(query: String, limit: Int = 24): List<VideoItem> = withContext(Dispatchers.IO) {
        val key = BuildConfig.YOUTUBE_API_KEY.trim()
        if (key.isBlank() || query.isBlank()) return@withContext emptyList()

        val searchUrl = "https://www.googleapis.com/youtube/v3/search".toHttpUrl().newBuilder()
            .addQueryParameter("part", "snippet")
            .addQueryParameter("q", query)
            .addQueryParameter("type", "video")
            .addQueryParameter("maxResults", minOf(limit, 50).toString())
            .addQueryParameter("videoDuration", "short")
            .addQueryParameter("videoEmbeddable", "true")
            .addQueryParameter("key", key)
            .build()

        val searchJson = get(searchUrl.toString()) ?: return@withContext emptyList()
        val ids = mutableListOf<String>()
        val snippets = HashMap<String, Triple<String, String, String?>>()
        val arr = searchJson.optJSONArray("items") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
            if (!id.matches(Regex("[A-Za-z0-9_-]{11}"))) continue
            val sn = item.optJSONObject("snippet") ?: continue
            ids += id
            snippets[id] = Triple(sn.optString("title"), sn.optString("channelTitle"), sn.optJSONObject("thumbnails")?.optJSONObject("medium")?.optString("url"))
        }
        if (ids.isEmpty()) return@withContext emptyList()

        val videoUrl = "https://www.googleapis.com/youtube/v3/videos".toHttpUrl().newBuilder()
            .addQueryParameter("part", "contentDetails,snippet")
            .addQueryParameter("id", ids.joinToString(","))
            .addQueryParameter("key", key)
            .build()
        val videosJson = get(videoUrl.toString()) ?: return@withContext emptyList()
        val videos = videosJson.optJSONArray("items") ?: JSONArray()
        val out = mutableListOf<VideoItem>()
        for (i in 0 until videos.length()) {
            val v = videos.optJSONObject(i) ?: continue
            val id = v.optString("id")
            val seconds = parseIsoDuration(v.optJSONObject("contentDetails")?.optString("duration").orEmpty())
            // Product rule: YouTube discovery is strictly under one minute.
            if (seconds >= 60) continue
            val s = snippets[id] ?: Triple(v.optJSONObject("snippet")?.optString("title").orEmpty(), v.optJSONObject("snippet")?.optString("channelTitle").orEmpty(), null)
            out += VideoItem(VideoProvider.YOUTUBE, id, s.first, s.second, s.third, seconds * 1000L, "https://www.youtube.com/watch?v=$id")
        }
        out
    }

    private fun get(url: String): org.json.JSONObject? = runCatching {
        client.newCall(Request.Builder().url(url).get().build()).execute().use { response ->
            if (!response.isSuccessful) return null
            org.json.JSONObject(response.body?.string().orEmpty())
        }
    }.getOrNull()

    private fun parseIsoDuration(value: String): Long {
        val m = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").matchEntire(value) ?: return Long.MAX_VALUE
        val h = m.groupValues[1].toLongOrNull() ?: 0
        val min = m.groupValues[2].toLongOrNull() ?: 0
        val sec = m.groupValues[3].toLongOrNull() ?: 0
        return h * 3600 + min * 60 + sec
    }
}
