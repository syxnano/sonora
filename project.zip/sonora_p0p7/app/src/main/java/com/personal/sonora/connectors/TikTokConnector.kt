package com.personal.sonora.connectors

import com.personal.sonora.connectors.core.*

class TikTokConnector : SonoraConnector {
    override val platform = Platform.TIKTOK

    override suspend fun capabilities() = listOf(
        CapabilityStatus(Capability.READ_PROFILE, CapabilityState.NEEDS_PERMISSION, "Login Kit + user scope"),
        CapabilityStatus(Capability.READ_STATS, CapabilityState.NEEDS_PERMISSION, "Stats scope/account eligibility"),
        CapabilityStatus(Capability.READ_FEED, CapabilityState.NEEDS_PERMISSION, "Provider/API eligibility"),
        CapabilityStatus(Capability.READ_MEDIA, CapabilityState.NEEDS_PERMISSION, "Display/API permission"),
        CapabilityStatus(
            Capability.READ_MESSAGES, CapabilityState.NEEDS_PERMISSION,
            "Official Data Portability API can export DM data; not a generic live inbox API"
        ),
        CapabilityStatus(
            Capability.SEND_MESSAGE, CapabilityState.UNSUPPORTED,
            "No general public TikTok developer endpoint established for sending a DM to another user"
        ),
        CapabilityStatus(
            Capability.DAILY_FLAME, CapabilityState.SUPPORTED,
            "Sonora tracks the streak; external TikTok send requires an officially supported action"
        ),
        CapabilityStatus(Capability.EMBED_PLAYBACK, CapabilityState.NEEDS_PERMISSION, "Official TikTok display/embed flow")
    )

    override suspend fun connect() = Result.success(Unit)
    override suspend fun disconnect() = Result.success(Unit)
    override suspend fun refresh() = Result.success(Unit)
}
