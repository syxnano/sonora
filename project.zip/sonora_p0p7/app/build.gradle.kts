import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.ksp)
    id("com.google.gms.google-services")
}

val localProperties = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) {
        file.inputStream().use { load(it) }
    }
}

android {
    namespace = "com.personal.sonora"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.personal.sonora"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "4.0.0-social-all-in-one"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField(
            "String",
            "LASTFM_API_KEY",
            "\"${localProperties.getProperty("LASTFM_API_KEY", "")}\""
        )

        buildConfigField(
            "String",
            "YOUTUBE_API_KEY",
            "\"${localProperties.getProperty("YOUTUBE_API_KEY", "")}\""
        )

        buildConfigField(
            "String",
            "TIKTOK_CLIENT_KEY",
            "\"${localProperties.getProperty("TIKTOK_CLIENT_KEY", "")}\""
        )

        buildConfigField(
            "String",
            "X_CLIENT_ID",
            "\"${localProperties.getProperty("X_CLIENT_ID", "")}\""
        )

        buildConfigField(
            "String",
            "TURN_URLS",
            "\"${localProperties.getProperty("TURN_URLS", "")}\""
        )

        buildConfigField(
            "String",
            "TURN_USERNAME",
            "\"${localProperties.getProperty("TURN_USERNAME", "")}\""
        )

        buildConfigField(
            "String",
            "TURN_CREDENTIAL",
            "\"${localProperties.getProperty("TURN_CREDENTIAL", "")}\""
        )

        buildConfigField(
            "String",
            "FIREBASE_DB_URL",
            "\"${localProperties.getProperty("FIREBASE_DB_URL", "")}\""
        )

        buildConfigField(
            "String",
            "METERED_API_KEY",
            "\"${localProperties.getProperty("METERED_API_KEY", "")}\""
        )
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
        }
    }
}

dependencies {
    coreLibraryDesugaring(libs.desugar.jdk.libs)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.palette)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.session)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.media3.common)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)

    implementation(libs.coil.compose)

    implementation(libs.jsoup)

    // Firebase Realtime DB — social room + playback sync (no login required)
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-database-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-messaging-ktx")
    implementation("com.google.android.gms:play-services-auth:21.3.0")
    implementation("com.dafruits:webrtc:123.0.0") {
        // Firebase protolite-well-known-types already packages the overlapping
        // protobuf DescriptorProtos classes. Avoid duplicate protobuf-javalite.
        exclude(group = "com.google.protobuf", module = "protobuf-javalite")
    }
    implementation("com.google.firebase:firebase-appcheck-playintegrity")
    debugImplementation("com.google.firebase:firebase-appcheck-debug")


    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
}
