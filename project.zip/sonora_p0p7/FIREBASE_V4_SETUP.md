# Sonora v4 Firebase setup

## Already required
- Authentication: Email/Password ON
- Authentication: Google provider ON
- Realtime Database ON
- Firestore Database ON
- Storage ON
- Cloud Messaging ON
- App Check: Play Integrity for Android (enforce only after testing)

## Google Sign-In
Download/refresh `google-services.json` after enabling Google Sign-In. The Android app expects the Firebase Web OAuth client ID in `default_web_client_id`. If the generated resources do not provide it, replace the placeholder in `app/src/main/res/values/strings.xml` with the Web client ID from Firebase Project Settings > General > Your apps > Web app / OAuth client.

## Firestore collections
users/{uid}
friendRequests/{requestId}
friends/{uidA:uidB}
dm/{sortedUidPair}/messages/{messageId}
posts/{postId}
comments/{postId}/items/{commentId}
likes/{postId}/users/{uid}
notifications/{uid}/items/{notificationId}

## Realtime Database
Keep RTDB for active rooms, playback clock/state, presence, room chat and WebRTC signaling. Do not put passwords in RTDB/Firestore.

## Provider keys
YouTube Data API key stays in local.properties/build secrets; do not commit it. Do not download/extract YouTube/TikTok media streams. Use official APIs/players/embeds.
