# Sonora merged latest source

This package combines the Sonora v4 all-in-one social Android source with the Connector Rebuild v0.2 architecture.

Included:
- All-in-one Android social/media foundation from v4
- Home/social/video/music foundations
- Firebase auth/social/room foundations
- Active room, chat and voice foundations
- Music Card / Morning Song / Taste systems
- Provider connector architecture
- Unified account center and capability engine
- X connector and TikTok connector capability boundaries
- Unified outbox and provider-confirmed delivery policy
- TikTok daily Flame tracking policy
- Provider attribution and failure models
- Token security policy
- Integration and TikTok DM status documentation

Important:
- This is a source merge, not a verified APK build.
- TikTok generic live DM sending is not faked; unsupported capabilities remain unsupported.
- Do not use scraped cookies, extracted private tokens, unofficial private APIs, or stream extraction for provider media.
- The existing legacy YouTubeResolver remains in the v4 source for legacy compatibility; the new official YouTube playback path must not use it.
