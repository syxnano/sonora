# Sonora — Production deployment

## 1. Firebase
- Project: `sonora-9d7f4`
- Enable Authentication → Anonymous.
- Enable Realtime Database.
- Apply `firebase-rules.json`.
- Enable App Check for Android and Web before opening the social/public Card endpoints broadly.

## 2. Public Music Card
From the project root:

```bash
npm install -g firebase-tools
firebase login
firebase use sonora-9d7f4
firebase deploy --only hosting,database
```

The public card URL used by Android is:
`https://sonora-9d7f4.web.app/card/<CARD_ID>`

If Firebase Hosting gives the project a different primary site/domain, update `PUBLIC_CARD_BASE_URL` in the Android sharing code and the App Link host in `AndroidManifest.xml`.

## 3. Android release
Open the project in Android Studio, sync Gradle, configure a release signing key, then build:

```bash
./gradlew bundleRelease
```

Upload the generated AAB to Google Play Console.

## 4. Pre-launch tests
- Create a Music Card on phone A.
- Share the URL to Discord.
- Open the URL on phone B and desktop browser.
- Verify card metadata, provider hand-off and reply.
- Verify anonymous auth and database rules reject unauthenticated writes.
- Verify a user cannot overwrite an existing public Card.
- Verify long/HTML/script payloads are rendered safely.
- Enable Firebase App Check and verify rejected requests are visible in monitoring.
- Test 100 concurrent card opens and replies before a 10,000-member community launch.

## Important
This repository still contains legacy unofficial stream-resolver code from the prototype. The normal external-catalog playback path has been changed to L0 hand-off, but the legacy resolver code has not been physically removed from the repository. Remove that legacy path before a public compliance review if the app will be distributed commercially/publicly.
