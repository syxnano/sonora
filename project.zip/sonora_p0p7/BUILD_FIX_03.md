# Sonora BUILD FIX 03

Fixes GitHub Actions `checkDebugDuplicateClasses`:
- WebRTC `com.dafruits:webrtc:123.0.0` was bringing `protobuf-javalite`.
- Firebase `protolite-well-known-types:18.0.0` already contains overlapping protobuf classes such as `DescriptorProtos`.
- The WebRTC dependency now excludes only its transitive `protobuf-javalite`.

This is scoped to WebRTC rather than globally excluding protobuf, so Firebase dependencies are not disabled.
