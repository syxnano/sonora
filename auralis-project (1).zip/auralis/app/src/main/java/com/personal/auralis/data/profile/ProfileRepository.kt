package com.personal.auralis.data.profile

import com.personal.auralis.data.settings.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import javax.inject.Inject
import javax.inject.Singleton

data class GuestProfile(
    val username: String = "Guest",
    val avatarUri: String = ""
)

@Singleton
class ProfileRepository @Inject constructor(
    private val settings: SettingsRepository
) {
    val profile: Flow<GuestProfile> = combine(
        settings.username,
        settings.avatarUri
    ) { name, avatar ->
        GuestProfile(username = name, avatarUri = avatar)
    }

    suspend fun setUsername(name: String) = settings.setUsername(name)
    suspend fun setAvatarUri(uri: String) = settings.setAvatarUri(uri)
}
