package com.personal.auralis.ui.queue

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.auralis.player.PlayerController
import com.personal.auralis.ui.components.CoverArt
import com.personal.auralis.ui.theme.SpotifyElevated
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    playerController: PlayerController,
    onDismiss: () -> Unit
) {
    val state by playerController.state.collectAsState()
    val queue = state.queue
    val current = state.queueIndex

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SpotifyElevated) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                "Queue (${queue.size})",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (queue.isEmpty()) {
                Text(
                    "The queue is empty.",
                    color = SpotifySecondary,
                    modifier = Modifier.padding(16.dp)
                )
            }
            LazyColumn(Modifier.heightIn(max = 480.dp)) {
                itemsIndexed(queue) { index, track ->
                    val isCurrent = index == current
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { playerController.playAt(index) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CoverArt(track.coverUrl, size = 44.dp, corner = 4.dp)
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(horizontal = 12.dp)
                        ) {
                            Text(
                                track.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (isCurrent) SpotifyGreen else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                track.artist,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = SpotifySecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (!isCurrent) {
                            IconButton(onClick = { playerController.removeFromQueue(index) }) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = SpotifySecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
