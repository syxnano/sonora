package com.personal.auralis.ui.nowplaying

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.auralis.data.lyrics.LyricLine
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary

@Composable
fun SyncedLyricsView(
    lines: List<LyricLine>,
    positionMs: Long,
    plainFallback: String? = null,
    modifier: Modifier = Modifier
) {
    if (lines.isEmpty()) {
        Box(modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            Text(
                plainFallback?.take(800) ?: "No lyrics found",
                color = SpotifySecondary,
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )
        }
        return
    }

    val activeIndex = remember(lines, positionMs) {
        var idx = 0
        for (i in lines.indices) {
            if (lines[i].timeMs <= positionMs) idx = i else break
        }
        idx
    }

    val listState = rememberLazyListState()
    LaunchedEffect(activeIndex) {
        if (lines.isNotEmpty()) {
            listState.animateScrollToItem(index = (activeIndex - 1).coerceAtLeast(0))
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        itemsIndexed(lines) { index, line ->
            val active = index == activeIndex
            Text(
                text = line.text,
                color = if (active) Color.White else SpotifySecondary.copy(alpha = 0.55f),
                fontSize = if (active) 20.sp else 15.sp,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp, horizontal = 24.dp)
            )
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}
