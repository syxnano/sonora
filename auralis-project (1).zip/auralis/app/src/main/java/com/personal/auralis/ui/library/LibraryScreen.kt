package com.personal.auralis.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.auralis.R
import com.personal.auralis.data.db.PlaylistEntity
import com.personal.auralis.data.playlist.PlaylistRepository
import com.personal.auralis.data.spotify.SpotifyImportException
import com.personal.auralis.data.spotify.SpotifyImporter
import com.personal.auralis.data.youtube.YouTubePlaylistImporter
import com.personal.auralis.player.PlayerController
import com.personal.auralis.ui.components.ConfirmDialog
import com.personal.auralis.ui.components.CoverArt
import com.personal.auralis.ui.components.NamePlaylistDialog
import com.personal.auralis.ui.theme.SpotifyElevated
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ImportUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val doneMessage: String? = null
)

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repo: PlaylistRepository,
    private val importer: SpotifyImporter,
    private val youtubeImporter: YouTubePlaylistImporter
) : ViewModel() {

    private val _import = MutableStateFlow(ImportUiState())
    val importState: StateFlow<ImportUiState> = _import.asStateFlow()

    fun importLink(link: String) {
        if (_import.value.loading) return
        _import.value = ImportUiState(loading = true)
        viewModelScope.launch {
            try {
                val result = if (youtubeImporter.looksLikeYouTube(link)) {
                    youtubeImporter.fetch(link)
                } else {
                    importer.fetch(link)
                }
                repo.createFromImport(result.name, result.coverUrl, result.tracks)
                fillMissingCovers()
                _import.value = ImportUiState(
                    doneMessage = "Imported ${result.tracks.size} songs into \"${result.name}\""
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: SpotifyImportException) {
                _import.value = ImportUiState(error = e.message)
            } catch (e: Throwable) {
                _import.value = ImportUiState(
                    error = "Import failed: ${e.javaClass.simpleName} ${e.message ?: ""}".take(160)
                )
            }
        }
    }

    fun resetImport() {
        _import.value = ImportUiState()
    }

    val playlists = repo.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<PlaylistEntity>())

    init {
        viewModelScope.launch { repo.ensureLikedSongs() }
        fillMissingCovers()
    }

    /** Downloads album art for imported Spotify songs that have none yet. */
    fun fillMissingCovers() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val missing = repo.tracksWithoutCover()
                if (missing.isEmpty()) return@launch
                val gate = Semaphore(4)
                coroutineScope {
                    missing.map { t ->
                        async {
                            gate.withPermit {
                                val spotifyId = t.externalId
                                if (spotifyId != null) {
                                    val url = importer.fetchTrackCover(spotifyId)
                                    if (url != null) repo.setTrackCover(t.id, url)
                                }
                            }
                        }
                    }.awaitAll()
                }
                repo.refreshPlaylistCovers()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // covers are optional
            }
        }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch { repo.create(name) }
    }

    fun rename(id: String, name: String) {
        viewModelScope.launch { repo.rename(id, name) }
    }

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}

@Composable
fun LibraryScreen(
    playerController: PlayerController,
    onOpenSettings: () -> Unit,
    onOpenPlaylist: (String) -> Unit,
    onOpenDownloads: () -> Unit = {},
    viewModel: LibraryViewModel = hiltViewModel()
) {
    val playlists by viewModel.playlists.collectAsState()
    val importState by viewModel.importState.collectAsState()
    var showImport by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<PlaylistEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<PlaylistEntity?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.nav_library), style = MaterialTheme.typography.headlineMedium)
            Row {
                IconButton(onClick = onOpenDownloads) {
                    Icon(Icons.Default.CloudDownload, contentDescription = "Downloads")
                }
                IconButton(onClick = { viewModel.resetImport(); showImport = true }) {
                    Icon(Icons.Default.Link, contentDescription = "Import playlist from link")
                }
                IconButton(onClick = { showCreate = true }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                }
            }
        }
        LazyColumn {
            item(key = "downloaded_songs") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenDownloads() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(64.dp)
                            .background(SpotifyGreen, androidx.compose.foundation.shape.RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Color.Black)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text("เพลงที่ดาวน์โหลดแล้ว", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "ฟังออฟไลน์ ไม่ต้องใช้เน็ต",
                            color = SpotifySecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            items(playlists, key = { it.id }) { pl ->
                var menuOpen by remember { mutableStateOf(false) }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenPlaylist(pl.id) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CoverArt(pl.coverUrl, size = 64.dp)
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(
                            if (pl.isLikedSongs) stringResource(R.string.liked_songs) else pl.name,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            if (pl.isLikedSongs) "Playlist" else "Playlist",
                            color = SpotifySecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (!pl.isLikedSongs) {
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = null, tint = SpotifySecondary)
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.rename_playlist)) },
                                    onClick = { menuOpen = false; renameTarget = pl }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.delete_playlist)) },
                                    onClick = { menuOpen = false; deleteTarget = pl }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showImport) {
        ImportSpotifyDialog(
            state = importState,
            onImport = { viewModel.importLink(it) },
            onClose = { showImport = false; viewModel.resetImport() }
        )
    }
    if (showCreate) {
        NamePlaylistDialog(
            title = stringResource(R.string.create_playlist),
            initial = "",
            onDismiss = { showCreate = false },
            onConfirm = { viewModel.createPlaylist(it); showCreate = false }
        )
    }
    renameTarget?.let { pl ->
        NamePlaylistDialog(
            title = stringResource(R.string.rename_playlist),
            initial = pl.name,
            onDismiss = { renameTarget = null },
            onConfirm = { viewModel.rename(pl.id, it); renameTarget = null }
        )
    }
    deleteTarget?.let { pl ->
        ConfirmDialog(
            title = stringResource(R.string.delete_playlist),
            message = "Delete \"${pl.name}\"? This cannot be undone.",
            confirmLabel = "Delete",
            onDismiss = { deleteTarget = null },
            onConfirm = { viewModel.delete(pl.id); deleteTarget = null }
        )
    }
}


@Composable
private fun ImportSpotifyDialog(
    state: ImportUiState,
    onImport: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var link by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { if (!state.loading) onClose() },
        containerColor = SpotifyElevated,
        title = { Text("Import playlist") },
        text = {
            Column {
                if (state.doneMessage != null) {
                    Text(state.doneMessage)
                } else {
                    Text(
                        "Paste a PUBLIC Spotify playlist/album link or a YouTube playlist link. Spotify gives only the first ~50-100 songs; YouTube up to 300.",
                        color = SpotifySecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = link,
                        onValueChange = { link = it },
                        singleLine = true,
                        enabled = !state.loading,
                        placeholder = { Text("Spotify or YouTube playlist link") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp)
                    )
                    TextButton(
                        enabled = !state.loading,
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val pasted = cm.primaryClip?.getItemAt(0)?.text?.toString()
                            if (!pasted.isNullOrBlank()) link = pasted.trim()
                        }
                    ) { Text("Paste from clipboard", color = SpotifyGreen) }
                    if (state.loading) {
                        Text("Importing...", color = SpotifySecondary)
                    }
                    state.error?.let { Text(it, color = androidx.compose.ui.graphics.Color(0xFFE22134)) }
                }
            }
        },
        confirmButton = {
            if (state.doneMessage != null) {
                TextButton(onClick = onClose) { Text("OK", color = SpotifyGreen) }
            } else {
                TextButton(
                    enabled = !state.loading && link.isNotBlank(),
                    onClick = { onImport(link) }
                ) { Text("Import", color = SpotifyGreen) }
            }
        },
        dismissButton = {
            if (state.doneMessage == null) {
                TextButton(enabled = !state.loading, onClick = onClose) {
                    Text("Cancel", color = SpotifySecondary)
                }
            }
        }
    )
}
