package com.personal.auralis.data.recommend

import com.personal.auralis.data.catalog.LastFmCatalog
import com.personal.auralis.data.catalog.MusicCatalog
import com.personal.auralis.data.catalog.Track
import com.personal.auralis.data.db.PlaylistDao
import com.personal.auralis.data.db.PlaylistTrackDao
import com.personal.auralis.data.db.SeenTrackDao
import com.personal.auralis.data.db.SeenTrackEntity
import com.personal.auralis.data.db.TrackDao
import com.personal.auralis.data.db.TrackEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DiscoverEngine @Inject constructor(
    private val catalog: MusicCatalog,
    private val lastFm: LastFmCatalog,
    private val playlistDao: PlaylistDao,
    private val playlistTrackDao: PlaylistTrackDao,
    private val trackDao: TrackDao,
    private val seenTrackDao: SeenTrackDao
) {
    private companion object {
        val AI_PATTERN = Regex(
            """(?i)(ai[- ]generated|suno|udio|made with ai|ai music|artificial intelligence|chatgpt song)"""
        )
    }

    suspend fun buildTasteProfile(playlistId: String? = null): TasteProfile {
        val playlists = if (playlistId != null) {
            listOfNotNull(playlistDao.getById(playlistId))
        } else {
            playlistDao.observeAll().first()
        }
        val artistCounts = mutableMapOf<String, Int>()
        val tagCounts = mutableMapOf<String, Int>()
        val seedTracks = mutableListOf<Track>()

        for (pl in playlists) {
            val ids = playlistTrackDao.getTrackIds(pl.id)
            val tracks = trackDao.getByIds(ids)
            for (t in tracks) {
                artistCounts[t.artist] = (artistCounts[t.artist] ?: 0) + 1
                seedTracks.add(
                    Track(t.id, t.title, t.artist, t.album, t.durationMs, t.coverUrl, t.source, t.externalId)
                )
                val tags = lastFm.artistTopTags(t.artist)
                tags.forEach { tag -> tagCounts[tag] = (tagCounts[tag] ?: 0) + 1 }
            }
        }

        return TasteProfile(
            topArtists = artistCounts.entries.sortedByDescending { it.value }.map { it.key }.take(10),
            topTags = tagCounts.entries.sortedByDescending { it.value }.map { it.key }.take(5),
            seedTracks = seedTracks.shuffled().take(15)
        )
    }

    suspend fun discover(count: Int = 60, playlistId: String? = null): List<Track> {
        val profile = buildTasteProfile(playlistId)
        val seen = seenTrackDao.getAllIds().toSet()
        val inPlaylists = mutableSetOf<String>()
        playlistDao.observeAll().first().forEach { pl ->
            inPlaylists.addAll(playlistTrackDao.getTrackIds(pl.id))
        }

        val candidates = mutableListOf<Track>()

        // From tags
        for (tag in profile.topTags.take(5)) {
            val page = (1..5).random()
            candidates += catalog.tracksByTag(tag, page, 20)
        }

        // Similar to seeds
        for (seed in profile.seedTracks.shuffled().take(8)) {
            candidates += catalog.similarTracks(seed, 10)
        }

        // Top tracks of top artists
        for (artist in profile.topArtists.take(5)) {
            candidates += catalog.artistTopTracks(artist, 8)
        }

        // If empty profile, use trending
        if (candidates.isEmpty()) {
            candidates += catalog.trending(count * 2)
        }

        // Prefer human artists; light filter for obvious AI-generated titles
        val aiPattern = Regex(
            """(?i)(ai[- ]generated|suno|udio|made with ai|ai music|artificial intelligence|chatgpt song)"""
        )
        val preferredTags = setOf("thai pop", "t-pop", "pop", "r&b", "rnb", "soul", "hip-hop", "indie pop")

        val filtered = candidates
            .filter { it.id !in seen && it.id !in inPlaylists }
            .filter { !aiPattern.containsMatchIn(it.title) && !aiPattern.containsMatchIn(it.artist) }
            .distinctBy { "${it.artist.lowercase()}|${it.title.lowercase()}" }
            .shuffled()
            .take(count)

        // Mark as seen
        seenTrackDao.markSeenAll(filtered.map { SeenTrackEntity(it.id) })
        // Cache tracks
        trackDao.upsertAll(filtered.map {
            TrackEntity(it.id, it.title, it.artist, it.album, it.durationMs, it.coverUrl, it.source, it.externalId)
        })

        return filtered
    }

    /**
     * "Keep the music going" after a playlist/queue ends.
     * Style comes from the tracks the user actually queued ([seeds]): their artists, those artists'
     * Last.fm tags, and tracks similar to random seeds. Anything in [exclude] (already in the queue)
     * is never returned, so the same song doesn't come back.
     */
    suspend fun autoplayFor(seeds: List<Track>, exclude: Set<String>, count: Int = 15): List<Track> {
        val pool = seeds.distinctBy { it.id }
        if (pool.isEmpty()) return emptyList()

        val artistCounts = pool.groupingBy { it.artist }.eachCount()
        val topArtists = artistCounts.entries
            .filter { it.key.isNotBlank() }
            .sortedByDescending { it.value }
            .map { it.key }
            .take(6)

        val tagCounts = mutableMapOf<String, Int>()
        for (artist in topArtists.take(4)) {
            for (tag in safeList { lastFm.artistTopTags(artist) }) {
                tagCounts[tag] = (tagCounts[tag] ?: 0) + 1
            }
        }
        val topTags = tagCounts.entries.sortedByDescending { it.value }.map { it.key }.take(3)

        val candidates = mutableListOf<Track>()
        for (seed in pool.shuffled().take(6)) {
            candidates += safeList { catalog.similarTracks(seed, 12) }
        }
        for (tag in topTags) {
            candidates += safeList { catalog.tracksByTag(tag, (1..3).random(), 15) }
        }
        for (artist in topArtists.shuffled().take(3)) {
            candidates += safeList { catalog.artistTopTracks(artist, 6) }
        }
        if (candidates.isEmpty()) {
            candidates += safeList { catalog.trending(count * 2) }
        }

        // max 3 songs per artist so one artist can't take over the whole batch
        val perArtist = mutableMapOf<String, Int>()
        val picked = candidates
            .filter { it.id !in exclude }
            .filter { !AI_PATTERN.containsMatchIn(it.title) && !AI_PATTERN.containsMatchIn(it.artist) }
            .distinctBy { "${it.artist.lowercase()}|${it.title.lowercase()}" }
            .shuffled()
            .filter { t ->
                val n = (perArtist[t.artist] ?: 0) + 1
                perArtist[t.artist] = n
                n <= 3
            }
            .take(count)

        if (picked.isNotEmpty()) {
            try {
                trackDao.upsertAll(picked.map {
                    TrackEntity(it.id, it.title, it.artist, it.album, it.durationMs, it.coverUrl, it.source, it.externalId)
                })
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
        return picked
    }

    private suspend fun <T> safeList(block: suspend () -> List<T>): List<T> =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            emptyList()
        }

    suspend fun resetSeen() {
        seenTrackDao.clearAll()
    }
}

data class TasteProfile(
    val topArtists: List<String>,
    val topTags: List<String>,
    val seedTracks: List<Track>
)
