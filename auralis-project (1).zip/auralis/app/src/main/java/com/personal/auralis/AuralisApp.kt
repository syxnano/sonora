package com.personal.auralis

import android.app.Application
import com.personal.auralis.data.download.OfflineRecovery
import com.personal.auralis.di.NewPipeInit
import com.personal.auralis.util.CrashLog
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class AuralisApp : Application() {
    /**
     * Injecting this marker forces Hilt to create the NewPipeInit binding,
     * which runs NewPipe.init(...) in its provider.
     */
    @Inject lateinit var newPipeInit: NewPipeInit
    @Inject lateinit var offlineRecovery: OfflineRecovery

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        // Install before anything else so even start-up crashes are captured.
        CrashLog.install(this)
        super.onCreate()
        // Recover playlists + offline files after reinstall (best-effort)
        appScope.launch {
            offlineRecovery.runIfNeeded()
        }
    }
}
