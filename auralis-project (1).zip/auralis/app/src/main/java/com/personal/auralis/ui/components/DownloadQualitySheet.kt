package com.personal.auralis.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.personal.auralis.data.download.DownloadQuality
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadQualitySheet(
    selected: DownloadQuality,
    onSelect: (DownloadQuality) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF1E1E1E)
    ) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                "Download quality",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
            Text(
                "Remembered for next time",
                color = SpotifySecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            DownloadQuality.entries.forEach { q ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(q) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(q.label, color = Color.White)
                    }
                    if (q == selected) {
                        Icon(Icons.Default.Check, null, tint = SpotifyGreen)
                    }
                }
            }
        }
    }
}
