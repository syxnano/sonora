package com.personal.auralis.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = SpotifyGreen,
    onPrimary = Color.Black,
    secondary = SpotifySecondary,
    onSecondary = SpotifyWhite,
    background = SpotifyBlack,
    onBackground = SpotifyWhite,
    surface = SpotifySurface,
    onSurface = SpotifyWhite,
    surfaceVariant = SpotifyElevated,
    onSurfaceVariant = SpotifySecondary,
    error = SpotifyError,
    onError = SpotifyWhite
)

@Composable
fun AuralisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = AuralisTypography,
        content = content
    )
}
