package com.personal.auralis.data.catalog

import com.personal.auralis.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LastFmCatalog @Inject constructor(
    private val client: OkHttpClient,
    private val fallback: YouTubeMusicCatalog
) : MusicCatalog {

    private val apiKey: String get() = BuildConfig.LASTFM_API_KEY
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val base = "https://ws.audioscrobbler.com/2.0/"

    private fun hasKey(): Boolean = apiKey.isNotBlank()

    override suspend fun search(query: String, type: SearchType, limit: Int): SearchResult {
        if (!hasKey()) return fallback.search(query, type, limit)
        return withContext(Dispatchers.IO) {
            try {
                val tracks = when (type) {
                    SearchType.SONGS, SearchType.ALL -> searchTracks(query, limit)
                    else -> emptyList()
                }
                SearchResult(tracks = tracks)
            } catch (e: Exception) {
                fallback.search(query, type, limit)
            }
        }
    }

    override suspend fun trending(limit: Int): List<Track> {
        if (!hasKey()) return fallback.trending(limit)
        return withContext(Dispatchers.IO) {
            try {
                val url = "$base?method=chart.getTopTracks&api_key=$apiKey&format=json&limit=$limit"
                val body = get(url) ?: return@withContext fallback.trending(limit)
                val resp = json.decodeFromString<ChartTracksResponse>(body)
                resp.tracks?.track?.map { it.toTrack() } ?: fallback.trending(limit)
            } catch (e: Exception) {
                fallback.trending(limit)
            }
        }
    }

    override suspend fun tracksByTag(tag: String, page: Int, limit: Int): List<Track> {
        if (!hasKey()) return fallback.tracksByTag(tag, page, limit)
        return withContext(Dispatchers.IO) {
            try {
                val url = "$base?method=tag.getTopTracks&tag=${tag.encode()}&api_key=$apiKey&format=json&limit=$limit&page=$page"
                val body = get(url) ?: return@withContext emptyList()
                val resp = json.decodeFromString<TagTracksResponse>(body)
                resp.tracks?.track?.map { it.toTrack() } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    override suspend fun similarTracks(seed: Track, limit: Int): List<Track> {
        if (!hasKey()) return fallback.similarTracks(seed, limit)
        return withContext(Dispatchers.IO) {
            try {
                val url = "$base?method=track.getSimilar&artist=${seed.artist.encode()}&track=${seed.title.encode()}&api_key=$apiKey&format=json&limit=$limit"
                val body = get(url) ?: return@withContext emptyList()
                val resp = json.decodeFromString<SimilarTracksResponse>(body)
                resp.similartracks?.track?.map { it.toTrack() } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    override suspend fun artistTopTracks(artist: String, limit: Int): List<Track> {
        if (!hasKey()) return fallback.artistTopTracks(artist, limit)
        return withContext(Dispatchers.IO) {
            try {
                val url = "$base?method=artist.getTopTracks&artist=${artist.encode()}&api_key=$apiKey&format=json&limit=$limit"
                val body = get(url) ?: return@withContext emptyList()
                val resp = json.decodeFromString<ArtistTracksResponse>(body)
                resp.toptracks?.track?.map { it.toTrack() } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    suspend fun artistTopTags(artist: String): List<String> = withContext(Dispatchers.IO) {
        if (!hasKey()) return@withContext emptyList()
        try {
            val url = "$base?method=artist.getTopTags&artist=${artist.encode()}&api_key=$apiKey&format=json"
            val body = get(url) ?: return@withContext emptyList()
            val resp = json.decodeFromString<TopTagsResponse>(body)
            resp.toptags?.tag?.mapNotNull { it.name }?.take(5) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun searchTracks(query: String, limit: Int): List<Track> {
        val url = "$base?method=track.search&track=${query.encode()}&api_key=$apiKey&format=json&limit=$limit"
        val body = get(url) ?: return emptyList()
        val resp = json.decodeFromString<TrackSearchResponse>(body)
        return resp.results?.trackmatches?.track?.map { it.toTrack() } ?: emptyList()
    }

    private fun get(url: String): String? {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            return resp.body?.string()
        }
    }

    private fun String.encode() = java.net.URLEncoder.encode(this, "UTF-8")

    /**
     * Last.fm returns `artist` as either a plain string or an object `{ "name": "..." }`.
     * We store it as JsonElement and resolve the display name here.
     */
    private fun LastFmTrack.toTrack(): Track {
        val artistName = resolveArtistName(artist)
        return Track(
            id = "lfm_${artistName}_$name".hashCode().toString(),
            title = name ?: "Unknown",
            artist = artistName,
            durationMs = (duration?.toLongOrNull() ?: 0L) * 1000,
            coverUrl = image?.lastOrNull { it.text?.isNotBlank() == true }?.text,
            source = "lastfm"
        )
    }

    private fun resolveArtistName(element: JsonElement?): String {
        if (element == null) return "Unknown"
        return when (element) {
            is JsonPrimitive -> element.contentOrNull ?: "Unknown"
            is JsonObject -> element["name"]?.jsonPrimitive?.contentOrNull ?: "Unknown"
            else -> "Unknown"
        }
    }

    // --- Serialization models ---
    @Serializable data class ChartTracksResponse(val tracks: TrackList? = null)
    @Serializable data class TagTracksResponse(val tracks: TrackList? = null)
    @Serializable data class SimilarTracksResponse(val similartracks: TrackList? = null)
    @Serializable data class ArtistTracksResponse(val toptracks: TrackList? = null)
    @Serializable data class TrackSearchResponse(val results: SearchResults? = null)
    @Serializable data class TopTagsResponse(val toptags: TagList? = null)

    @Serializable data class TrackList(val track: List<LastFmTrack>? = null)
    @Serializable data class SearchResults(val trackmatches: TrackList? = null)
    @Serializable data class TagList(val tag: List<TagItem>? = null)
    @Serializable data class TagItem(val name: String? = null)

    @Serializable
    data class LastFmTrack(
        val name: String? = null,
        val duration: String? = null,
        /** String or object depending on the Last.fm endpoint */
        val artist: JsonElement? = null,
        val image: List<ImageObj>? = null
    )

    @Serializable
    data class ImageObj(
        @SerialName("#text") val text: String? = null,
        val size: String? = null
    )
}
