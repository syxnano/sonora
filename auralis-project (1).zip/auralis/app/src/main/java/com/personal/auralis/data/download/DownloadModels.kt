package com.personal.auralis.data.download

enum class DownloadQuality(val key: String, val label: String, val maxBitrate: Int) {
    LOW("LOW", "Low (~64 kbps)", 80),
    MEDIUM("MEDIUM", "Medium (~128 kbps)", 140),
    HIGH("HIGH", "High (~160–256 kbps)", 280),
    BEST("BEST", "Best available", Int.MAX_VALUE);

    companion object {
        fun fromKey(key: String): DownloadQuality =
            entries.find { it.key == key } ?: HIGH
    }
}

enum class DownloadStatus {
    QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELLED
}

data class DownloadProgress(
    val id: String,
    val trackId: String,
    val title: String,
    val artist: String,
    val status: DownloadStatus,
    val progress: Float,
    val bytesDownloaded: Long,
    val totalBytes: Long,
    val speedBps: Long,
    val etaSeconds: Long? = null,
    val error: String? = null,
    val playlistId: String? = null,
    val playlistProgress: Pair<Int, Int>? = null // completed / total in same playlist batch
)
