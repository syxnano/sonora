package com.personal.auralis.data.catalog

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YouTubeMusicCatalog @Inject constructor() : MusicCatalog {

    private val service get() = ServiceList.YouTube

    override suspend fun search(query: String, type: SearchType, limit: Int): SearchResult =
        withContext(Dispatchers.IO) {
            try {
                val search = SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(query))
                val tracks = search.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .take(limit)
                    .map { it.toTrack() }
                SearchResult(tracks = tracks)
            } catch (e: Exception) {
                SearchResult()
            }
        }

    override suspend fun trending(limit: Int): List<Track> = withContext(Dispatchers.IO) {
        try {
            // Use a popular music search as trending proxy
            val search = SearchInfo.getInfo(
                service,
                service.searchQHFactory.fromQuery("top songs this week")
            )
            search.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .take(limit)
                .map { it.toTrack() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override suspend fun tracksByTag(tag: String, page: Int, limit: Int): List<Track> =
        withContext(Dispatchers.IO) {
            try {
                val search = SearchInfo.getInfo(
                    service,
                    service.searchQHFactory.fromQuery("$tag music")
                )
                search.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .drop((page - 1) * limit)
                    .take(limit)
                    .map { it.toTrack() }
            } catch (e: Exception) {
                emptyList()
            }
        }

    override suspend fun similarTracks(seed: Track, limit: Int): List<Track> =
        withContext(Dispatchers.IO) {
            try {
                val query = "${seed.artist} ${seed.title} similar"
                val search = SearchInfo.getInfo(service, service.searchQHFactory.fromQuery(query))
                search.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .take(limit)
                    .map { it.toTrack() }
            } catch (e: Exception) {
                emptyList()
            }
        }

    override suspend fun artistTopTracks(artist: String, limit: Int): List<Track> =
        withContext(Dispatchers.IO) {
            try {
                val search = SearchInfo.getInfo(
                    service,
                    service.searchQHFactory.fromQuery("$artist official audio")
                )
                search.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .take(limit)
                    .map { it.toTrack() }
            } catch (e: Exception) {
                emptyList()
            }
        }

    private fun StreamInfoItem.toTrack(): Track {
        val id = url?.let { extractVideoId(it) } ?: url.hashCode().toString()
        return Track(
            id = "yt_$id",
            title = name ?: "Unknown",
            artist = uploaderName ?: "Unknown",
            durationMs = duration * 1000L,
            coverUrl = thumbnails?.maxByOrNull { it.height }?.url,
            source = "youtube",
            externalId = id
        )
    }

    private fun extractVideoId(url: String): String {
        val patterns = listOf(
            Regex("(?:v=|/embed/|/shorts/|youtu\\.be/)([\\w\\-]{11})"),
            Regex("([\\w\\-]{11})")
        )
        for (p in patterns) {
            p.find(url)?.groupValues?.getOrNull(1)?.let { return it }
        }
        return url.hashCode().toString()
    }
}
