package com.personal.auralis.ui.theme

import androidx.compose.ui.graphics.Color

val SpotifyBlack = Color(0xFF121212)
val SpotifySurface = Color(0xFF181818)
val SpotifyElevated = Color(0xFF282828)
val SpotifyWhite = Color(0xFFFFFFFF)
val SpotifySecondary = Color(0xFFB3B3B3)
val SpotifyGreen = Color(0xFF1DB954)
val SpotifyError = Color(0xFFE22134)
val SpotifyGreenDark = Color(0xFF1AA34A)
