package com.personal.auralis.data.lyrics

import com.personal.auralis.data.catalog.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

data class LyricLine(
    val timeMs: Long,
    val text: String
)

data class LyricsResult(
    val plain: String? = null,
    val synced: List<LyricLine> = emptyList(),
    val source: String = "lrclib"
)

/**
 * Free lyrics via LRCLIB (https://lrclib.net) — no API key required.
 */
@Singleton
class LyricsRepository @Inject constructor(
    private val client: OkHttpClient
) {
    suspend fun fetch(track: Track): LyricsResult? = withContext(Dispatchers.IO) {
        try {
            val artist = URLEncoder.encode(track.artist, StandardCharsets.UTF_8.name())
            val title = URLEncoder.encode(track.title, StandardCharsets.UTF_8.name())
            val durationSec = if (track.durationMs > 0) (track.durationMs / 1000).toString() else null
            val album = track.album?.let { URLEncoder.encode(it, StandardCharsets.UTF_8.name()) }

            val url = buildString {
                append("https://lrclib.net/api/get?artist_name=$artist&track_name=$title")
                if (album != null) append("&album_name=$album")
                if (durationSec != null) append("&duration=$durationSec")
            }

            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Auralis/1.0 (personal; Android)")
                .get()
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    // fallback search
                    return@withContext searchFallback(track)
                }
                val body = resp.body?.string() ?: return@withContext null
                parseLyricsJson(body)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun searchFallback(track: Track): LyricsResult? {
        return try {
            val q = URLEncoder.encode("${track.artist} ${track.title}", StandardCharsets.UTF_8.name())
            val req = Request.Builder()
                .url("https://lrclib.net/api/search?q=$q")
                .header("User-Agent", "Auralis/1.0 (personal; Android)")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val arr = org.json.JSONArray(resp.body?.string() ?: return null)
                if (arr.length() == 0) return null
                val first = arr.getJSONObject(0)
                parseLyricsJson(first.toString())
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun parseLyricsJson(body: String): LyricsResult? {
        val obj = JSONObject(body)
        val plain = obj.optString("plainLyrics").ifBlank { null }
        val syncedRaw = obj.optString("syncedLyrics").ifBlank { null }
        val lines = if (syncedRaw != null) parseLrc(syncedRaw) else emptyList()
        if (plain == null && lines.isEmpty()) return null
        return LyricsResult(plain = plain, synced = lines)
    }

    /** Parse [mm:ss.xx] text LRC format */
    fun parseLrc(lrc: String): List<LyricLine> {
        val regex = Regex("""\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?](.*)""")
        val result = mutableListOf<LyricLine>()
        for (line in lrc.lines()) {
            val m = regex.find(line.trim()) ?: continue
            val min = m.groupValues[1].toLong()
            val sec = m.groupValues[2].toLong()
            val frac = m.groupValues[3].ifBlank { "0" }
            val msPart = when (frac.length) {
                1 -> frac.toLong() * 100
                2 -> frac.toLong() * 10
                else -> frac.take(3).toLong()
            }
            val timeMs = min * 60_000 + sec * 1_000 + msPart
            val text = m.groupValues[4].trim()
            if (text.isNotEmpty()) result.add(LyricLine(timeMs, text))
        }
        return result.sortedBy { it.timeMs }
    }
}
