package com.personal.auralis.ui.components

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.auralis.data.catalog.Track
import com.personal.auralis.data.db.PlaylistEntity
import com.personal.auralis.data.playlist.PlaylistRepository
import com.personal.auralis.ui.theme.SpotifyElevated
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlaylistActionsViewModel @Inject constructor(
    private val repo: PlaylistRepository
) : ViewModel() {

    val playlists = repo.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList<PlaylistEntity>())

    init {
        viewModelScope.launch { repo.ensureLikedSongs() }
    }

    /** onDone(true) = added, onDone(false) = it was already there. */
    fun addTo(playlistId: String, track: Track, onDone: (Boolean) -> Unit) {
        viewModelScope.launch { onDone(repo.addTrack(playlistId, track)) }
    }

    fun createAndAdd(name: String, track: Track, onDone: () -> Unit) {
        viewModelScope.launch {
            val id = repo.create(name)
            repo.addTrack(id, track)
            onDone()
        }
    }

    fun observeLiked(trackId: String): Flow<Boolean> = repo.observeLiked(trackId)

    fun toggleLike(track: Track) {
        viewModelScope.launch { repo.toggleLike(track) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddToPlaylistSheet(
    track: Track,
    onDismiss: () -> Unit,
    viewModel: PlaylistActionsViewModel = hiltViewModel()
) {
    val playlists by viewModel.playlists.collectAsState()
    val context = LocalContext.current
    var showCreate by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SpotifyElevated) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                "Add to playlist",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            Text(
                "${track.title} · ${track.artist}",
                color = SpotifySecondary,
                maxLines = 1,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { showCreate = true }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = SpotifyGreen)
                Spacer(Modifier.width(16.dp))
                Text("New playlist", color = SpotifyGreen)
            }
            LazyColumn {
                items(playlists) { pl ->
                    Text(
                        text = if (pl.isLikedSongs) "Liked Songs" else pl.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.addTo(pl.id, track) { added ->
                                    Toast.makeText(
                                        context,
                                        if (added) "Added to ${pl.name}" else "Already in ${pl.name}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onDismiss()
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    )
                }
            }
        }
    }

    if (showCreate) {
        NamePlaylistDialog(
            title = "New playlist",
            initial = "",
            onDismiss = { showCreate = false },
            onConfirm = { name ->
                showCreate = false
                viewModel.createAndAdd(name, track) {
                    Toast.makeText(context, "Added to $name", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            }
        )
    }
}

@Composable
fun NamePlaylistDialog(
    title: String,
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SpotifyElevated,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Playlist name") }
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text.trim().ifBlank { "New playlist" }) }) {
                Text("OK", color = SpotifyGreen)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = SpotifySecondary) }
        }
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SpotifyElevated,
        title = { Text(title) },
        text = { Text(message, color = SpotifySecondary) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(confirmLabel, color = SpotifyGreen) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = SpotifySecondary) }
        }
    )
}
