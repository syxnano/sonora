package com.personal.auralis.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.auralis.data.catalog.Track
import com.personal.auralis.data.db.PlayHistoryDao
import com.personal.auralis.data.db.PlaylistDao
import com.personal.auralis.data.db.PlaylistEntity
import com.personal.auralis.data.db.TrackDao
import com.personal.auralis.data.recommend.DiscoverEngine
import com.personal.auralis.data.settings.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val discover: List<Track> = emptyList(),
    val recent: List<Track> = emptyList(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val discoverEngine: DiscoverEngine,
    private val settings: SettingsRepository,
    private val playlistDao: PlaylistDao,
    private val playHistoryDao: PlayHistoryDao,
    private val trackDao: TrackDao
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        load()
        viewModelScope.launch {
            playlistDao.observeAll().collect { list ->
                _state.value = _state.value.copy(playlists = list)
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val count = settings.discoverCount.first()
                val discover = discoverEngine.discover(count)
                val recentIds = playHistoryDao.recentTrackIds(20)
                val recent = trackDao.getByIds(recentIds).map {
                    Track(it.id, it.title, it.artist, it.album, it.durationMs, it.coverUrl, it.source, it.externalId)
                }
                _state.value = _state.value.copy(
                    isLoading = false,
                    discover = discover,
                    recent = recent
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Error"
                )
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            discoverEngine.resetSeen()
            load()
        }
    }
}
