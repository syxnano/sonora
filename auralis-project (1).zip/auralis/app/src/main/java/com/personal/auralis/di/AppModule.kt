package com.personal.auralis.di

import android.content.Context
import androidx.room.Room
import com.personal.auralis.data.catalog.LastFmCatalog
import com.personal.auralis.data.catalog.MusicCatalog
import com.personal.auralis.data.catalog.YouTubeMusicCatalog
import com.personal.auralis.data.db.AuralisDatabase
import com.personal.auralis.data.resolver.OkHttpDownloader
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/** Marker type so we can inject NewPipe initialization without using a primitive. */
class NewPipeInit

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        return OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AuralisDatabase {
        return Room.databaseBuilder(context, AuralisDatabase::class.java, "auralis.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides fun provideTrackDao(db: AuralisDatabase) = db.trackDao()
    @Provides fun providePlaylistDao(db: AuralisDatabase) = db.playlistDao()
    @Provides fun providePlaylistTrackDao(db: AuralisDatabase) = db.playlistTrackDao()
    @Provides fun provideResolvedStreamDao(db: AuralisDatabase) = db.resolvedStreamDao()
    @Provides fun provideSeenTrackDao(db: AuralisDatabase) = db.seenTrackDao()
    @Provides fun provideRecentSearchDao(db: AuralisDatabase) = db.recentSearchDao()
    @Provides fun providePlayHistoryDao(db: AuralisDatabase) = db.playHistoryDao()
    @Provides fun provideDownloadDao(db: AuralisDatabase) = db.downloadDao()
    @Provides fun provideOfflineTrackDao(db: AuralisDatabase) = db.offlineTrackDao()

    @Provides
    @Singleton
    fun provideMusicCatalog(lastFm: LastFmCatalog): MusicCatalog = lastFm

    @Provides
    @Singleton
    fun provideNewPipeInit(client: OkHttpClient): NewPipeInit {
        NewPipe.init(
            OkHttpDownloader(client),
            Localization.DEFAULT,
            ContentCountry.DEFAULT
        )
        return NewPipeInit()
    }
}
