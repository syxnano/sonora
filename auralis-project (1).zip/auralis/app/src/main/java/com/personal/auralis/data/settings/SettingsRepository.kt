package com.personal.auralis.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("auralis_settings")

enum class StreamQuality { AUTO, VERY_HIGH, HIGH, DATA_SAVER }

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val ds = context.dataStore

    private object Keys {
        val WIFI_QUALITY = stringPreferencesKey("wifi_quality")
        val MOBILE_QUALITY = stringPreferencesKey("mobile_quality")
        val DISCOVER_COUNT = intPreferencesKey("discover_count")
        val CROSSFADE_SEC = floatPreferencesKey("crossfade_sec")
        val NORMALIZATION = booleanPreferencesKey("normalization")
        val LASTFM_KEY = stringPreferencesKey("lastfm_key_override")
        val SPOTIFY_CLIENT_ID = stringPreferencesKey("spotify_client_id")
        val EQ_PRESET = intPreferencesKey("eq_preset")
        val DOWNLOAD_QUALITY = stringPreferencesKey("download_quality")
        val USERNAME = stringPreferencesKey("username")
        val AVATAR_URI = stringPreferencesKey("avatar_uri")
        val SLEEP_TIMER_MIN = intPreferencesKey("sleep_timer_min")
    }

    val wifiQuality: Flow<StreamQuality> = ds.data.map {
        StreamQuality.valueOf(it[Keys.WIFI_QUALITY] ?: StreamQuality.VERY_HIGH.name)
    }
    val mobileQuality: Flow<StreamQuality> = ds.data.map {
        StreamQuality.valueOf(it[Keys.MOBILE_QUALITY] ?: StreamQuality.HIGH.name)
    }
    val discoverCount: Flow<Int> = ds.data.map { it[Keys.DISCOVER_COUNT] ?: 60 }
    val crossfadeSec: Flow<Float> = ds.data.map { it[Keys.CROSSFADE_SEC] ?: 0f }
    val normalization: Flow<Boolean> = ds.data.map { it[Keys.NORMALIZATION] ?: false }
    val lastFmKeyOverride: Flow<String> = ds.data.map { it[Keys.LASTFM_KEY] ?: "" }
    val spotifyClientId: Flow<String> = ds.data.map { it[Keys.SPOTIFY_CLIENT_ID] ?: "" }
    val eqPreset: Flow<Int> = ds.data.map { it[Keys.EQ_PRESET] ?: 0 }
    val downloadQuality: Flow<String> = ds.data.map { it[Keys.DOWNLOAD_QUALITY] ?: "HIGH" }
    val username: Flow<String> = ds.data.map { it[Keys.USERNAME] ?: "Guest" }
    val avatarUri: Flow<String> = ds.data.map { it[Keys.AVATAR_URI] ?: "" }
    val sleepTimerMin: Flow<Int> = ds.data.map { it[Keys.SLEEP_TIMER_MIN] ?: 0 }

    suspend fun getDownloadQuality(): String =
        ds.data.map { it[Keys.DOWNLOAD_QUALITY] ?: "HIGH" }.first()

    suspend fun setWifiQuality(q: StreamQuality) {
        ds.edit { it[Keys.WIFI_QUALITY] = q.name }
    }
    suspend fun setMobileQuality(q: StreamQuality) {
        ds.edit { it[Keys.MOBILE_QUALITY] = q.name }
    }
    suspend fun setDiscoverCount(n: Int) {
        ds.edit { it[Keys.DISCOVER_COUNT] = n.coerceIn(50, 100) }
    }
    suspend fun setCrossfadeSec(sec: Float) {
        ds.edit { it[Keys.CROSSFADE_SEC] = sec.coerceIn(0f, 12f) }
    }
    suspend fun setNormalization(enabled: Boolean) {
        ds.edit { it[Keys.NORMALIZATION] = enabled }
    }
    suspend fun setLastFmKey(key: String) {
        ds.edit { it[Keys.LASTFM_KEY] = key }
    }
    suspend fun setSpotifyClientId(id: String) {
        ds.edit { it[Keys.SPOTIFY_CLIENT_ID] = id }
    }
    suspend fun setEqPreset(index: Int) {
        ds.edit { it[Keys.EQ_PRESET] = index }
    }
    suspend fun setDownloadQuality(q: String) {
        ds.edit { it[Keys.DOWNLOAD_QUALITY] = q }
    }
    suspend fun setUsername(name: String) {
        ds.edit { it[Keys.USERNAME] = name.trim().ifBlank { "Guest" } }
    }
    suspend fun setAvatarUri(uri: String) {
        ds.edit { it[Keys.AVATAR_URI] = uri }
    }
    suspend fun setSleepTimerMin(min: Int) {
        ds.edit { it[Keys.SLEEP_TIMER_MIN] = min.coerceIn(0, 180) }
    }
}
