package com.personal.auralis.data.resolver

/**
 * Many YouTube videos carry several audio tracks (the original plus auto-dubbed or described
 * versions in other languages). Picking "the highest bitrate" can land on an English dub of a Thai
 * song, so we always prefer the ORIGINAL language track.
 */
object AudioTrackPolicy {
    enum class Kind { ORIGINAL, DUBBED, OTHER_VARIANT, UNKNOWN }

    /**
     * @param trackType NewPipe's AudioTrackType name (ORIGINAL / DUBBED / DESCRIPTIVE / SECONDARY) or null
     * @param url       stream url; YouTube tags the track in it as `xtags=acont=original:lang=th`
     */
    fun kindOf(trackType: String?, url: String?): Kind {
        when (trackType?.uppercase()) {
            "ORIGINAL" -> return Kind.ORIGINAL
            "DUBBED" -> return Kind.DUBBED
            "DESCRIPTIVE", "SECONDARY" -> return Kind.OTHER_VARIANT
        }
        val u = (url ?: "").lowercase().replace("%3d", "=").replace("%3a", ":").replace("%253d", "=")
        return when {
            u.contains("acont=original") -> Kind.ORIGINAL
            u.contains("acont=dubbed") -> Kind.DUBBED // also matches dubbed-auto
            u.contains("acont=descriptive") -> Kind.OTHER_VARIANT
            else -> Kind.UNKNOWN
        }
    }

    /** True if this url is a dubbed / audio-description track (used to discard old cached urls). */
    fun isDubbedUrl(url: String?): Boolean = kindOf(null, url).let {
        it == Kind.DUBBED || it == Kind.OTHER_VARIANT
    }

    /**
     * ORIGINAL tracks if there are any; otherwise everything that isn't a dub/description;
     * otherwise (nothing else exists) the full list.
     */
    fun <T> select(items: List<T>, kind: (T) -> Kind): List<T> {
        val original = items.filter { kind(it) == Kind.ORIGINAL }
        if (original.isNotEmpty()) return original
        val plain = items.filter {
            val k = kind(it)
            k != Kind.DUBBED && k != Kind.OTHER_VARIANT
        }
        return plain.ifEmpty { items }
    }
}
