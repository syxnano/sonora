package com.personal.auralis.ui.navigation

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.personal.auralis.R
import com.personal.auralis.player.PlayerController
import com.personal.auralis.ui.components.MiniPlayer
import com.personal.auralis.ui.home.HomeScreen
import com.personal.auralis.ui.library.LibraryScreen
import com.personal.auralis.ui.nowplaying.NowPlayingScreen
import com.personal.auralis.ui.playlist.PlaylistScreen
import com.personal.auralis.ui.search.SearchScreen
import com.personal.auralis.ui.settings.SettingsScreen
import com.personal.auralis.ui.theme.SpotifyBlack
import com.personal.auralis.ui.theme.SpotifyGreen
import com.personal.auralis.ui.theme.SpotifySecondary

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Search : Screen("search")
    data object Library : Screen("library")
    data object NowPlaying : Screen("nowplaying")
    data object Settings : Screen("settings")
    data object Downloads : Screen("downloads")
    data object Artist : Screen("artist/{name}") {
        fun create(name: String) = "artist/$name"
    }
    data object Playlist : Screen("playlist/{id}") {
        fun create(id: String) = "playlist/$id"
    }
}

@Composable
fun AuralisNavGraph(
    playerController: PlayerController
) {
    val navController = rememberNavController()
    val playerState by playerController.state.collectAsState()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showBottomBar = currentDestination?.route in listOf(
        Screen.Home.route, Screen.Search.route, Screen.Library.route, Screen.Playlist.route
    )

    val context = LocalContext.current
    LaunchedEffect(playerState.error) {
        playerState.error?.let { Toast.makeText(context, it, Toast.LENGTH_LONG).show() }
    }

    Scaffold(
        containerColor = SpotifyBlack,
        bottomBar = {
            if (showBottomBar) {
                androidx.compose.foundation.layout.Column {
                    MiniPlayer(
                        track = playerState.currentTrack,
                        isPlaying = playerState.isPlaying,
                        progress = if (playerState.durationMs > 0)
                            playerState.positionMs.toFloat() / playerState.durationMs
                        else 0f,
                        onToggle = { playerController.togglePlayPause() },
                        onNext = { playerController.skipNext() },
                        onExpand = { navController.navigate(Screen.NowPlaying.route) }
                    )
                    NavigationBar(containerColor = SpotifyBlack) {
                        val items = listOf(
                            Triple(Screen.Home, Icons.Default.Home, R.string.nav_home),
                            Triple(Screen.Search, Icons.Default.Search, R.string.nav_search),
                            Triple(Screen.Library, Icons.Default.LibraryMusic, R.string.nav_library)
                        )
                        items.forEach { (screen, icon, labelRes) ->
                            val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(icon, contentDescription = null) },
                                label = { Text(stringResource(labelRes)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = Color.White,
                                    unselectedIconColor = SpotifySecondary,
                                    unselectedTextColor = SpotifySecondary,
                                    indicatorColor = Color.Transparent
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    playerController = playerController,
                    onOpenSettings = { navController.navigate(Screen.Settings.route) },
                    onOpenPlaylist = { id -> navController.navigate(Screen.Playlist.create(id)) }
                )
            }
            composable(Screen.Search.route) {
                SearchScreen(playerController = playerController)
            }
            composable(Screen.Library.route) {
                LibraryScreen(
                    playerController = playerController,
                    onOpenSettings = { navController.navigate(Screen.Settings.route) },
                    onOpenPlaylist = { id -> navController.navigate(Screen.Playlist.create(id)) },
                    onOpenDownloads = { navController.navigate(Screen.Downloads.route) }
                )
            }
            composable(Screen.NowPlaying.route) {
                NowPlayingScreen(
                    playerController = playerController,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Playlist.route) {
                PlaylistScreen(
                    playerController = playerController,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Downloads.route) {
                com.personal.auralis.ui.downloads.DownloadsScreen()
            }
            composable(Screen.Artist.route) { backStack ->
                val name = backStack.arguments?.getString("name") ?: "Artist"
                com.personal.auralis.ui.artist.ArtistScreen(artistName = name)
            }
        }
    }
}
