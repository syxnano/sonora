package com.personal.auralis.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TrackDao {
    // IGNORE (not REPLACE): replacing a track row would cascade-delete its playlist entries.
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun upsert(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun upsertAll(tracks: List<TrackEntity>)

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun getById(id: String): TrackEntity?

    @Query("SELECT * FROM tracks WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<TrackEntity>

    @Query("SELECT * FROM tracks WHERE source = 'spotify' AND (coverUrl IS NULL OR coverUrl = '')")
    suspend fun getSpotifyWithoutCover(): List<TrackEntity>

    @Query("UPDATE tracks SET coverUrl = :url WHERE id = :id")
    suspend fun setCover(id: String, url: String)
}

@Dao
interface PlaylistDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(playlist: PlaylistEntity)

    @Update
    suspend fun update(playlist: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: String)

    @Query(
        "UPDATE playlists SET coverUrl = (" +
            "SELECT t.coverUrl FROM tracks t INNER JOIN playlist_tracks pt ON pt.trackId = t.id " +
            "WHERE pt.playlistId = playlists.id AND t.coverUrl IS NOT NULL " +
            "ORDER BY pt.position ASC LIMIT 1) " +
            "WHERE coverUrl IS NULL OR coverUrl = ''"
    )
    suspend fun fillEmptyCovers()

    @Query("SELECT * FROM playlists ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id")
    suspend fun getById(id: String): PlaylistEntity?

    @Query("SELECT * FROM playlists WHERE isLikedSongs = 1 LIMIT 1")
    suspend fun getLikedSongs(): PlaylistEntity?

    @Query("SELECT * FROM playlists WHERE id = :id")
    fun observeById(id: String): Flow<PlaylistEntity?>
}

@Dao
interface PlaylistTrackDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: PlaylistTrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<PlaylistTrackEntity>)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId")
    suspend fun remove(playlistId: String, trackId: String)

    @Query("DELETE FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun clearPlaylist(playlistId: String)

    @Query("SELECT trackId FROM playlist_tracks WHERE playlistId = :playlistId ORDER BY position ASC")
    suspend fun getTrackIds(playlistId: String): List<String>

    @Query("SELECT * FROM playlist_tracks WHERE playlistId = :playlistId ORDER BY position ASC")
    fun observeTracks(playlistId: String): Flow<List<PlaylistTrackEntity>>

    @Query("SELECT COUNT(*) FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun count(playlistId: String): Int

    @Query("SELECT MAX(position) FROM playlist_tracks WHERE playlistId = :playlistId")
    suspend fun maxPosition(playlistId: String): Int?

    @Query(
        "SELECT t.* FROM tracks t INNER JOIN playlist_tracks pt ON pt.trackId = t.id " +
            "WHERE pt.playlistId = :playlistId ORDER BY pt.position ASC"
    )
    fun observeTrackEntities(playlistId: String): Flow<List<TrackEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM playlist_tracks WHERE playlistId = :playlistId AND trackId = :trackId)")
    fun observeContains(playlistId: String, trackId: String): Flow<Boolean>

    @Transaction
    suspend fun reorder(playlistId: String, orderedTrackIds: List<String>) {
        clearPlaylist(playlistId)
        orderedTrackIds.forEachIndexed { index, trackId ->
            upsert(PlaylistTrackEntity(playlistId, trackId, index))
        }
    }
}

@Dao
interface ResolvedStreamDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ResolvedStreamEntity)

    @Query("SELECT * FROM resolved_streams WHERE trackId = :trackId")
    suspend fun get(trackId: String): ResolvedStreamEntity?

    @Query("DELETE FROM resolved_streams WHERE trackId = :trackId")
    suspend fun delete(trackId: String)

    @Query("DELETE FROM resolved_streams WHERE streamExpiresAt > 0 AND streamExpiresAt < :now")
    suspend fun deleteExpired(now: Long)

    @Query("DELETE FROM resolved_streams")
    suspend fun clearAll()
}

@Dao
interface SeenTrackDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markSeen(entity: SeenTrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markSeenAll(entities: List<SeenTrackEntity>)

    @Query("SELECT trackId FROM seen_tracks")
    suspend fun getAllIds(): List<String>

    @Query("DELETE FROM seen_tracks")
    suspend fun clearAll()
}

@Dao
interface RecentSearchDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RecentSearchEntity)

    @Query("SELECT * FROM recent_searches ORDER BY searchedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 20): Flow<List<RecentSearchEntity>>

    @Query("DELETE FROM recent_searches")
    suspend fun clearAll()

    @Query("DELETE FROM recent_searches WHERE query = :query")
    suspend fun delete(query: String)
}

@Dao
interface PlayHistoryDao {
    @Insert
    suspend fun insert(entity: PlayHistoryEntity)

    @Query("SELECT * FROM play_history ORDER BY playedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 50): List<PlayHistoryEntity>

    @Query("SELECT trackId FROM play_history ORDER BY playedAt DESC LIMIT :limit")
    suspend fun recentTrackIds(limit: Int = 30): List<String>
}

@Dao
interface DownloadDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<DownloadEntity>)

    @Query("SELECT * FROM downloads ORDER BY position ASC, createdAt ASC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'DOWNLOADING', 'PAUSED') ORDER BY position ASC")
    fun observeActive(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun getById(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status = 'QUEUED' ORDER BY position ASC LIMIT 1")
    suspend fun nextQueued(): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status = 'DOWNLOADING' LIMIT 1")
    suspend fun currentDownloading(): DownloadEntity?

    @Query("UPDATE downloads SET status = :status, progress = :progress, bytesDownloaded = :bytes, totalBytes = :total, speedBps = :speed, error = :error, updatedAt = :now WHERE id = :id")
    suspend fun updateProgress(id: String, status: String, progress: Float, bytes: Long, total: Long, speed: Long, error: String?, now: Long)

    @Query("UPDATE downloads SET status = 'COMPLETED', localUri = :localUri, mediaStoreUri = :mediaStoreUri, progress = 1.0, updatedAt = :now WHERE id = :id")
    suspend fun markCompleted(id: String, localUri: String, mediaStoreUri: String?, now: Long)

    @Query("UPDATE downloads SET status = :status, error = :error, updatedAt = :now WHERE id = :id")
    suspend fun markFailed(id: String, status: String, error: String?, now: Long)

    @Query("UPDATE downloads SET position = :position WHERE id = :id")
    suspend fun setPosition(id: String, position: Int)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM downloads WHERE status IN ('COMPLETED', 'FAILED', 'CANCELLED')")
    suspend fun clearFinished()

    @Query("SELECT MAX(position) FROM downloads")
    suspend fun maxPosition(): Int?

    @Query("SELECT COUNT(*) FROM downloads WHERE status IN ('QUEUED', 'DOWNLOADING', 'PAUSED')")
    fun observeActiveCount(): Flow<Int>
}

@Dao
interface OfflineTrackDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: OfflineTrackEntity)

    @Query("SELECT * FROM offline_tracks WHERE trackId = :trackId")
    suspend fun get(trackId: String): OfflineTrackEntity?

    @Query("SELECT * FROM offline_tracks")
    fun observeAll(): Flow<List<OfflineTrackEntity>>

    @Query("SELECT trackId FROM offline_tracks")
    fun observeIds(): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM offline_tracks WHERE trackId = :trackId)")
    fun observeIsOffline(trackId: String): Flow<Boolean>

    @Query("DELETE FROM offline_tracks WHERE trackId = :trackId")
    suspend fun delete(trackId: String)

    @Query("SELECT COUNT(*) FROM offline_tracks")
    fun observeCount(): Flow<Int>

    /** Every downloaded song with its metadata, newest download first. */
    @Query("SELECT t.* FROM tracks t INNER JOIN offline_tracks o ON o.trackId = t.id ORDER BY o.downloadedAt DESC")
    fun observeOfflineTracks(): Flow<List<TrackEntity>>

    @Query("SELECT t.* FROM tracks t INNER JOIN offline_tracks o ON o.trackId = t.id")
    suspend fun getOfflineTracks(): List<TrackEntity>
}
