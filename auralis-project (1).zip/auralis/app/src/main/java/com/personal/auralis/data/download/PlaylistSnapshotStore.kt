package com.personal.auralis.data.download

import android.content.Context
import android.os.Environment
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Saves playlist metadata + custom covers to a public Documents folder
 * so they can be recovered after app uninstall/reinstall.
 */
@Singleton
class PlaylistSnapshotStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    private fun snapshotDir(): File {
        val base = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val dir = File(base, "Auralis")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    @Serializable
    data class SnapshotTrack(
        val id: String,
        val title: String,
        val artist: String,
        val album: String? = null,
        val durationMs: Long = 0,
        val coverUrl: String? = null,
        val source: String = "youtube",
        val externalId: String? = null
    )

    @Serializable
    data class SnapshotPlaylist(
        val id: String,
        val name: String,
        val coverUrl: String? = null,
        val localCoverUri: String? = null,
        val isLikedSongs: Boolean = false,
        val trackIds: List<String> = emptyList()
    )

    @Serializable
    data class Snapshot(
        val version: Int = 1,
        val exportedAt: Long = System.currentTimeMillis(),
        val playlists: List<SnapshotPlaylist> = emptyList(),
        val tracks: List<SnapshotTrack> = emptyList()
    )

    suspend fun export(snapshot: Snapshot) = withContext(Dispatchers.IO) {
        try {
            val file = File(snapshotDir(), "playlists_snapshot.json")
            file.writeText(json.encodeToString(snapshot))
        } catch (_: Exception) {
            // Best-effort; scoped storage / permission may block on some devices
        }
    }

    suspend fun import(): Snapshot? = withContext(Dispatchers.IO) {
        try {
            val file = File(snapshotDir(), "playlists_snapshot.json")
            // Fall back to the folder used under the app's old name ("Sonora").
            val legacy = File(
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Sonora"),
                "playlists_snapshot.json"
            )
            val src = when {
                file.exists() -> file
                legacy.exists() -> legacy
                else -> return@withContext null
            }
            json.decodeFromString<Snapshot>(src.readText())
        } catch (_: Exception) {
            null
        }
    }
}
