package com.personal.auralis.data.spotify

import com.personal.auralis.data.catalog.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Singleton

class PlaylistImportException(message: String) : Exception(message)

typealias SpotifyImportException = PlaylistImportException

data class ImportedPlaylist(
    val name: String,
    val coverUrl: String?,
    val tracks: List<Track>
)

/**
 * Reads a PUBLIC Spotify playlist/album from its embed page (no login, no API key).
 * This is unofficial: it only returns what the embed page exposes (roughly the first
 * 50-100 tracks) and may stop working if Spotify changes the page.
 */
@Singleton
class SpotifyImporter @Inject constructor(
    private val client: OkHttpClient
) {
    private val idRegex = Regex("(playlist|album)[/:]([A-Za-z0-9]{22})")
    private val nextDataRegex =
        Regex("<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>", RegexOption.DOT_MATCHES_ALL)

    private val userAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/126.0.0.0 Safari/537.36"

    suspend fun fetch(link: String): ImportedPlaylist = withContext(Dispatchers.IO) {
        val (type, id) = resolveLink(link)
        val html = download("https://open.spotify.com/embed/$type/$id?utm_source=generator")
        parse(html)
    }

    /** Album art for one track via Spotify's public oEmbed endpoint (no login). */
    suspend fun fetchTrackCover(spotifyTrackId: String): String? = withContext(Dispatchers.IO) {
        try {
            val target = URLEncoder.encode("https://open.spotify.com/track/$spotifyTrackId", "UTF-8")
            val req = Request.Builder()
                .url("https://open.spotify.com/oembed?url=$target")
                .header("User-Agent", userAgent)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    null
                } else {
                    val obj = Json.parseToJsonElement(resp.body?.string().orEmpty()) as? JsonObject
                    str(obj?.get("thumbnail_url"))
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            null
        }
    }

    // ---------- link handling ----------

    private fun resolveLink(raw: String): Pair<String, String> {
        val text = raw.trim()
        idRegex.find(text)?.let { return it.groupValues[1] to it.groupValues[2] }

        if (text.startsWith("http", ignoreCase = true)) {
            // Short links (spotify.link/...) redirect to the real page.
            try {
                val req = Request.Builder().url(text).header("User-Agent", userAgent).build()
                client.newCall(req).execute().use { resp ->
                    idRegex.find(resp.request.url.toString())?.let {
                        return it.groupValues[1] to it.groupValues[2]
                    }
                    val body = resp.body?.string().orEmpty()
                    idRegex.find(body)?.let { return it.groupValues[1] to it.groupValues[2] }
                }
            } catch (e: IllegalArgumentException) {
                throw SpotifyImportException("That does not look like a valid link.")
            } catch (e: IOException) {
                throw SpotifyImportException("Could not open the link. Check your internet connection.")
            }
        }
        throw SpotifyImportException(
            "Paste a Spotify playlist or album link (open.spotify.com/playlist/...)."
        )
    }

    private fun download(url: String): String {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()
        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw SpotifyImportException(
                        "Spotify returned HTTP ${resp.code}. Is the playlist public?"
                    )
                }
                return resp.body?.string().orEmpty()
            }
        } catch (e: IOException) {
            throw SpotifyImportException("Network error: ${e.message ?: "could not reach Spotify"}")
        }
    }

    // ---------- parsing ----------

    private fun parse(html: String): ImportedPlaylist {
        val jsonText = nextDataRegex.find(html)?.groupValues?.get(1)
            ?: throw SpotifyImportException(
                "Could not read the Spotify page (Spotify may have changed it or blocked the request)."
            )
        val root = try {
            Json.parseToJsonElement(jsonText)
        } catch (e: Exception) {
            throw SpotifyImportException("Could not understand the Spotify page data.")
        }

        val owner = findObjectWithKey(root, "trackList")
        val trackList = owner?.get("trackList") as? JsonArray
        val found = LinkedHashMap<String, Track>()
        if (trackList != null) {
            for (item in trackList) collectTracks(item, found)
        } else {
            collectTracks(root, found)
        }
        if (found.isEmpty()) {
            throw SpotifyImportException(
                "No songs found. The playlist may be private or empty."
            )
        }

        val name = owner?.let { str(it["name"]) ?: str(it["title"]) }?.trim()
            ?.takeIf { it.isNotEmpty() } ?: "Spotify playlist"
        val cover = owner?.let { firstImage(it, skipKey = "trackList") }
            ?: found.values.firstNotNullOfOrNull { it.coverUrl }
        return ImportedPlaylist(name, cover, found.values.toList())
    }

    private fun collectTracks(e: JsonElement, out: MutableMap<String, Track>) {
        when (e) {
            is JsonObject -> {
                val uri = str(e["uri"])
                if (uri != null && uri.startsWith("spotify:track:")) {
                    val track = toTrack(e, uri.removePrefix("spotify:track:"))
                    if (track != null && !out.containsKey(track.id)) out[track.id] = track
                } else {
                    for (v in e.values) collectTracks(v, out)
                }
            }
            is JsonArray -> for (v in e) collectTracks(v, out)
            else -> {}
        }
    }

    private fun toTrack(o: JsonObject, spotifyId: String): Track? {
        val title = (str(o["title"]) ?: str(o["name"]))?.trim()
        if (title.isNullOrEmpty()) return null
        val artist = (str(o["subtitle"]) ?: artistsFrom(o["artists"]) ?: "")
            .replace('\u00a0', ' ')
            .trim()
        return Track(
            id = "sp_$spotifyId",
            title = title,
            artist = artist,
            album = null,
            durationMs = durationMs(o),
            coverUrl = firstImage(o),
            source = "spotify",
            externalId = spotifyId
        )
    }

    private fun artistsFrom(e: JsonElement?): String? {
        val arr = e as? JsonArray ?: return null
        val names = arr.mapNotNull { item ->
            when (item) {
                is JsonObject -> str(item["name"])
                is JsonPrimitive -> if (item.isString) item.content else null
                else -> null
            }
        }
        return names.joinToString(", ").takeIf { it.isNotEmpty() }
    }

    private fun durationMs(o: JsonObject): Long {
        for (key in listOf("duration", "duration_ms", "durationMs")) {
            val v = (o[key] as? JsonPrimitive)?.longOrNull ?: continue
            if (v <= 0) continue
            // Some versions give seconds, others milliseconds.
            return if (v < 2000) v * 1000 else v
        }
        return 0L
    }

    private fun str(e: JsonElement?): String? {
        val p = e as? JsonPrimitive ?: return null
        return if (p.isString) p.content else null
    }

    private fun findObjectWithKey(e: JsonElement, key: String): JsonObject? {
        when (e) {
            is JsonObject -> {
                if (e.containsKey(key)) return e
                for (v in e.values) {
                    val r = findObjectWithKey(v, key)
                    if (r != null) return r
                }
            }
            is JsonArray -> for (v in e) {
                val r = findObjectWithKey(v, key)
                if (r != null) return r
            }
            else -> {}
        }
        return null
    }

    private fun firstImage(e: JsonElement, skipKey: String? = null): String? {
        when (e) {
            is JsonPrimitive ->
                if (e.isString && e.content.startsWith("https://i.scdn.co/image/")) return e.content
            is JsonObject -> for ((k, v) in e) {
                if (k == skipKey) continue
                val r = firstImage(v, skipKey)
                if (r != null) return r
            }
            is JsonArray -> for (v in e) {
                val r = firstImage(v, skipKey)
                if (r != null) return r
            }
            else -> {}
        }
        return null
    }
}
