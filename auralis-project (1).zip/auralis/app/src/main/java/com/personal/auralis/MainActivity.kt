package com.personal.auralis

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.personal.auralis.player.PlayerController
import com.personal.auralis.ui.components.CrashDialog
import com.personal.auralis.ui.navigation.AuralisNavGraph
import com.personal.auralis.ui.theme.AuralisTheme
import com.personal.auralis.ui.theme.SpotifyBlack
import com.personal.auralis.util.CrashLog
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var playerController: PlayerController

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        playerController.connect()
        setContent {
            AuralisTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = SpotifyBlack
                ) {
                    AuralisNavGraph(playerController = playerController)
                    var crash by remember { mutableStateOf(CrashLog.read(applicationContext)) }
                    crash?.let { report ->
                        CrashDialog(
                            report = report,
                            onDismiss = {
                                CrashLog.clear(applicationContext)
                                crash = null
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        playerController.disconnect()
        super.onDestroy()
    }
}
