package com.personal.auralis.data.download

import android.content.Context
import android.provider.MediaStore
import com.personal.auralis.data.db.OfflineTrackDao
import com.personal.auralis.data.db.OfflineTrackEntity
import com.personal.auralis.data.db.PlaylistDao
import com.personal.auralis.data.db.PlaylistEntity
import com.personal.auralis.data.db.PlaylistTrackDao
import com.personal.auralis.data.db.PlaylistTrackEntity
import com.personal.auralis.data.db.TrackDao
import com.personal.auralis.data.db.TrackEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * On first launch after reinstall, recover offline tracks from MediaStore
 * and playlists from Documents/Auralis snapshot.
 */
@Singleton
class OfflineRecovery @Inject constructor(
    @ApplicationContext private val context: Context,
    private val snapshotStore: PlaylistSnapshotStore,
    private val trackDao: TrackDao,
    private val playlistDao: PlaylistDao,
    private val playlistTrackDao: PlaylistTrackDao,
    private val offlineTrackDao: OfflineTrackDao
) {
    suspend fun runIfNeeded() = withContext(Dispatchers.IO) {
        try {
            recoverFromSnapshot()
            recoverOfflineFromMediaStore()
        } catch (_: Exception) {
            // Best-effort
        }
    }

    private suspend fun recoverFromSnapshot() {
        val snap = snapshotStore.import() ?: return
        if (snap.tracks.isEmpty() && snap.playlists.isEmpty()) return

        // Restore tracks
        snap.tracks.forEach { t ->
            trackDao.upsert(
                TrackEntity(
                    id = t.id,
                    title = t.title,
                    artist = t.artist,
                    album = t.album,
                    durationMs = t.durationMs,
                    coverUrl = t.coverUrl,
                    source = t.source,
                    externalId = t.externalId
                )
            )
        }

        // Restore playlists (skip if already present)
        for (pl in snap.playlists) {
            if (playlistDao.getById(pl.id) != null) continue
            playlistDao.upsert(
                PlaylistEntity(
                    id = pl.id,
                    name = pl.name,
                    coverUrl = pl.coverUrl,
                    localCoverUri = pl.localCoverUri,
                    isLikedSongs = pl.isLikedSongs
                )
            )
            pl.trackIds.forEachIndexed { index, tid ->
                playlistTrackDao.upsert(
                    PlaylistTrackEntity(playlistId = pl.id, trackId = tid, position = index)
                )
            }
        }
    }

    private suspend fun recoverOfflineFromMediaStore() {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE
        )
        // Also scan the folder used by the app's old name ("Sonora") so earlier downloads are still found.
        val selection = "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
        val args = arrayOf("%Music/Auralis%", "%Music/Sonora%")

        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            selection,
            args,
            null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

            while (cursor.moveToNext()) {
                val mediaId = cursor.getLong(idCol)
                val title = cursor.getString(titleCol) ?: continue
                val artist = cursor.getString(artistCol) ?: "Unknown"
                val duration = cursor.getLong(durCol)
                val size = cursor.getLong(sizeCol)
                val uri = android.content.ContentUris.withAppendedId(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId
                ).toString()

                // Synthetic stable id from media path so we can re-link
                val trackId = "offline_$mediaId"
                if (offlineTrackDao.get(trackId) != null) continue

                trackDao.upsert(
                    TrackEntity(
                        id = trackId,
                        title = title,
                        artist = artist,
                        durationMs = duration,
                        source = "offline",
                        externalId = mediaId.toString()
                    )
                )
                offlineTrackDao.upsert(
                    OfflineTrackEntity(
                        trackId = trackId,
                        localUri = uri,
                        mediaStoreUri = uri,
                        fileSize = size,
                        quality = "HIGH"
                    )
                )
            }
        }
    }
}
