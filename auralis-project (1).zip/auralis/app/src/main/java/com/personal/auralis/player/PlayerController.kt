package com.personal.auralis.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.personal.auralis.data.catalog.Track
import com.personal.auralis.data.playlist.toTrack
import com.personal.auralis.data.recommend.DiscoverEngine
import com.personal.auralis.data.resolver.YouTubeResolver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

data class PlayerUiState(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val codec: String? = null,
    val bitrate: Int = 0,
    val error: String? = null
)

@Singleton
class PlayerController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val resolver: YouTubeResolver,
    private val offlineTrackDao: com.personal.auralis.data.db.OfflineTrackDao,
    private val discover: DiscoverEngine
) {
    private class PendingLoad(val item: MediaItem)

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    // Any uncaught error inside a player coroutine is shown on screen instead of killing the app.
    private val errorHandler = CoroutineExceptionHandler { _, e ->
        _state.value = _state.value.copy(
            error = "Player error: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
        )
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + errorHandler)

    private val queue = mutableListOf<Track>()
    private var currentIndex = 0
    private val autoIds = mutableSetOf<String>()
    private var originalOrder: List<Track>? = null
    private var pending: PendingLoad? = null
    private var retriedTrackId: String? = null
    private var repeat = Player.REPEAT_MODE_OFF
    @Volatile private var playingOffline = false

    private var loadJob: Job? = null
    private var loadToken = 0L
    private var autoplayJob: Job? = null

    // ---------------------------------------------------------------- connection

    fun connect() {
        if (controller != null || controllerFuture != null) return
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, token).buildAsync()
        controllerFuture?.addListener({
            try {
                val c = controllerFuture?.get()
                controller = c
                c?.addListener(playerListener)
                val p = pending
                if (c != null && p != null) {
                    c.setMediaItem(p.item)
                    c.prepare()
                    c.play()
                    pending = null
                }
                syncState()
            } catch (e: Exception) {
                _state.value = _state.value.copy(error = "Player service error: ${e.message}")
            }
        }, MoreExecutors.directExecutor())
    }

    fun disconnect() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    // ---------------------------------------------------------------- user intents

    fun play(track: Track, newQueue: List<Track> = listOf(track), startIndex: Int = 0) {
        val q = newQueue.ifEmpty { listOf(track) }
        val idx = if (q.getOrNull(startIndex)?.id == track.id) startIndex
        else q.indexOfFirst { it.id == track.id }
        val finalQueue = if (idx >= 0) q else listOf(track) + q
        val finalIdx = if (idx >= 0) idx else 0

        queue.clear()
        queue.addAll(finalQueue)
        currentIndex = finalIdx
        autoIds.clear()
        originalOrder = null
        if (_state.value.shuffle && queue.size > 1) shuffleKeepingCurrent()
        retriedTrackId = null
        startLoad(queue[currentIndex])
    }

    fun playNext(track: Track) {
        val insertAt = (currentIndex + 1).coerceAtMost(queue.size)
        queue.add(insertAt, track)
        originalOrder = originalOrder?.plus(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun addToQueue(track: Track) {
        queue.add(track)
        originalOrder = originalOrder?.plus(track)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.playbackState == Player.STATE_ENDED) {
            c.seekTo(0)
            c.play()
        } else if (c.playWhenReady) {
            c.pause()
        } else {
            c.play()
        }
    }

    fun playAt(index: Int) {
        if (index !in queue.indices) return
        currentIndex = index
        retriedTrackId = null
        startLoad(queue[index])
    }

    fun skipNext() {
        localNext(userInitiated = true)
    }

    fun skipPrevious() {
        if ((controller?.currentPosition ?: 0L) > 3000L) {
            controller?.seekTo(0)
        } else if (currentIndex > 0) {
            currentIndex--
            retriedTrackId = null
            startLoad(queue[currentIndex])
        } else {
            controller?.seekTo(0)
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _state.value = _state.value.copy(positionMs = ms)
    }

    fun setShuffle(enabled: Boolean) {
        if (enabled == _state.value.shuffle) return
        if (enabled) {
            if (queue.size > 1) shuffleKeepingCurrent()
        } else {
            val orig = originalOrder
            if (orig != null) {
                val cur = queue.getOrNull(currentIndex)
                val extras = queue.filter { q -> orig.none { it.id == q.id } }
                queue.clear()
                queue.addAll(orig + extras)
                currentIndex = cur?.let { c -> queue.indexOfFirst { it.id == c.id } }
                    ?.takeIf { it >= 0 } ?: 0
            }
            originalOrder = null
        }
        _state.value = _state.value.copy(
            shuffle = enabled,
            queue = queue.toList(),
            queueIndex = currentIndex
        )
    }

    fun cycleRepeat() {
        repeat = when (repeat) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        // ONE is looped by the player itself; ALL is handled by our own queue (wrap-around).
        controller?.repeatMode =
            if (repeat == Player.REPEAT_MODE_ONE) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        _state.value = _state.value.copy(repeatMode = repeat)
    }

    fun clearQueue() {
        autoplayJob?.cancel()
        loadJob?.cancel()
        queue.clear()
        autoIds.clear()
        originalOrder = null
        currentIndex = 0
        controller?.stop()
        controller?.clearMediaItems()
        _state.value = PlayerUiState(shuffle = _state.value.shuffle, repeatMode = repeat)
    }

    fun reorderQueue(from: Int, to: Int) {
        if (from in queue.indices && to in queue.indices) {
            val item = queue.removeAt(from)
            queue.add(to, item)
            when {
                currentIndex == from -> currentIndex = to
                from < currentIndex && to >= currentIndex -> currentIndex--
                from > currentIndex && to <= currentIndex -> currentIndex++
            }
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun removeFromQueue(index: Int) {
        if (index in queue.indices && index != currentIndex) {
            val removed = queue.removeAt(index)
            autoIds.remove(removed.id)
            originalOrder = originalOrder?.filter { it.id != removed.id }
            if (index < currentIndex) currentIndex--
            _state.value = _state.value.copy(queue = queue.toList(), queueIndex = currentIndex)
        }
    }

    fun updatePosition() {
        controller?.let {
            _state.value = _state.value.copy(
                positionMs = it.currentPosition,
                durationMs = it.duration.coerceAtLeast(0)
            )
        }
    }

    // ---------------------------------------------------------------- auto-continue

    /**
     * More songs in the style of the queue: based on the tracks the user queued themselves
     * (not the auto-added ones). With no internet it falls back to other downloaded songs,
     * so offline listening never just stops at the end of the list.
     */
    private suspend fun buildAutoplayBatch(items: List<Track>, auto: Set<String>): List<Track> {
        val seeds = items.filter { it.id !in auto }.ifEmpty { items.takeLast(10) }
        if (seeds.isEmpty()) return emptyList()
        val online = try {
            withContext(Dispatchers.IO) {
                discover.autoplayFor(seeds, items.map { it.id }.toHashSet(), 15)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            emptyList()
        }
        if (online.isNotEmpty()) return online

        return try {
            val have = items.map { it.id }.toHashSet()
            withContext(Dispatchers.IO) {
                offlineTrackDao.getOfflineTracks()
                    .filter { it.id !in have }
                    .shuffled()
                    .take(15)
                    .map { it.toTrack() }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            emptyList()
        }
    }

    private fun appendAuto(more: List<Track>) {
        val existing = queue.map { it.id }.toHashSet()
        val add = more.filter { existing.add(it.id) }
        if (add.isEmpty()) return
        queue.addAll(add)
        autoIds.addAll(add.map { it.id })
        originalOrder = originalOrder?.plus(add)
        _state.value = _state.value.copy(queue = queue.toList())
    }

    /** Keep at least two songs queued behind the current one, so the end of a playlist is seamless. */
    private fun ensureRunway() {
        if (repeat != Player.REPEAT_MODE_OFF) return
        if (queue.size - 1 - currentIndex >= 2) return
        if (autoplayJob?.isActive == true) return
        autoplayJob = scope.launch {
            val more = buildAutoplayBatch(queue.toList(), autoIds.toSet())
            if (more.isNotEmpty()) appendAuto(more)
        }
    }

    // ---------------------------------------------------------------- internals

    private fun shuffleKeepingCurrent() {
        originalOrder = queue.toList()
        val cur = queue.getOrNull(currentIndex)
        val rest = queue.filterIndexed { i, _ -> i != currentIndex }.shuffled()
        queue.clear()
        if (cur != null) queue.add(cur)
        queue.addAll(rest)
        currentIndex = 0
    }

    private fun notice(msg: String) {
        _state.value = _state.value.copy(error = msg)
        scope.launch {
            delay(3500)
            if (_state.value.error == msg) _state.value = _state.value.copy(error = null)
        }
    }

    /** Start loading [track]; any load still in flight is cancelled so an older tap can't win. */
    private fun startLoad(track: Track) {
        loadJob?.cancel()
        val token = ++loadToken
        loadJob = scope.launch {
            try {
                loadAndPlay(track)
            } finally {
                if (loadToken == token) loadJob = null
            }
        }
    }

    private fun localNext(userInitiated: Boolean) {
        when {
            currentIndex < queue.lastIndex -> {
                currentIndex++
                retriedTrackId = null
                startLoad(queue[currentIndex])
            }
            repeat == Player.REPEAT_MODE_ALL && queue.isNotEmpty() -> {
                currentIndex = 0
                retriedTrackId = null
                startLoad(queue[0])
            }
            else -> {
                // Playlist is over: keep the music going with songs in the same style.
                autoplayJob?.cancel()
                autoplayJob = scope.launch {
                    val more = buildAutoplayBatch(queue.toList(), autoIds.toSet())
                    if (more.isNotEmpty()) {
                        appendAuto(more)
                        if (currentIndex < queue.lastIndex) {
                            currentIndex++
                            retriedTrackId = null
                            startLoad(queue[currentIndex])
                        }
                    } else if (userInitiated) {
                        notice("หาเพลงต่อไม่ได้ ตรวจอินเทอร์เน็ต / Last.fm key")
                    }
                }
            }
        }
    }

    private suspend fun loadAndPlay(track: Track) {
        try {
            loadAndPlayInner(track)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            _state.value = _state.value.copy(
                isPlaying = false,
                error = "Cannot play: ${e.javaClass.simpleName} ${e.message ?: ""}".take(200)
            )
        }
    }

    /** The downloaded file was deleted from the phone: forget it so the UI stops claiming it's offline. */
    private suspend fun dropOfflineIfUnreadable(trackId: String) = withContext(Dispatchers.IO) {
        try {
            val rec = offlineTrackDao.get(trackId) ?: return@withContext
            val readable = try {
                context.contentResolver.openFileDescriptor(android.net.Uri.parse(rec.localUri), "r")
                    ?.use { true } ?: false
            } catch (e: Exception) {
                false
            }
            if (!readable) offlineTrackDao.delete(trackId)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private suspend fun loadAndPlayInner(track: Track) {
        _state.value = _state.value.copy(
            currentTrack = track,
            queue = queue.toList(),
            queueIndex = currentIndex,
            error = null,
            isPlaying = false,
            positionMs = 0L,
            durationMs = 0L
        )
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .apply { track.coverUrl?.let { setArtworkUri(android.net.Uri.parse(it)) } }
            .build()

        // Downloaded songs play straight from the local file (no internet needed).
        val offline = if (retriedTrackId != track.id) {
            try {
                offlineTrackDao.get(track.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        } else null
        val mediaItem: MediaItem
        playingOffline = offline != null
        if (offline != null) {
            mediaItem = MediaItem.Builder()
                .setUri(android.net.Uri.parse(offline.localUri))
                .setMediaId(track.id)
                .setMediaMetadata(metadata)
                .build()
            _state.value = _state.value.copy(codec = offline.codec, bitrate = offline.bitrate)
        } else {
            val resolved = resolver.resolve(track, preferHighest = true)
            if (resolved == null) {
                _state.value = _state.value.copy(
                    error = resolver.lastError ?: "Could not resolve stream"
                )
                return
            }
            mediaItem = MediaItem.Builder()
                .setUri(resolved.streamUrl)
                .setMediaId(track.id)
                .setMediaMetadata(metadata)
                .build()
            _state.value = _state.value.copy(codec = resolved.codec, bitrate = resolved.bitrate)
        }

        val c = controller
        if (c == null) {
            // Service connection not ready yet: play as soon as it connects.
            pending = PendingLoad(mediaItem)
            connect()
        } else {
            c.setMediaItem(mediaItem)
            c.prepare()
            c.play()
        }
        // Prefetch next track (not needed for offline files)
        if (offline == null) prefetchNext()
        ensureRunway()
    }

    private fun prefetchNext() {
        val next = queue.getOrNull(currentIndex + 1) ?: return
        scope.launch(Dispatchers.IO) {
            try {
                resolver.resolve(next, preferHighest = true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // prefetch is best-effort
            }
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val track = _state.value.currentTrack ?: return
            if (retriedTrackId != track.id) {
                // Stream URLs expire or get rejected: drop the cache and resolve once more.
                retriedTrackId = track.id
                val wasOffline = playingOffline
                scope.launch {
                    if (wasOffline) dropOfflineIfUnreadable(track.id)
                    resolver.invalidate(track.id)
                    startLoad(track)
                }
            } else {
                val detail = error.cause?.message ?: error.message ?: ""
                _state.value = _state.value.copy(
                    isPlaying = false,
                    error = "Playback failed (${error.errorCodeName}) $detail".take(160)
                )
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) localNext(userInitiated = false)
            syncState()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            syncState()
        }
    }

    private fun syncState() {
        val c = controller ?: return
        _state.value = _state.value.copy(
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition,
            durationMs = c.duration.coerceAtLeast(0),
            repeatMode = repeat
        )
    }
}
