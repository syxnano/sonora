package com.personal.auralis

import com.personal.auralis.data.resolver.AudioTrackPolicy
import com.personal.auralis.data.resolver.AudioTrackPolicy.Kind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioTrackPolicyTest {
    private data class S(val name: String, val type: String?, val url: String)

    private fun pick(list: List<S>) = AudioTrackPolicy.select(list) { AudioTrackPolicy.kindOf(it.type, it.url) }

    @Test fun originalWinsOverHigherBitrateDub() {
        val th = S("th", "ORIGINAL", "https://x/a?xtags=acont%3Doriginal%3Alang%3Dth")
        val en = S("en", "DUBBED", "https://x/b?xtags=acont%3Ddubbed-auto%3Alang%3Den")
        assertEquals(listOf(th), pick(listOf(en, th)))
    }

    @Test fun detectsTagsInUrlWhenTypeMissing() {
        val th = S("th", null, "https://x/a?xtags=acont%3Doriginal%3Alang%3Dth")
        val en = S("en", null, "https://x/b?xtags=acont%3Ddubbed-auto%3Alang%3Den")
        assertEquals(listOf(th), pick(listOf(en, th)))
    }

    @Test fun singleTrackVideosAreUntouched() {
        val a = S("a", null, "https://x/a?itag=140")
        val b = S("b", null, "https://x/b?itag=251")
        assertEquals(listOf(a, b), pick(listOf(a, b)))
    }

    @Test fun dropsDubsEvenWithoutOriginalTag() {
        val plain = S("plain", null, "https://x/a")
        val dub = S("dub", "DUBBED", "https://x/b")
        assertEquals(listOf(plain), pick(listOf(dub, plain)))
    }

    @Test fun onlyDubsAvailableStillPlays() {
        val dub = S("dub", "DUBBED", "https://x/b")
        assertEquals(listOf(dub), pick(listOf(dub)))
    }

    @Test fun cachedDubbedUrlIsRejected() {
        assertTrue(AudioTrackPolicy.isDubbedUrl("https://x/b?xtags=acont%3Ddubbed-auto%3Alang%3Den"))
        assertFalse(AudioTrackPolicy.isDubbedUrl("https://x/a?xtags=acont%3Doriginal%3Alang%3Dth"))
        assertEquals(Kind.UNKNOWN, AudioTrackPolicy.kindOf(null, "https://x/a"))
    }
}
