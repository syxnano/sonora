# Auralis

Personal Spotify-style music player for Android. Metadata from online catalogs; audio is resolved to YouTube audio-only streams (no video, no ads).

**Personal use only.** Audio extraction depends on NewPipe Extractor and may break when YouTube changes. Quality is limited by what YouTube serves (typically ~160 kbps Opus / ~128–256 kbps AAC), not lossless.

## Features

- **Home / Discover** – “Popular for you” recommendations from your playlists (Last.fm tags + similar tracks when an API key is set; otherwise YouTube search)
- **Search** – Songs via YouTube / Last.fm
- **Library** – Local playlists (Room), Liked Songs
- **Player** – Mini player, full Now Playing, queue, MediaSession notification, background playback
- **Audio resolver** – Scores YouTube results by duration, title/artist match, official channels; caches video IDs and stream URLs
- **Settings** – Streaming quality hints, discover count, crossfade, clear caches
- **Thai + English** UI strings

## Screenshots

*(Add screenshots here after building)*

## Optional: Last.fm API key

1. Create a free account and API key: https://www.last.fm/api/account/create  
2. Put it in `local.properties`:

```properties
LASTFM_API_KEY=your_key_here
```

Or set the GitHub secret `LASTFM_API_KEY` for CI. Without a key, the app falls back to YouTube Music–style search only.

## Build with GitHub Actions (zero local setup)

1. Create a new empty GitHub repository.
2. Push this project:

```bash
git init
git add .
git commit -m "Initial Auralis app"
git branch -M main
git remote add origin https://github.com/YOUR_USER/auralis.git
git push -u origin main
```

3. Open the **Actions** tab → workflow **Build APK** → download the artifact `auralis-debug-apk`.
4. Optional: add repository secret `LASTFM_API_KEY`.
5. Tagging `v*` also creates a GitHub Release with the APK.

## Build locally

Requirements: JDK 17, Android SDK (compileSdk 35).

```bash
# optional
cp local.properties.example local.properties
# edit sdk.dir and LASTFM_API_KEY

gradle assembleDebug
# or open in Android Studio and Run
```

APK path: `app/build/outputs/apk/debug/app-debug.apk`

CI uses **Gradle 8.13** (not the wrapper). AGP is **8.13.2**.

## Tech stack

- Kotlin, Jetpack Compose, Material 3 (dark theme)
- minSdk 26, targetSdk 35
- MVVM + Hilt + Coroutines/Flow
- Room, DataStore, Media3 (ExoPlayer + MediaSessionService)
- NewPipe Extractor (JitPack), OkHttp, Coil, kotlinx.serialization

## Limitations & legal

- YouTube extraction can break; update the NewPipe Extractor version when needed.
- Audio quality ceiling is YouTube’s, not CD/lossless.
- Spotify catalog cannot be fully listed; optional import of *your* playlists only (not implemented in this scaffold beyond Client ID field).
- Intended for **personal use**. Automated downloading/streaming may conflict with YouTube’s Terms of Service. Use at your own risk.

## Project structure

```
auralis/
├── app/
│   ├── build.gradle.kts
│   └── src/main/java/com/personal/auralis/
│       ├── data/ (db, catalog, resolver, recommend, settings)
│       ├── player/
│       ├── ui/
│       └── di/
├── gradle/libs.versions.toml
├── .github/workflows/build.yml
└── README.md
```

## License

Use and modify freely for personal projects. No warranty.

## Changelog (fix round 1)
- Playlists: add-to-playlist sheet (Home, Search, Now Playing), playlist page, rename/delete, remove songs, Liked Songs heart
- Search history is now tappable and deletable
- Playback: YouTube-compatible User-Agent for streams, progressive-only stream filter, one automatic retry, real error messages shown as toasts
- Fixed: tracks table used REPLACE which could cascade-delete playlist entries
- Spotify import is NOT implemented yet

## Changelog (fix round 2)
- Crash reporter: if the app crashes, the next launch shows the error text with a Copy button
- Player and stream resolver now catch every error (not only Exception) and show it as a message instead of closing the app
- Scoring keeps Thai/Unicode letters when matching song titles
- Library -> link icon: import a PUBLIC Spotify playlist/album by pasting its link (unofficial embed page, roughly first 50-100 songs, no login)

## Changelog (fix round 3)
- Fixed Android regex crash in title matching (escape ] and })
- Imported Spotify songs now get album art via Spotify's public oEmbed endpoint (also back-fills older imports when the Library opens)

## Changelog (fix round 4)
- Queue button on Now Playing opens a queue sheet (tap to jump, X to remove)
- YouTube extraction: requests are serialized, retried once, and fall back to the next 2 search results; failures now include the HTTP status
- Downloader uses a Firefox user agent like NewPipe

## Changelog (fix round 5)
- Import YouTube / YouTube Music playlists by link (public or unlisted, up to 300 videos) from the Library link icon
- Tracks that come from YouTube use their real video id directly (no re-search)

## Changelog (Phase 1–6 expansion)

### Phase 1 – Offline / Download Queue + Persistence
- Full download queue (serial, one active at a time)
- Quality selection: Low / Medium / High / Best (remembered)
- Progress with %, speed, ETA
- Files written to MediaStore Music/Auralis (survive uninstall)
- Playlist snapshot export to Documents/Auralis for recovery
- OfflineTrack table + Downloads UI screen

### Phase 2 – Guest Profile
- Local username + avatar URI in DataStore (no login / no Firebase)

### Phase 3 – Recommendations + Artist page
- AI-title filter + preference for Pop / R&B / T-Pop style discovery
- Basic ArtistScreen (name, platforms, top tracks)

### Phase 4 – Now Playing notes
- Existing sharp Coil covers retained; Canvas / lyrics can be added progressively

### Auto-continue
- When a playlist/queue ends, similar songs (same style as the queued tracks) are added automatically.
- With no internet it continues with other downloaded songs.

### Polish hooks
- Sleep timer + download quality + profile fields in SettingsRepository
- Equalizer preset already present
