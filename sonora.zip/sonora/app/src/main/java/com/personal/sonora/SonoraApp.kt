package com.personal.sonora

import android.app.Application
import com.personal.sonora.di.NewPipeInit
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class SonoraApp : Application() {
    /**
     * Injecting this marker forces Hilt to create the NewPipeInit binding,
     * which runs NewPipe.init(...) in its provider.
     */
    @Inject lateinit var newPipeInit: NewPipeInit
}
