package com.personal.sonora.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String? = null,
    val durationMs: Long = 0L,
    val coverUrl: String? = null,
    val source: String = "youtube", // youtube, lastfm, spotify
    val externalId: String? = null
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val coverUrl: String? = null,
    val isLikedSongs: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playlist_tracks",
    primaryKeys = ["playlistId", "trackId"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = TrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["trackId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("trackId")]
)
data class PlaylistTrackEntity(
    val playlistId: String,
    val trackId: String,
    val position: Int,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "resolved_streams")
data class ResolvedStreamEntity(
    @PrimaryKey val trackId: String,
    val videoId: String,
    val streamUrl: String? = null,
    val streamExpiresAt: Long = 0L,
    val codec: String? = null,
    val bitrate: Int = 0,
    val resolvedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "seen_tracks")
data class SeenTrackEntity(
    @PrimaryKey val trackId: String,
    val seenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recent_searches")
data class RecentSearchEntity(
    @PrimaryKey val query: String,
    val searchedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: String,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val trackId: String,
    val playlistId: String? = null,
    val title: String,
    val artist: String,
    val coverUrl: String? = null,
    val quality: String,
    val status: String,
    val position: Int = 0,
    val progress: Float = 0f,
    val bytesDownloaded: Long = 0L,
    val totalBytes: Long = 0L,
    val speedBps: Long = 0L,
    val error: String? = null,
    val localUri: String? = null,
    val mediaStoreUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "offline_tracks")
data class OfflineTrackEntity(
    @PrimaryKey val trackId: String,
    val localUri: String,
    val mediaStoreUri: String? = null,
    val quality: String = "HIGH",
    val fileSize: Long = 0L,
    val codec: String? = null,
    val bitrate: Int = 0,
    val downloadedAt: Long = System.currentTimeMillis()
)
