package com.personal.sonora.ui.social

import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.sonora.data.profile.ProfileRepository
import com.personal.sonora.data.social.FirebasePlaybackSync
import com.personal.sonora.data.social.FirebaseRoomRepository
import com.personal.sonora.player.PlayerController
import com.personal.sonora.ui.theme.SpotifyGreen
import com.personal.sonora.ui.theme.SpotifySecondary
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class SocialViewModel @Inject constructor(
    val rooms: FirebaseRoomRepository,
    val sync: FirebasePlaybackSync,
    val playerController: PlayerController,
    profileRepository: ProfileRepository
) : ViewModel() {
    val profile = profileRepository.profile

    init {
        sync.start()
    }

    fun create(name: String) = viewModelScope.launch {
        rooms.createRoom(name)
    }

    fun join(code: String, name: String) = viewModelScope.launch {
        rooms.joinRoom(code, name)
    }

    fun leave() = rooms.leave()

    fun chat(sender: String, text: String) = rooms.sendChat(sender, text)

    fun syncPlay() {
        rooms.sendPlayback("play")
        if (!playerController.state.value.isPlaying) playerController.togglePlayPause()
    }

    fun syncPause() {
        rooms.sendPlayback("pause")
        if (playerController.state.value.isPlaying) playerController.togglePlayPause()
    }

    fun syncSeek() {
        val pos = playerController.state.value.positionMs
        rooms.sendPlayback("seek", positionMs = pos)
    }

    fun shareTrack() {
        val st = playerController.state.value
        val t = st.currentTrack ?: return
        rooms.sendPlayback("track", positionMs = st.positionMs, track = t)
    }
}

@Composable
fun SocialScreen(
    viewModel: SocialViewModel = hiltViewModel()
) {
    val room by viewModel.rooms.room.collectAsState()
    val messages by viewModel.rooms.messages.collectAsState()
    val profile by viewModel.profile.collectAsState(
        initial = com.personal.sonora.data.profile.GuestProfile()
    )
    val playerState by viewModel.playerController.state.collectAsState()
    val username = profile.username
    var joinCode by remember { mutableStateOf("") }
    var chatText by remember { mutableStateOf("") }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = engine?.setLanguage(Locale("th", "TH"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine?.setLanguage(Locale.US)
                }
            }
        }
        tts = engine
        onDispose {
            engine?.stop()
            engine?.shutdown()
        }
    }

    // TTS for remote messages
    LaunchedEffect(messages.size) {
        val last = messages.lastOrNull() ?: return@LaunchedEffect
        if (last.tts && last.sender != username) {
            tts?.speak("${last.sender} ว่า ${last.text}", TextToSpeech.QUEUE_ADD, null, last.id)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Listen with Friends", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 22.sp)
        Text("Firebase · รหัส 6 หลัก · ไม่ต้อง login", color = SpotifySecondary, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))

        room.error?.let {
            Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }

        if (room.code == null) {
            Button(
                onClick = {
                    scope.launch {
                        val code = viewModel.rooms.createRoom(username)
                        if (code != null) {
                            Toast.makeText(context, "Room $code", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("สร้างห้อง", color = Color.Black)
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = joinCode,
                onValueChange = { if (it.length <= 6) joinCode = it.filter { c -> c.isDigit() } },
                label = { Text("รหัส 6 หลัก") },
                modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    scope.launch {
                        val ok = viewModel.rooms.joinRoom(joinCode, username)
                        if (ok) Toast.makeText(context, "เข้าร่วมแล้ว", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = joinCode.length == 6,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) {
                Text("เข้าร่วมห้อง", color = Color.White)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "ต้องวางไฟล์ google-services.json จาก Firebase Console ลง app/\n" +
                    "เปิด Anonymous Auth + Realtime Database\n" +
                    "Rules ตัวอย่างอยู่ใน firebase-rules.json",
                color = SpotifySecondary,
                fontSize = 12.sp
            )
        } else {
            Text(
                "ห้อง ${room.code}",
                color = SpotifyGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp
            )
            Text(
                "${room.status} · ออนไลน์ ~${room.peerCount} คน",
                color = SpotifySecondary
            )
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth()) {
                Button(
                    onClick = { viewModel.syncPlay() },
                    modifier = Modifier.weight(1f).padding(end = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)
                ) { Text("▶ Play", color = Color.Black) }
                Button(
                    onClick = { viewModel.syncPause() },
                    modifier = Modifier.weight(1f).padding(start = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
                ) { Text("⏸ Pause", color = Color.White) }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.shareTrack() },
                enabled = playerState.currentTrack != null,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) { Text("แชร์เพลงที่กำลังเล่น", color = Color.White) }
            Button(
                onClick = { viewModel.syncSeek() },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
            ) { Text("ซิงค์ตำแหน่งเล่น", color = Color.White) }

            Spacer(Modifier.height(16.dp))
            Text("แชท", color = Color.White, fontWeight = FontWeight.SemiBold)
            messages.takeLast(40).forEach { msg ->
                Text(
                    "${msg.sender}: ${msg.text}",
                    color = Color.White,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = chatText,
                    onValueChange = { chatText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("ข้อความ…") },
                    colors = fieldColors()
                )
                Button(
                    onClick = {
                        if (chatText.isNotBlank()) {
                            viewModel.chat(username, chatText)
                            tts?.speak(chatText, TextToSpeech.QUEUE_ADD, null, System.currentTimeMillis().toString())
                            chatText = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SpotifyGreen)
                ) { Text("ส่ง", color = Color.Black) }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { viewModel.leave() }) {
                Text("ออกจากห้อง")
            }
        }
    }
}

@Composable
private fun fieldColors() = TextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedContainerColor = Color(0xFF1E1E1E),
    unfocusedContainerColor = Color(0xFF1E1E1E)
)
