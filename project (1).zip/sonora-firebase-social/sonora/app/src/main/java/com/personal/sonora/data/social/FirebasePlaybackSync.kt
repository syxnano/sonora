package com.personal.sonora.data.social

import com.personal.sonora.data.catalog.Track
import com.personal.sonora.player.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Applies remote Firebase playback commands to the local player.
 */
@Singleton
class FirebasePlaybackSync @Inject constructor(
    private val rooms: FirebaseRoomRepository,
    private val player: PlayerController
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false

    fun start() {
        if (started) return
        started = true
        scope.launch {
            rooms.playback.collectLatest { cmd ->
                if (cmd == null) return@collectLatest
                apply(cmd)
            }
        }
    }

    private suspend fun apply(cmd: FirebaseRoomRepository.PlaybackCmd) {
        when (cmd.type) {
            "play" -> {
                if (!player.state.value.isPlaying) player.togglePlayPause()
            }
            "pause" -> {
                if (player.state.value.isPlaying) player.togglePlayPause()
            }
            "seek" -> {
                player.seekTo(cmd.positionMs)
            }
            "track" -> {
                val id = cmd.trackId ?: return
                val track = Track(
                    id = id,
                    title = cmd.trackTitle ?: "Track",
                    artist = cmd.trackArtist ?: "",
                    coverUrl = cmd.coverUrl
                )
                player.play(track)
                if (cmd.positionMs > 0) {
                    delay(900)
                    player.seekTo(cmd.positionMs)
                }
            }
        }
    }
}
