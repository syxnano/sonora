package com.personal.sonora.data.product

import com.personal.sonora.data.catalog.Track
import javax.inject.Inject
import javax.inject.Singleton

/** Deterministic, local ranking prototype. It never invents tracks; candidates come from catalog search. */
@Singleton
class TasteAgent @Inject constructor() {
    fun rank(request: String, taste: TasteMemory, candidates: List<Track>): AgentResult {
        val q = request.lowercase()
        val scored = candidates.map { t ->
            var score = 0
            if (t.id in taste.likedTrackIds) score += 70
            if (t.id in taste.dislikedTrackIds) score -= 120
            if (taste.likedArtists.any { t.artist.contains(it, true) }) score += 40
            if (taste.dislikedArtists.any { t.artist.contains(it, true) }) score -= 80
            if (taste.moodTags.any { tag -> q.contains(tag.lowercase()) }) score += 5
            if (q.contains("ไทย") && looksThai(t)) score += 25
            if (q.contains("ชิล") || q.contains("ช้า") || q.contains("calm")) score += calmScore(t)
            if (q.contains("เร็ว") || q.contains("มัน") || q.contains("energy")) score += energyScore(t)
            t to score
        }.sortedByDescending { it.second }
        val chosen = scored.take(10).map { it.first }
        val explanation = if (chosen.isEmpty()) "ยังหาเพลงที่ตรงเงื่อนไขจากรายการที่ตรวจแล้วไม่เจอ" else "คัดจากเพลงที่ค้นพบจริง แล้วให้น้ำหนักตามสิ่งที่คุณบอกไว้ก่อน"
        return AgentResult(chosen.map { it.id }, explanation, if (chosen.size < 3) "ลองเพิ่มเงื่อนไขหรือศิลปินที่ชอบอีกนิด" else null)
    }

    private fun looksThai(t: Track): Boolean = Regex("[ก-๙]").containsMatchIn(t.title + t.artist)
    private fun calmScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("acoustic|piano|slow|ballad", RegexOption.IGNORE_CASE))) 10 else 0
    private fun energyScore(t: Track): Int = if ((t.title + t.artist).contains(Regex("live|mix|remix|rock|dance|party", RegexOption.IGNORE_CASE))) 10 else 0
}
